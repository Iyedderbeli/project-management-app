const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String },
    status: {
      type: String,
      enum: ["Planning", "Active", "On Hold", "Completed", "Cancelled"],
      default: "Planning",
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High", "Critical"],
      default: "Medium",
    },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    dueDate: { type: Date, required: true },
    
    // Project assignments
    assignedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Users assigned to the project
    assignedDomainManagers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Domain managers assigned to the project
    projectManager: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // Main project manager
    
    // Project metadata
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    client: { type: String },
    budget: { type: Number },
    progress: { type: Number, default: 0 },
    
    // Project-level skill requirements
    requiredSkills: [{ type: String }],
    
    // Project settings
    isPublic: { type: Boolean, default: false }, // Whether project is visible to all users
    allowSelfAssignment: { type: Boolean, default: false }, // Whether users can assign themselves to tasks
    
    // Project statistics
    totalTasks: { type: Number, default: 0 },
    completedTasks: { type: Number, default: 0 },
    totalChecklistItems: { type: Number, default: 0 },
    completedChecklistItems: { type: Number, default: 0 },
    
    // Project notifications
    notifications: [{
      type: { type: String, enum: ["assignment", "progress", "deadline", "milestone", "message"], default: "assignment" },
      message: { type: String, required: true },
      fromUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      toUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      createdAt: { type: Date, default: Date.now },
      read: { type: Boolean, default: false },
      priority: { type: String, enum: ["Low", "Medium", "High"], default: "Medium" }
    }],
    
    // Project tags and categories
    tags: [{ type: String }],
    category: { type: String },
    
    // Project files and attachments
    attachments: [{ type: String }],
    projectDocuments: [{ type: String }],
    
    // Project milestones
    milestones: [{
      title: { type: String, required: true },
      description: { type: String },
      dueDate: { type: Date, required: true },
      completed: { type: Boolean, default: false },
      completedAt: { type: Date },
      completedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
    }]
  },
  { timestamps: true }
);

// Index for efficient queries
projectSchema.index({ status: 1, dueDate: 1 });
projectSchema.index({ assignedUsers: 1 });
projectSchema.index({ assignedDomainManagers: 1 });
projectSchema.index({ createdBy: 1 });

module.exports = mongoose.model('Project', projectSchema);
