const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    fromUser: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: "User", 
      required: true 
    },
    toUser: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: "User", 
      required: true 
    },
    message: { 
      type: String, 
      required: true 
    },
    read: { 
      type: Boolean, 
      default: false 
    },
    // Optional: link to a specific task if the message is about a task
    taskId: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: "Task" 
    },
    // Optional: link to a specific notification if the message is a response to a notification
    notificationId: { 
      type: mongoose.Schema.Types.ObjectId 
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Message', messageSchema); 