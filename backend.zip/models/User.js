const mongoose = require('mongoose');

const skillSchema = new mongoose.Schema({
    name: { type: String, required: true },
    rating: { type: Number, min: 1, max: 5, default: 1 },
    category: { type: String, default: "General" }
});

const UserSchema = new mongoose.Schema(
    {
        name: { type: String, required: true },
        email: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        profileImageUrl: { type: String, default: null },
        role: { type: String, enum: ["admin", "user","member", "domain_manager"], default: "member" },
        skills: [skillSchema], // Skills with ratings for assignment
        overallRating: { type: Number, min: 1, max: 5, default: 1 }, // Overall performance rating
        domainExpertise: [{ type: String }], // For domain managers - their areas of expertise
    },
    { timestamps: true}
);

module.exports = mongoose.model('User', UserSchema);

