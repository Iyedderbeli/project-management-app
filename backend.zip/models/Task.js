const mongoose = require('mongoose');

const todoSchema = new mongoose.Schema(
    {
        text: { type: String, required: true },
        completed: { type: Boolean, required: true },
        description: { type: String, default: "" }, // Description added by user when completing
        completedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // User who completed the item
        completedAt: { type: Date }, // When the item was completed
        approved: { type: Boolean, default: false },
        approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        approvedAt: { type: Date },
        rejected: { type: Boolean, default: false },
        rejectionFeedback: { type: String },
        rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        rejectedAt: { type: Date },
        requiredSkills: [{ type: String }], // Skills required for this checklist item
        assignedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Users assigned to this specific checklist item
        userRatings: [{
            userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
            rating: { type: Number, min: 1, max: 5, required: true },
            feedback: { type: String, default: "" },
            ratedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
            ratedAt: { type: Date, default: Date.now }
        }]
    });

    const taskSchema = new mongoose.Schema(
      {
        title: { type: String, required: true },
        description: { type: String },
        priority: {
          type: String,
          enum: ["Low", "Medium", "High"],
          default: "Medium",
        },
        status: {
          type: String,
          enum: ["Pending", "In Progress", "Completed", "Under Review", "Approved", "Rejected", "Ready for Assignment"],
          default: "Ready for Assignment",
        },
        dueDate: { type: Date, required: true },
        
        // Project relationship
        projectId: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: false }, // Reference to the project this task belongs to (optional for existing tasks)
        
        assignedTo: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
        assignedDomainManagers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Domain managers assigned to review this task
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        attachments: [{ type: String }],
        todoCheckList: [todoSchema],
        progress: { type: Number, default: 0 },
        // Domain Manager specific fields
        qualityRating: { type: Number, min: 1, max: 5, default: null },
        timeRating: { type: Number, min: 1, max: 5, default: null },
        ratedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        ratedAt: { type: Date },
        reviewNotes: { type: String },
        // Rejection feedback for admin
        adminRejectionFeedback: { type: String },
        rejectedByDomainManager: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        rejectedAt: { type: Date },
        // Task-level skill requirements
        requiredSkills: [{ type: String }], // Skills required for this task
        notifications: [{
          type: { type: String, enum: ["feedback", "approval", "assignment", "checklist_rejection", "message"], default: "feedback" },
          message: { type: String, required: true },
          fromUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
          toUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
          createdAt: { type: Date, default: Date.now },
          read: { type: Boolean, default: false },
          todoIndex: { type: Number }, // For checklist rejection notifications
          rejectionFeedback: { type: String } // For checklist rejection notifications
        }],
      },
      { timestamps: true }
    );
module.exports = mongoose.model('Task', taskSchema);

