const express = require('express');
const { registerUser, loginUser, getProfile, updateProfile } = require('../controllers/authController');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware'); // Import the upload middleware


//Auth Routes
router.post('/register', registerUser); // Register user
router.post('/login', loginUser); // Login user
router.get('/profile', protect, getProfile); // Get user profile
router.put('/profile', protect, updateProfile); // Update user profile

router.post("/upload-image", upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
    }
    const imageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
    res.status(200).json({ imageUrl });

})

module.exports = router;
