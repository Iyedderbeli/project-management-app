const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const { sendMessage, getConversation, getConversations, markMessagesAsRead, getUnreadCount, getAllMessages, createTestMessage, debugAllMessages } = require('../controllers/messageController');

router.post('/', protect, sendMessage);
router.get('/conversation/:userId', protect, getConversation);
router.get('/conversations', protect, getConversations);
router.put('/read/:userId', protect, markMessagesAsRead);
router.get('/unread-count', protect, getUnreadCount);
router.get('/debug/all', protect, getAllMessages); // Debug endpoint
router.post('/debug/test', protect, createTestMessage); // Test endpoint
router.get('/debug/messages', protect, debugAllMessages); // New debug endpoint

module.exports = router; 