const express = require("express");
const { adminOnly, protect, adminOrDomainManager, domainManagerOnly } = require("../middlewares/authMiddleware");
const {
    getUsers,
    getUserById,
    getDomainManagers,
    getUsersBySkills,
    searchUsers,
    updateUserSkills,
    updateDomainManagerExpertise,
} = require("../controllers/userController");

const router = express.Router();

//User Management Routes
router.get("/", protect, adminOrDomainManager, getUsers); // Get all users(admin or domain manager only)
router.get("/search", protect, searchUsers); // Search users by name or email
router.get("/domain-managers", protect, adminOrDomainManager, getDomainManagers); // Get domain managers with expertise
router.get("/by-skills", protect, domainManagerOnly, getUsersBySkills); // Get users by skills for assignment
router.get("/:id", protect, getUserById); // Get user by ID
router.put("/:id/skills", protect, adminOrDomainManager, updateUserSkills); // Update user skills and ratings
router.put("/:id/expertise", protect, adminOnly, updateDomainManagerExpertise); // Update domain manager expertise

module.exports = router;