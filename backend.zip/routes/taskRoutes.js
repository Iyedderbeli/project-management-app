const express = require("express");
const { protect, adminOnly, domainManagerOnly, adminOrDomainManager } = require("../middlewares/authMiddleware");
const router = express.Router();
const {
    getDashboardData,
    getUserDashboardData,
    getTasks,
    getTasksById,
    createTask,
    updateTask,
    deleteTask,
    updateTaskStatus,
    updateTaskChecklist,
    approveTodoItem,
    rejectTodoItem,
    rateTask,
    getTasksPendingApproval,
    getTasksPendingRating,
    assignUsersToChecklistItem,
    getSuitableUsersForChecklistItem,
    completeChecklistItem,
    rateUserPerformance,
    assignUsersToTask,
    assignDomainManagersToTask,
    getTasksReadyForAssignment,
    getRejectedTasks,
    sendFeedbackToAdmin,
    getNotifications,
    markNotificationAsRead,
    getDomainManagerDashboardData,
    getUserChecklistItems,
    updateChecklistItemStatus,
    updateChecklistItemDescription,
    getUserTasks
} = require("../controllers/taskController");


// Notification routes (must come BEFORE parameterized routes)
router.get("/notifications", protect, getNotifications);
router.put("/notifications/:notificationId/read", protect, markNotificationAsRead);

// Test endpoint
router.get("/test-notifications", protect, adminOnly, (req, res) => {
  res.json({ message: "Test endpoint working", user: req.user._id });
});

// Test endpoint for pending approval
router.get("/test-pending-approval", protect, domainManagerOnly, (req, res) => {
  res.json({ 
    message: "Test pending approval endpoint working", 
    user: req.user._id,
    userRole: req.user.role 
  });
});

// Test endpoint for checklist item status
router.get("/test-checklist-status", protect, (req, res) => {
  res.json({ 
    message: "Test checklist status endpoint working", 
    user: req.user._id,
    routes: "Routes are working"
  });
});

// Test endpoint for reject functionality
router.put("/test-reject", protect, domainManagerOnly, (req, res) => {
  console.log("=== TEST REJECT ENDPOINT HIT ===");
  console.log("User:", req.user._id);
  console.log("User role:", req.user.role);
  res.json({ 
    message: "Test reject endpoint working", 
    user: req.user._id,
    userRole: req.user.role 
  });
});

// Task Management Routes
router.get("/dashboard-data", protect, getDashboardData);
router.get("/user-dashboard-data", protect, getUserDashboardData);
router.get("/user-checklist-items", protect, getUserChecklistItems);
router.get("/user/my-tasks", protect, getUserTasks);
router.get("/domain-manager-dashboard-data", protect, domainManagerOnly, getDomainManagerDashboardData);
router.get("/", protect, getTasks); // Get all tasks (Admin: all, User: assigned)

// Domain Manager specific routes
router.get("/pending-approval", protect, domainManagerOnly, getTasksPendingApproval);
router.get("/pending-rating", protect, domainManagerOnly, getTasksPendingRating);

// Admin specific routes
router.get("/ready-for-assignment", protect, adminOnly, getTasksReadyForAssignment);
router.get("/rejected", protect, adminOnly, getRejectedTasks);

// User checklist item management routes (MUST come BEFORE the general /:id route)
router.put("/:id/todo/:todoIndex/status", protect, updateChecklistItemStatus); // Update checklist item status
router.put("/:id/todo/:todoIndex/description", protect, updateChecklistItemDescription); // Update checklist item description
router.put("/:id/todo/:todoIndex/approve", protect, domainManagerOnly, approveTodoItem);
router.put("/:id/todo/:todoIndex/reject", protect, domainManagerOnly, rejectTodoItem);
router.put("/:id/todo/:todoIndex/assign-users", protect, domainManagerOnly, assignUsersToChecklistItem); // Assign users to specific checklist item
router.get("/:id/todo/:todoIndex/suitable-users", protect, domainManagerOnly, getSuitableUsersForChecklistItem); // Get suitable users for checklist item
router.put("/:id/todo/:todoIndex/complete", protect, completeChecklistItem); // Complete checklist item (Assigned users only)
router.put("/:id/todo/:todoIndex/rate-user", protect, rateUserPerformance); // Rate user performance on checklist item

// General todo route (must come AFTER specific todo routes)
router.put("/:id/todo", protect, updateTaskChecklist); // Update task checklist

// Parameterized routes (must come AFTER specific todo routes)
router.get("/:id", protect, getTasksById); // Get task by ID
router.post("/", protect, adminOrDomainManager, createTask); // Create a task (Admin or Domain Manager)
router.put("/:id", protect, updateTask); // Update task details
router.delete("/:id", protect, adminOnly, deleteTask); // Delete a task (Admin only)
router.put("/:id/status", protect, updateTaskStatus); // Update task status

router.put("/:id/rate", protect, domainManagerOnly, rateTask);
router.put("/:id/assign", protect, domainManagerOnly, assignUsersToTask); // Assign users to task
router.put("/:id/assign-domain-managers", protect, adminOnly, assignDomainManagersToTask); // Assign domain managers to task (Admin only)
router.put("/:id/feedback-to-admin", protect, domainManagerOnly, sendFeedbackToAdmin); // Send feedback to admin


module.exports = router;