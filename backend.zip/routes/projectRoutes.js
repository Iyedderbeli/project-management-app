const express = require('express');
const router = express.Router();
const { protect, adminOnly, domainManagerOnly, adminOrDomainManager } = require('../middlewares/authMiddleware');
const {
    createProject,
    getProjects,
    getProjectById,
    updateProject,
    deleteProject,
    assignUsersToProject,
    getUserProjects
} = require('../controllers/projectController');

// @route   POST /api/projects
// @desc    Create a new project
// @access  Private (Admin or Domain Manager)
router.post('/', protect, adminOrDomainManager, createProject);

// @route   GET /api/projects
// @desc    Get all projects (with filtering)
// @access  Private
router.get('/', protect, getProjects);

// @route   GET /api/projects/user/my-projects
// @desc    Get user's assigned projects
// @access  Private
router.get('/user/my-projects', protect, getUserProjects);

// @route   GET /api/projects/:id
// @desc    Get project by ID
// @access  Private
router.get('/:id', protect, getProjectById);

// @route   PUT /api/projects/:id
// @desc    Update project
// @access  Private (Admin or assigned Domain Manager)
router.put('/:id', protect, adminOrDomainManager, updateProject);

// @route   DELETE /api/projects/:id
// @desc    Delete project
// @access  Private (Admin only)
router.delete('/:id', protect, adminOnly, deleteProject);

// @route   PUT /api/projects/:id/assign-users
// @desc    Assign users to project
// @access  Private (Admin or assigned Domain Manager)
router.put('/:id/assign-users', protect, adminOrDomainManager, assignUsersToProject);

module.exports = router;
