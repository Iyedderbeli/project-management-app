const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
    try {
        let token = req.headers.authorization;
        if (token && token.startsWith('Bearer')) {
            token = token.split(" ")[1]; // Extract the token from the header
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.user = await User.findById(decoded.id).select("-password");
            next();
        } else {
            res.status(401).json({ message: "Not authorized, no token" });
        }
        
    } catch (error) {
        res.status(401).json({ message: "Token Failed", error: error.message });
    }
};

// Middleware for Admin-only access
const adminOnly = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({message: "Access denied, admin only" });
    }
};

// Middleware for Domain Manager access
const domainManagerOnly = (req, res, next) => {
    if (req.user && req.user.role === 'domain_manager') {
        next();
    } else {
        res.status(403).json({message: "Access denied, domain manager only" });
    }
};

// Middleware for Admin or Domain Manager access
const adminOrDomainManager = (req, res, next) => {
    if (req.user && (req.user.role === 'admin' || req.user.role === 'domain_manager')) {
        next();
    } else {
        res.status(403).json({message: "Access denied, admin or domain manager only" });
    }
};

module.exports={protect,adminOnly,domainManagerOnly,adminOrDomainManager};