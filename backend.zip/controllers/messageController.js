const Message = require('../models/Message');
const User = require('../models/User');
const Task = require('../models/Task');

// Send a message
const sendMessage = async (req, res) => {
  try {
    const { toUserId, message, taskId, notificationId } = req.body;
    const fromUserId = req.user._id;



    // Validate that the recipient exists
    const toUser = await User.findById(toUserId);
    if (!toUser) {
      return res.status(404).json({ message: "Recipient not found" });
    }

    // Create the message
    const newMessage = new Message({
      fromUser: fromUserId,
      toUser: toUserId,
      message,
      taskId,
      notificationId
    });

    await newMessage.save();

    // Create a notification for the recipient
    // If there's a taskId, add notification to the task
    if (taskId) {
      const task = await Task.findById(taskId);
      if (task) {
        const notification = {
          type: "message",
          message: `${req.user.name} sent you a message: ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`,
          fromUser: fromUserId,
          toUser: toUserId,
          taskId: taskId,
          taskTitle: task.title
        };
        
        task.notifications.push(notification);
        await task.save();
      }
    } else {
      // Create a general notification for the recipient
      // First, try to find a task where the recipient is involved
      let recipientTasks = await Task.find({
        $or: [
          { createdBy: toUserId },
          { assignedTo: toUserId },
          { assignedDomainManagers: toUserId },
          { assignedUsers: toUserId },
          { "todoCheckList.assignedUsers": toUserId }
        ]
      }).limit(1);
      
      if (recipientTasks.length === 0) {
        // If no task found where recipient is involved, find a task where sender is involved
        // This ensures the notification is in a task the sender can see
        recipientTasks = await Task.find({
          $or: [
            { createdBy: fromUserId },
            { assignedTo: fromUserId },
            { assignedDomainManagers: fromUserId },
            { assignedUsers: fromUserId },
            { "todoCheckList.assignedUsers": fromUserId }
          ]
        }).limit(1);
      }
      
      if (recipientTasks.length === 0) {
        // If still no task found, find any task and add the notification there
        // This is a fallback to ensure notifications are always created
        recipientTasks = await Task.find({}).limit(1);
      }
      
      if (recipientTasks.length > 0) {
        const task = recipientTasks[0];
        const notification = {
          type: "message",
          message: `${req.user.name} sent you a message: ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`,
          fromUser: fromUserId,
          toUser: toUserId,
          taskTitle: "General Message"
        };
        
        task.notifications.push(notification);
        await task.save();
      }
    }

    // Populate user details for response
    await newMessage.populate('fromUser', 'name email profileImageUrl');
    await newMessage.populate('toUser', 'name email profileImageUrl');
    res.status(201).json(newMessage);
  } catch (error) {
    console.error("Error sending message:", error);
    res.status(500).json({ message: "Error sending message", error: error.message });
  }
};

// Get conversation between two users
const getConversation = async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUserId = req.user._id;

    // Get messages between the two users
    const messages = await Message.find({
      $or: [
        { fromUser: currentUserId, toUser: userId },
        { fromUser: userId, toUser: currentUserId }
      ]
    })
    .populate('fromUser', 'name email profileImageUrl')
    .populate('toUser', 'name email profileImageUrl')
    .populate('taskId', 'title')
    .sort({ createdAt: 1 });

    res.json(messages);
  } catch (error) {
    console.error("Error getting conversation:", error);
    res.status(500).json({ message: "Error getting conversation", error: error.message });
  }
};

// Get all conversations for current user
const getConversations = async (req, res) => {
  try {
    const currentUserId = req.user._id;
    console.log("Getting conversations for user:", currentUserId);

    // Get all messages where current user is involved
    const messages = await Message.find({
      $or: [
        { fromUser: currentUserId },
        { toUser: currentUserId }
      ]
    })
    .populate('fromUser', 'name email profileImageUrl role')
    .populate('toUser', 'name email profileImageUrl role')
    .populate('taskId', 'title')
    .sort({ createdAt: -1 });



    // Group messages by conversation partner
    const conversations = {};
    
    messages.forEach(message => {

      const otherUserId = message.fromUser._id.toString() === currentUserId.toString() 
        ? message.toUser._id.toString() 
        : message.fromUser._id.toString();
      
      if (!conversations[otherUserId]) {
        conversations[otherUserId] = {
          user: message.fromUser._id.toString() === currentUserId.toString() 
            ? message.toUser 
            : message.fromUser,
          lastMessage: message,
          unreadCount: 0
        };
      } else {
        // Update last message if this message is newer
        if (new Date(message.createdAt) > new Date(conversations[otherUserId].lastMessage.createdAt)) {
          conversations[otherUserId].lastMessage = message;
        }
      }
      
      // Count unread messages
      if (message.toUser._id.toString() === currentUserId.toString() && !message.read) {
        conversations[otherUserId].unreadCount++;
      }
    });

    // Convert to array and sort by last message date
    const conversationsArray = Object.values(conversations).sort((a, b) => 
      new Date(b.lastMessage.createdAt) - new Date(a.lastMessage.createdAt)
    );



    res.json(conversationsArray);
  } catch (error) {
    console.error("Error getting conversations:", error);
    res.status(500).json({ message: "Error getting conversations", error: error.message });
  }
};

// Mark messages as read
const markMessagesAsRead = async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUserId = req.user._id;

    // Mark all messages from the other user as read
    await Message.updateMany(
      {
        fromUser: userId,
        toUser: currentUserId,
        read: false
      },
      {
        read: true
      }
    );

    res.json({ message: "Messages marked as read" });
  } catch (error) {
    console.error("Error marking messages as read:", error);
    res.status(500).json({ message: "Error marking messages as read", error: error.message });
  }
};

// Get unread message count
const getUnreadCount = async (req, res) => {
  try {
    const currentUserId = req.user._id;

    const unreadCount = await Message.countDocuments({
      toUser: currentUserId,
      read: false
    });

    res.json({ unreadCount });
  } catch (error) {
    console.error("Error getting unread count:", error);
    res.status(500).json({ message: "Error getting unread count", error: error.message });
  }
};

// Test endpoint to get all messages (for debugging)
const getAllMessages = async (req, res) => {
  try {
    const messages = await Message.find({})
      .populate('fromUser', 'name email role')
      .populate('toUser', 'name email role')
      .sort({ createdAt: -1 });

    res.json(messages);
  } catch (error) {
    console.error("Error getting all messages:", error);
    res.status(500).json({ message: "Error getting all messages", error: error.message });
  }
};

// Test endpoint to create a sample message
const createTestMessage = async (req, res) => {
  try {
    const { fromUserId, toUserId, message } = req.body;

    // Validate users exist
    const fromUser = await User.findById(fromUserId);
    const toUser = await User.findById(toUserId);
    
    if (!fromUser || !toUser) {
      return res.status(404).json({ message: "One or both users not found" });
    }

    // Create the message
    const newMessage = new Message({
      fromUser: fromUserId,
      toUser: toUserId,
      message: message || "Test message from admin to domain manager"
    });

    await newMessage.save();

    // Populate user details for response
    await newMessage.populate('fromUser', 'name email profileImageUrl');
    await newMessage.populate('toUser', 'name email profileImageUrl');

    res.status(201).json(newMessage);
  } catch (error) {
    console.error("Error creating test message:", error);
    res.status(500).json({ message: "Error creating test message", error: error.message });
  }
};

// Debug endpoint to check all messages
const debugAllMessages = async (req, res) => {
  try {
    const messages = await Message.find({})
      .populate('fromUser', 'name email role')
      .populate('toUser', 'name email role')
      .sort({ createdAt: -1 });

    res.json({
      totalMessages: messages.length,
      messages: messages.map(m => ({
        from: m.fromUser?.name || 'Unknown',
        to: m.toUser?.name || 'Unknown',
        message: m.message.substring(0, 50) + "...",
        createdAt: m.createdAt,
        read: m.read
      }))
    });
  } catch (error) {
    console.error("Error in debugAllMessages:", error);
    res.status(500).json({ message: "Error getting debug messages", error: error.message });
  }
};

module.exports = {
  sendMessage,
  getConversation,
  getConversations,
  markMessagesAsRead,
  getUnreadCount,
  getAllMessages,
  createTestMessage,
  debugAllMessages
}; 