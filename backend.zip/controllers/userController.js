const Task = require("../models/Task");
const User = require("../models/User");
const bcrypt = require("bcryptjs");

// @desc Get all users(admin or domain manager only)
// @route GET /api/users
// @access Private/Admin/Domain Manager
const getUsers = async (req, res) => {
    try {
        const users = await User.find({ role: { $in: ['member', 'user', 'domain_manager'] } }).select("-password");
        
        //Add task count to each user
        const usersWithTaskCount = await Promise.all(users.map(async (user) => {
            const pendingTasks = await Task.countDocuments({ assignedTo: user._id, status: 'Pending' });
            const inProgressTasks = await Task.countDocuments({ assignedTo: user._id, status: 'In Progress' });
            const completedTasks = await Task.countDocuments({ assignedTo: user._id, status: 'Completed' });

            return {
                ...user._doc, //Include all existing user data
                pendingTasks,
                inProgressTasks,
                completedTasks
            };
        }));
        res.json(usersWithTaskCount);


    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get user by ID
// @route GET /api/users/:id
// @access Private
const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select("-password");
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get domain managers with expertise
// @route GET /api/users/domain-managers
// @access Private/Admin
const getDomainManagers = async (req, res) => {
    try {
        const domainManagers = await User.find({ role: 'domain_manager' })
            .select("-password")
            .sort({ overallRating: -1 });
        
        res.json(domainManagers);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get users by skills (for assignment)
// @route GET /api/users/by-skills
// @access Private/Domain Manager
const getUsersBySkills = async (req, res) => {
    try {
        const { skills } = req.query;
        const requiredSkills = skills ? skills.split(',') : [];
        
        let query = { role: { $in: ['member', 'user', 'domain_manager'] } };
        
        if (requiredSkills.length > 0) {
            query['skills.name'] = { $in: requiredSkills };
        }
        
        const users = await User.find(query)
            .select("-password")
            .sort({ overallRating: -1 });
        
        // Sort by skill match and rating
        const sortedUsers = users.map(user => {
            const skillMatchScore = requiredSkills.length > 0 
                ? user.skills.filter(skill => requiredSkills.includes(skill.name)).length / requiredSkills.length
                : 0;
            
            return {
                ...user._doc,
                skillMatchScore,
                matchedSkills: user.skills.filter(skill => requiredSkills.includes(skill.name))
            };
        }).sort((a, b) => {
            // Sort by skill match first, then by overall rating
            if (a.skillMatchScore !== b.skillMatchScore) {
                return b.skillMatchScore - a.skillMatchScore;
            }
            return b.overallRating - a.overallRating;
        });
        
        res.json(sortedUsers);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Search users by name or email
// @route GET /api/users/search
// @access Private
const searchUsers = async (req, res) => {
    try {
        const { q } = req.query;
        
        if (!q || q.trim().length === 0) {
            return res.status(400).json({ message: "Search query cannot be empty" });
        }

        // Allow single character searches for better user experience
        const searchQuery = {
            $or: [
                { name: { $regex: q.trim(), $options: 'i' } },
                { email: { $regex: q.trim(), $options: 'i' } }
            ]
        };

        const users = await User.find(searchQuery)
            .select("-password")
            .limit(20) // Increased limit for better search results
            .sort({ name: 1 });

        res.json(users);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Update user skills and ratings
// @route PUT /api/users/:id/skills
// @access Private/Admin/Domain Manager
const updateUserSkills = async (req, res) => {
    try {
        const { skills, overallRating } = req.body;
        const user = await User.findById(req.params.id);
        
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        
        if (skills) {
            user.skills = skills;
        }
        
        if (overallRating !== undefined) {
            user.overallRating = overallRating;
        }
        
        await user.save();
        
        const updatedUser = await User.findById(req.params.id).select("-password");
        res.json({ message: "User skills updated successfully", user: updatedUser });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Update domain manager expertise
// @route PUT /api/users/:id/expertise
// @access Private/Admin
const updateDomainManagerExpertise = async (req, res) => {
    try {
        const { domainExpertise } = req.body;
        const user = await User.findById(req.params.id);
        
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        
        if (user.role !== 'domain_manager') {
            return res.status(400).json({ message: "User is not a domain manager" });
        }
        
        user.domainExpertise = domainExpertise || [];
        await user.save();
        
        const updatedUser = await User.findById(req.params.id).select("-password");
        res.json({ message: "Domain manager expertise updated successfully", user: updatedUser });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Delete user by ID
// @route DELETE /api/users/:id
// @access Private/Admin


module.exports = {
    getUsers,
    getUserById,
    getDomainManagers,
    getUsersBySkills,
    searchUsers,
    updateUserSkills,
    updateDomainManagerExpertise,
};
