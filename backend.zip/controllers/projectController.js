const Project = require('../models/Project');
const Task = require('../models/Task');
const User = require('../models/User');

// @desc Create a new project
// @route POST /api/projects
// @access Private (Admin or Domain Manager)
const createProject = async (req, res) => {
    try {
        const {
            title,
            description,
            status,
            priority,
            startDate,
            endDate,
            dueDate,
            assignedUsers,
            assignedDomainManagers,
            projectManager,
            client,
            budget,
            requiredSkills,
            tags,
            category,
            isPublic,
            allowSelfAssignment
        } = req.body;

        // Validate required fields
        if (!title || !startDate || !endDate || !dueDate) {
            return res.status(400).json({ message: "Title, start date, end date, and due date are required" });
        }

        // Create new project
        const project = new Project({
            title,
            description,
            status,
            priority,
            startDate: new Date(startDate),
            endDate: new Date(endDate),
            dueDate: new Date(dueDate),
            assignedUsers: assignedUsers || [],
            assignedDomainManagers: assignedDomainManagers || [],
            projectManager,
            client,
            budget,
            requiredSkills: requiredSkills || [],
            tags: tags || [],
            category,
            isPublic: isPublic || false,
            allowSelfAssignment: allowSelfAssignment || false,
            createdBy: req.user._id
        });

        await project.save();

        // Populate user references
        const populatedProject = await Project.findById(project._id).populate([
            { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' },
            { path: 'createdBy', select: 'name email profileImageUrl' }
        ]);

        res.status(201).json({
            success: true,
            message: "Project created successfully",
            project: populatedProject
        });

    } catch (error) {
        console.error("Error creating project:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get all projects (with filtering)
// @route GET /api/projects
// @access Private
const getProjects = async (req, res) => {
    try {
        const { status, priority, assignedTo, search } = req.query;
        const userId = req.user._id;
        const userRole = req.user.role;

        let query = {};

        // Apply filters
        if (status) query.status = status;
        if (priority) query.priority = priority;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } },
                { client: { $regex: search, $options: 'i' } }
            ];
        }

        // Role-based access control
        if (userRole === 'admin') {
            // Admins can see all projects
        } else if (userRole === 'domain_manager') {
            // Domain managers can see projects they're assigned to or public projects
            query.$or = [
                { assignedDomainManagers: userId },
                { projectManager: userId },
                { isPublic: true }
            ];
        } else {
            // Regular users can only see projects they're assigned to or public projects
            query.$or = [
                { assignedUsers: userId },
                { isPublic: true }
            ];
        }

        const projects = await Project.find(query)
            .populate([
                { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
                { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
                { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' },
                { path: 'createdBy', select: 'name email profileImageUrl' }
            ])
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            projects,
            total: projects.length
        });

    } catch (error) {
        console.error("Error getting projects:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get project by ID
// @route GET /api/projects/:id
// @access Private
const getProjectById = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user._id;
        const userRole = req.user.role;

        const project = await Project.findById(id).populate([
            { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' },
            { path: 'createdBy', select: 'name email profileImageUrl' }
        ]);

        if (!project) {
            return res.status(404).json({ message: "Project not found" });
        }

        // Check access permissions
        const hasAccess = userRole === 'admin' || 
                         project.assignedUsers.includes(userId) ||
                         project.assignedDomainManagers.includes(userId) ||
                         project.projectManager === userId ||
                         project.isPublic;

        if (!hasAccess) {
            return res.status(403).json({ message: "Access denied to this project" });
        }

        // Get project tasks
        const tasks = await Task.find({ projectId: id })
            .populate([
                { path: 'assignedTo', select: 'name email profileImageUrl skills overallRating' },
                { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
                { path: 'createdBy', select: 'name email profileImageUrl' }
            ])
            .sort({ createdAt: -1 });

        // Calculate project statistics
        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(task => task.status === 'Completed').length;
        const totalChecklistItems = tasks.reduce((total, task) => total + task.todoCheckList.length, 0);
        const completedChecklistItems = tasks.reduce((total, task) => 
            total + task.todoCheckList.filter(item => item.completed).length, 0
        );

        // Update project statistics
        project.totalTasks = totalTasks;
        project.completedTasks = completedTasks;
        project.totalChecklistItems = totalChecklistItems;
        project.completedChecklistItems = completedChecklistItems;
        project.progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

        await project.save();

        res.json({
            success: true,
            project,
            tasks,
            statistics: {
                totalTasks,
                completedTasks,
                totalChecklistItems,
                completedChecklistItems,
                progress: project.progress
            }
        });

    } catch (error) {
        console.error("Error getting project:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Update project
// @route PUT /api/projects/:id
// @access Private (Admin or assigned Domain Manager)
const updateProject = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user._id;
        const userRole = req.user.role;

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({ message: "Project not found" });
        }

        // Check permissions
        const canEdit = userRole === 'admin' || 
                       project.assignedDomainManagers.includes(userId) ||
                       project.projectManager === userId;

        if (!canEdit) {
            return res.status(403).json({ message: "You don't have permission to edit this project" });
        }

        // Update project fields
        const updateFields = [
            'title', 'description', 'status', 'priority', 'startDate', 'endDate', 'dueDate',
            'assignedUsers', 'assignedDomainManagers', 'projectManager', 'client', 'budget',
            'requiredSkills', 'tags', 'category', 'isPublic', 'allowSelfAssignment'
        ];

        updateFields.forEach(field => {
            if (req.body[field] !== undefined) {
                if (field.includes('Date')) {
                    project[field] = new Date(req.body[field]);
                } else {
                    project[field] = req.body[field];
                }
            }
        });

        await project.save();

        const updatedProject = await Project.findById(id).populate([
            { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' },
            { path: 'createdBy', select: 'name email profileImageUrl' }
        ]);

        res.json({
            success: true,
            message: "Project updated successfully",
            project: updatedProject
        });

    } catch (error) {
        console.error("Error updating project:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Delete project
// @route DELETE /api/projects/:id
// @access Private (Admin only)
const deleteProject = async (req, res) => {
    try {
        const { id } = req.params;

        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: "Only admins can delete projects" });
        }

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({ message: "Project not found" });
        }

        // Check if project has tasks
        const taskCount = await Task.countDocuments({ projectId: id });
        if (taskCount > 0) {
            return res.status(400).json({ 
                message: "Cannot delete project with existing tasks. Please delete all tasks first." 
            });
        }

        await Project.findByIdAndDelete(id);

        res.json({
            success: true,
            message: "Project deleted successfully"
        });

    } catch (error) {
        console.error("Error deleting project:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Assign users to project
// @route PUT /api/projects/:id/assign-users
// @access Private (Admin or assigned Domain Manager)
const assignUsersToProject = async (req, res) => {
    try {
        const { id } = req.params;
        const { assignedUsers, assignedDomainManagers, projectManager } = req.body;
        const userId = req.user._id;
        const userRole = req.user.role;

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).json({ message: "Project not found" });
        }

        // Check permissions
        const canAssign = userRole === 'admin' || 
                         project.assignedDomainManagers.includes(userId) ||
                         project.projectManager === userId;

        if (!canAssign) {
            return res.status(403).json({ message: "You don't have permission to assign users to this project" });
        }

        // Update assignments
        if (assignedUsers !== undefined) {
            project.assignedUsers = assignedUsers;
        }
        if (assignedDomainManagers !== undefined) {
            project.assignedDomainManagers = assignedDomainManagers;
        }
        if (projectManager !== undefined) {
            project.projectManager = projectManager;
        }

        await project.save();

        const updatedProject = await Project.findById(id).populate([
            { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
            { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' }
        ]);

        res.json({
            success: true,
            message: "Users assigned to project successfully",
            project: updatedProject
        });

    } catch (error) {
        console.error("Error assigning users to project:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get user's projects
// @route GET /api/projects/user/my-projects
// @access Private
const getUserProjects = async (req, res) => {
    try {
        const userId = req.user._id;
        const userRole = req.user.role;

        let query = {};

        if (userRole === 'admin') {
            // Admins can see all projects
        } else if (userRole === 'domain_manager') {
            query.$or = [
                { assignedDomainManagers: userId },
                { projectManager: userId }
            ];
        } else {
            query.assignedUsers = userId;
        }

        const projects = await Project.find(query)
            .populate([
                { path: 'assignedUsers', select: 'name email profileImageUrl skills overallRating' },
                { path: 'assignedDomainManagers', select: 'name email profileImageUrl skills overallRating' },
                { path: 'projectManager', select: 'name email profileImageUrl skills overallRating' }
            ])
            .sort({ updatedAt: -1 });

        res.json({
            success: true,
            projects,
            total: projects.length
        });

    } catch (error) {
        console.error("Error getting user projects:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

module.exports = {
    createProject,
    getProjects,
    getProjectById,
    updateProject,
    deleteProject,
    assignUsersToProject,
    getUserProjects
};
