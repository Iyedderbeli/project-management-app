const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


// Generate JWT token
const generateToken = (userId) => {
    return jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
};
// @desc Register a new user
// @route POST /api/auth/register
// @access Public
const registerUser = async (req, res) => {
    try {
        const { name, email, password, profileImageUrl, adminInviteToken, skills } = req.body;
        
        //check if user exists
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: "User already exists" }); 
        }

        //Determine user role: Admin if correct token is provided, Domain Manager if domain manager token, otherwise User
        let role = "member";
        if (adminInviteToken && adminInviteToken === process.env.ADMIN_INVITE_TOKEN) {
            role = "admin";
        } else if (adminInviteToken && adminInviteToken === process.env.DOMAIN_MANAGER_INVITE_TOKEN) {
            role = "domain_manager";
        }

        //Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        
        //Create new user
        const user = new User({
            name,
            email,
            password: hashedPassword,
            profileImageUrl,
            role,
            skills: skills || [], // Include skills if provided
        });

        await user.save();

        //Return user data with JWT
        res.status(201).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            profileImageUrl: user.profileImageUrl,
            skills: user.skills,
            token: generateToken(user._id),
            
        });
    } catch (error) {
        console.error("Register error:", error.message);
        console.error(error.stack);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Login user
// @route POST /api/auth/login
// @access Public
const loginUser = async (req, res) => { 
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: "Invalid email or password" });
        }

        //Verify password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid email or password" });
        }
        //Return user data with JWT
        res.json({
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            profileImageUrl: user.profileImageUrl,
            skills: user.skills,
            token: generateToken(user._id),

        });

        
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

// @desc Get user profile
// @route GET /api/auth/profile
// @access Private(requires JWT)
const getProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json(user);
        
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
 };

// @desc Update user profile
// @route PUT /api/auth/profile
// @access Private(requires JWT)
const updateProfile = async (req, res) => {
    try {
        console.log("=== UPDATE PROFILE CALLED ===");
        console.log("User ID:", req.user.id);
        console.log("Request body:", req.body);
        
        const user= await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }
        
        console.log("Current user skills:", user.skills);
        
        // Update basic fields
        user.name = req.body.name || user.name;
        user.email = req.body.email || user.email;
        
        // Update profile image if provided
        if (req.body.profileImageUrl !== undefined) {
            user.profileImageUrl = req.body.profileImageUrl;
        }
        
        // Update skills if provided
        if (req.body.skills !== undefined) {
            console.log("Updating skills from:", user.skills, "to:", req.body.skills);
            user.skills = req.body.skills;
        }

        // Update password if provided
        if (req.body.newPassword) {
            // Verify current password if provided
            if (req.body.currentPassword) {
                const isMatch = await bcrypt.compare(req.body.currentPassword, user.password);
                if (!isMatch) {
                    return res.status(400).json({ message: "Current password is incorrect" });
                }
            }
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(req.body.newPassword, salt);
        }

        console.log("User before save:", {
            name: user.name,
            email: user.email,
            skills: user.skills,
            profileImageUrl: user.profileImageUrl
        });

        const updatedUser = await user.save();
        
        console.log("User after save:", {
            name: updatedUser.name,
            email: updatedUser.email,
            skills: updatedUser.skills,
            profileImageUrl: updatedUser.profileImageUrl
        });
        
        res.json({
            success: true,
            message: "Profile updated successfully",
            user: {
                _id: updatedUser._id,
                name: updatedUser.name,
                email: updatedUser.email,
                role: updatedUser.role,
                profileImageUrl: updatedUser.profileImageUrl,
                skills: updatedUser.skills,
                token: generateToken(updatedUser._id),
            }
        });
    } catch (error) {
        console.error("Update profile error:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
 };

module.exports = { registerUser, loginUser, getProfile, updateProfile };
