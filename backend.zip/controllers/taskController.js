const Task = require("../models/Task");
const User = require("../models/User"); // Added User model import
const Project = require("../models/Project"); // Added Project model import
const Message = require("../models/Message"); // Added Message model import


//@desc Get all tasks
//@route GET /api/tasks
//@access Private
const getTasks = async (req, res) => {
    try {
        const { status } = req.query;
        let filter = {};
        if (status) {
            filter.status = status;
        }
        let tasks;
        if (req.user.role === "admin") {
            // Admin can see all tasks
            tasks = await Task.find(filter).populate([
                { path: "assignedTo", select: "name email profileImageUrl" },
                { path: "assignedDomainManagers", select: "name email profileImageUrl" }
            ]);
        } else if (req.user.role === "domain_manager") {
            // Domain managers can only see tasks they're assigned to
            filter.assignedDomainManagers = req.user._id;
            tasks = await Task.find(filter).populate([
                { path: "assignedTo", select: "name email profileImageUrl" },
                { path: "assignedDomainManagers", select: "name email profileImageUrl" }
            ]);
        } else {
            // For regular users, only show tasks where ALL Deliverables Checklist items are approved by domain managers
            tasks = await Task.find({ 
                ...filter, 
                assignedTo: req.user._id,
                // Only show tasks where ALL Deliverables Checklist items are approved
                $expr: {
                    $and: [
                        { $in: [req.user._id, "$assignedTo"] },
                        {
                            $not: {
                                $anyElementTrue: {
                                    $map: {
                                        input: "$todoCheckList",
                                        as: "deliverable",
                                        in: {
                                            $eq: ["$$deliverable.approved", false]
                                        }
                                    }
                                }
                            }
                        }
                    ]
                }
            }).populate(
                "assignedTo",
                "name email profileImageUrl"
            );
        }

        //Add completed Deliverables Checklist count to each task
        tasks = await Promise.all(tasks.map(async (task) => {
            const completedCount = task.todoCheckList.filter(
                (item) => item.completed
            ).length;
            return { ...task._doc, completedTodoCount: completedCount };
        })
        );

        //Status summary counts
        let allTasks, pendingTasks, inProgressTasks, completedTasks;
        
        if (req.user.role === "admin") {
            // Admin can see all tasks
            allTasks = await Task.countDocuments();
            pendingTasks = await Task.countDocuments({ ...filter, status: "Pending" });
            inProgressTasks = await Task.countDocuments({ ...filter, status: "In Progress" });
            completedTasks = await Task.countDocuments({ ...filter, status: "Completed" });
        } else if (req.user.role === "domain_manager") {
            // Domain managers only see their assigned tasks
            const domainManagerFilter = { assignedDomainManagers: req.user._id };
            allTasks = await Task.countDocuments(domainManagerFilter);
            pendingTasks = await Task.countDocuments({ ...filter, ...domainManagerFilter, status: "Pending" });
            inProgressTasks = await Task.countDocuments({ ...filter, ...domainManagerFilter, status: "In Progress" });
            completedTasks = await Task.countDocuments({ ...filter, ...domainManagerFilter, status: "Completed" });
        } else {
            // Regular users only see their assigned tasks
            allTasks = await Task.countDocuments({ assignedTo: req.user._id });
            pendingTasks = await Task.countDocuments({ ...filter, assignedTo: req.user._id, status: "Pending" });
            inProgressTasks = await Task.countDocuments({ ...filter, assignedTo: req.user._id, status: "In Progress" });
            completedTasks = await Task.countDocuments({ ...filter, assignedTo: req.user._id, status: "Completed" });
        }

        res.json({
            tasks,
            statusSummary: {
                all: allTasks,
                pendingTasks,
                inProgressTasks,
                completedTasks,
            },
        });
        
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get task by ID
//@route GET /api/tasks/:id
//@access Private
const getTasksById = async (req, res) => {
    try {
        const task = await Task.findById(req.params.id).populate([
            { path: "assignedTo", select: "name email profileImageUrl" },
            { path: "assignedDomainManagers", select: "name email profileImageUrl" }
        ]);

        if (!task) return res.status(404).json({ message: "Task not found" });

        res.json(task);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Create a new Task
//@route POST /api/tasks
//@access Private (Domain Manager only)
const createTask = async (req, res) => {
    try {
        const {
            title,
            description,
            priority,
            dueDate,
            assignedTo,
            attachments,
            todoCheckList,
            projectId, // Required project ID
        } = req.body;

        // Validate required fields
        if (!projectId) {
            return res.status(400).json({ message: "projectId is required" });
        }

        if (!Array.isArray(assignedTo)) {
            return res.status(400).json({message:"assignedTo must be an array of user IDs" });
        }

        // Ensure all Deliverables Checklist items start as unapproved
        const processedTodoCheckList = todoCheckList.map(deliverable => ({
            ...deliverable,
            approved: false,
            rejected: false,
            completed: false
        }));

        const task = await Task.create({
            title,
            description,
            priority,
            dueDate,
            projectId, // Include project ID
            assignedTo,
            createdBy:req.user._id,
            todoCheckList: processedTodoCheckList,
            attachments,
            status: "Ready for Assignment", // New tasks start as ready for assignment
        });

        // Automatically assign users to the project
        try {
            const Project = require('../models/Project');
            const project = await Project.findById(projectId);
            
            if (project) {
                // Add new users to project if they're not already assigned
                const newUsers = assignedTo.filter(userId => 
                    !project.assignedUsers.includes(userId)
                );
                
                if (newUsers.length > 0) {
                    project.assignedUsers = [...new Set([...project.assignedUsers, ...newUsers])];
                    await project.save();
                    
                    console.log(`Automatically assigned ${newUsers.length} users to project: ${project.title} via task creation`);
                }
            }
        } catch (projectError) {
            console.error("Error auto-assigning users to project:", projectError);
            // Don't fail the task creation if project assignment fails
        }

        res.status(201).json({ message:"Task created successfully", task });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Update Task details
//@route PUT /api/tasks/:id
//@access Private
const updateTask = async (req, res) => {
    try {
        const task = await Task.findById(req.params.id);

        if (!task) return res.status(404).json({ message: "Task not found" });
        
        task.title = req.body.title || task.title;
        task.description = req.body.description || task.description;
        task.priority = req.body.priority || task.priority;
        task.dueDate = req.body.dueDate || task.dueDate;
        task.todoCheckList = req.body.todoCheckList || task.todoCheckList;
        task.attachments = req.body.attachments || task.attachments;

        if (req.body.assignedTo) {
            if (!Array.isArray(req.body.assignedTo)) {
                return res.status(400).json({ message: "assignedTo must be an array of user IDs" });   
            }
            task.assignedTo = req.body.assignedTo;
        }

        const updatedTask = await task.save();
        res.json({message:"Task updated successfully", updatedTask});

    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Delete a Task (Admin Only)
//@route DELETE /api/tasks/:id
//@access Private (Admin)
const deleteTask = async (req, res) => {
    try {
        const task = await Task.findById(req.params.id);
        
        if (!task) return res.status(404).json({ message: "Task not found" });

        await task.deleteOne();
        res.json({ message: "Task deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Update Task status
//@route PUT /api/tasks/:id/status
//@access Private
const updateTaskStatus = async (req, res) => {
    try {
        const task = await Task.findById(req.params.id);
        if (!task) return res.status(404).json({ message: "Task not found" });

        const isAssigned = task.assignedTo.some(
            (userId) => userId.toString() === req.user._id.toString()
        );

        if (!isAssigned && req.user.role !== "admin") {
            return res.status(403).json({ message: " Not Authorized" });

        }

        task.status = req.body.status || task.status;

        if (task.status === "Completed") {
            task.todoCheckList.forEach((item) => (item.completed = true));
            task.progress = 100;
        }

        await task.save();
        res.json({ message: "Task status updated successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};


//@desc Update Task Deliverables Checklist
//@route PUT /api/tasks/:id/todo
//@access Private
const updateTaskChecklist = async (req, res) => {
  try {
    const { todoCheckList } = req.body;

    // Validate Deliverables Checklist structure
    if (!Array.isArray(todoCheckList)) {
      return res
        .status(400)
        .json({ message: "todoCheckList must be an array" });
    }
    for (const [i, item] of todoCheckList.entries()) {
      if (
        typeof item.text !== "string" ||
        typeof item.completed !== "boolean"
      ) {
        return res.status(400).json({
          message: `Each Deliverables Checklist item must have 'text' (string) and 'completed' (boolean). Error at index ${i}.`,
          item,
        });
      }
      
      // Users can only complete Deliverables Checklist items that are approved by domain managers
      if (item.completed && !item.approved) {
        return res.status(400).json({
          message: `Cannot complete Deliverables Checklist item that is not approved by domain manager. Error at index ${i}.`,
          item,
        });
      }
      
      // Require description when completing a Deliverables Checklist item
      if (item.completed && (!item.description || item.description.trim() === "")) {
        return res.status(400).json({
          message: `Description is required when completing a Deliverables Checklist item. Error at index ${i}.`,
          item,
        });
      }
    }

    const task = await Task.findById(req.params.id);

    if (!task) return res.status(404).json({ message: "Task not found" });

    // Proper ObjectId comparison
    const isAssigned =
      task.assignedTo.toString() === req.user._id.toString() ||
      (Array.isArray(task.assignedTo) &&
        task.assignedTo.some(
          (userId) => userId.toString() === req.user._id.toString()
        ));

    if (!isAssigned && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not Authorized" });
    }

    task.todoCheckList = todoCheckList; // Replace with updated Deliverables Checklist

    // Auto-update progress based on Deliverables Checklist completion
    const completedCount = task.todoCheckList.filter(
      (item) => item.completed
    ).length;
    const totalItems = task.todoCheckList.length;
    task.progress =
      totalItems > 0 ? Math.round((completedCount / totalItems) * 100) : 0;

    // Check if all Deliverables Checklist items are completed
    const allCompleted = task.todoCheckList.every(item => item.completed);
    
    if (allCompleted) {
      task.status = "Completed";
    } else if (task.progress > 0) {
      task.status = "In Progress";
    } else {
      task.status = "Pending";
    }

    await task.save();
    const updatedTask = await Task.findById(req.params.id).populate(
      "assignedTo",
      "name email profileImageUrl"
    );

    res.json({ message: "Task Deliverables Checklist updated", task: updatedTask });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};


//@desc Dashboard Data (Admin Only)
//@route GET /api/tasks/dashboard-data
//@access Private
const getDashboardData = async (req, res) => {
    try {
        // Fetch statistics
        const totalTasks = await Task.countDocuments();
        const pendingTasks=await Task.countDocuments({ status: "Pending" });
        const completedTasks = await Task.countDocuments({ status: "Completed" });
        const overdueTasks = await Task.countDocuments({
            status: { $ne: "Completed" },
            dueDate: { $lt: new Date() },
        });

        // Ensure all possible status are included
        const taskStatuses = ["Pending", "In Progress", "Completed"];
        taskDistributionRaw = await Task.aggregate([
            {
                $group: {
                    _id: "$status",
                    count: { $sum: 1 },
                },
            },
        ]);
        taskDistribution = taskStatuses.reduce((acc, status) => { 
            const formattedKey = status.replace(/\s+/g, ""); // Remove spaces for respnse keys
            acc[formattedKey] =
                taskDistributionRaw.find((item) => item._id === status)?.count || 0;// Get count for each status
            return acc;
            }, {});
        taskDistribution["All"] = totalTasks;// Add total count to taskDistribution
        
        // Ensure all priority levels are included
        const taskPriorities = ["Low", "Medium", "High"];

        const taskPriorityLevelsRaw = await Task.aggregate([
        {
            $group: {
                _id: "$priority",
                count: { $sum: 1 },
            },
        },
        ]);

        const taskPriorityLevels = taskPriorities.reduce((acc, priority) => {
            acc[priority] =
                taskPriorityLevelsRaw.find((item) => item._id === priority)?.count || 0;
            return acc;
        }, {});

        //Fetch recent 10 tasks
        const recentTasks = await Task.find()
            .sort({ createdAt: -1 })
            .limit(10)
            .select("title status priority dueDate createdAt");
        res.status(200).json({
            statistics: {
                totalTasks,
                pendingTasks,
                completedTasks,
                overdueTasks,
            },
            charts: {
                taskDistribution,
                taskPriorityLevels,
            },
            recentTasks,
            
        });


    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Dashboard Data (User-specific)
//@route GET /api/tasks/user-dashboard-data
//@access Private
const getUserDashboardData = async (req, res) => {
    try {
        const userId = req.user._id; // Only fetch data for the logged-in user

        // Fetch statistics for user-specific tasks
        const totalTasks = await Task.countDocuments({ assignedTo: userId });
        const pendingTasks = await Task.countDocuments({ assignedTo: userId, status: "Pending" });
        const completedTasks = await Task.countDocuments({ assignedTo: userId, status: "Completed" });
        const overdueTasks = await Task.countDocuments({
            assignedTo: userId,
            dueDate: { $lt: new Date() },
            status: { $ne: "Completed" },
        });

        //Task Distribution by status
        const taskStatuses = ["Pending", "In Progress", "Completed"];
        const taskDistributionRaw = await Task.aggregate([
            { $match: { assignedTo: userId } },
            { $group: { _id: "$status", count: { $sum: 1 } } },
        ]);

        const taskDistribution = taskStatuses.reduce((acc, status) => {
            const formattedKey = status.replace(/\s+/g, "");// Remove spaces from status names
            acc[formattedKey] = taskDistributionRaw.find((item) => item._id === status)?.count || 0;// Get count for each status
            return acc;
        }, {});
        taskDistribution["All"] = totalTasks;

        // Task distribution by priority
        const taskPriorities = ["Low", "Medium", "High"];
        const taskPriorityLevelsRaw = await Task.aggregate([
            { $match: { assignedTo: userId } },
            { $group: { _id: "$priority", count: { $sum: 1 } } },
        ]);
        
        const taskPriorityLevels = taskPriorities.reduce((acc, priority) => {
            acc[priority] = taskPriorityLevelsRaw.find((item) => item._id === priority)?.count || 0;// Get count for each priority
            return acc;
        }, {});

        //Fetch recent 10 tasks for the logged-in user
        const recentTasks = await Task.find({ assignedTo: userId })
            .sort({ createdAt: -1 })
            .limit(10)
            .select("title status priority dueDate createdAt");
        
        res.status(200).json({
            statistics: {
                totalTasks,
                pendingTasks,
                completedTasks,
                overdueTasks,
            },
            charts: {
                taskDistribution,
                taskPriorityLevels,
            },
            recentTasks,
        });
        
            
    } catch (error) {
        res.status(500).json({ message:"Server error", error: error.message });
    }
}

//@desc Dashboard Data (Domain Manager-specific)
//@route GET /api/tasks/domain-manager-dashboard-data
//@access Private (Domain Manager)
const getDomainManagerDashboardData = async (req, res) => {
    try {
        const domainManagerId = req.user._id; // Only fetch data for the logged-in domain manager

        // Fetch statistics for domain manager-specific tasks
        const totalTasks = await Task.countDocuments({ assignedDomainManagers: domainManagerId });
        const pendingTasks = await Task.countDocuments({ assignedDomainManagers: domainManagerId, status: "Pending" });
        const completedTasks = await Task.countDocuments({ assignedDomainManagers: domainManagerId, status: "Completed" });
        const overdueTasks = await Task.countDocuments({
            assignedDomainManagers: domainManagerId,
            dueDate: { $lt: new Date() },
            status: { $ne: "Completed" },
        });

        //Task Distribution by status
        const taskStatuses = ["Pending", "In Progress", "Completed"];
        const taskDistributionRaw = await Task.aggregate([
            { $match: { assignedDomainManagers: domainManagerId } },
            { $group: { _id: "$status", count: { $sum: 1 } } },
        ]);

        const taskDistribution = taskStatuses.reduce((acc, status) => {
            const formattedKey = status.replace(/\s+/g, "");// Remove spaces from status names
            acc[formattedKey] = taskDistributionRaw.find((item) => item._id === status)?.count || 0;// Get count for each status
            return acc;
        }, {});
        taskDistribution["All"] = totalTasks;

        // Task distribution by priority
        const taskPriorities = ["Low", "Medium", "High"];
        const taskPriorityLevelsRaw = await Task.aggregate([
            { $match: { assignedDomainManagers: domainManagerId } },
            { $group: { _id: "$priority", count: { $sum: 1 } } },
        ]);
        
        const taskPriorityLevels = taskPriorities.reduce((acc, priority) => {
            acc[priority] = taskPriorityLevelsRaw.find((item) => item._id === priority)?.count || 0;// Get count for each priority
            return acc;
        }, {});

        // Task approval status distribution
        const taskApprovalStatusRaw = await Task.aggregate([
            { $match: { assignedDomainManagers: domainManagerId } },
            {
                $addFields: {
                    approvalStatus: {
                        $cond: {
                            if: { $eq: [{ $size: "$todoCheckList" }, 0] },
                            then: "Waiting for Approval",
                            else: {
                                                        $cond: {
                            if: { $allElementsTrue: "$todoCheckList.approved" },
                            then: "Approved",
                            else: {
                                $cond: {
                                    if: { $anyElementTrue: "$todoCheckList.approved" },
                                    then: "Partially Approved",
                                    else: "Not Approved"
                                }
                            }
                        }
                            }
                        }
                    }
                }
            },
            { $group: { _id: "$approvalStatus", count: { $sum: 1 } } },
        ]);

        const taskApprovalStatuses = ["Approved", "Partially Approved", "Not Approved", "Waiting for Approval"];
        const taskApprovalStatus = taskApprovalStatuses.reduce((acc, status) => {
            const formattedKey = status.replace(/\s+/g, ""); // Remove spaces from status names
            acc[formattedKey] = taskApprovalStatusRaw.find((item) => item._id === status)?.count || 0;
            return acc;
        }, {});

        //Fetch recent 10 tasks for the logged-in domain manager
        const recentTasks = await Task.find({ assignedDomainManagers: domainManagerId })
            .sort({ createdAt: -1 })
            .limit(10)
            .select("title status priority dueDate createdAt");
        
        res.status(200).json({
            statistics: {
                totalTasks,
                pendingTasks,
                completedTasks,
                overdueTasks,
            },
            charts: {
                taskDistribution,
                taskPriorityLevels,
                taskApprovalStatus,
            },
            recentTasks,
        });
        
            
    } catch (error) {
        res.status(500).json({ message:"Server error", error: error.message });
    }
};

//@desc Approve Deliverables Checklist item (Domain Manager only)
//@route PUT /api/tasks/:id/todo/:todoIndex/approve
//@access Private (Domain Manager)
const approveTodoItem = async (req, res) => {
    try {
        const { id, todoIndex } = req.params;
        const task = await Task.findById(id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Convert todoIndex to number
        const index = parseInt(todoIndex);
        
        if (isNaN(index) || index < 0 || index >= task.todoCheckList.length) {
            return res.status(404).json({ message: "Deliverables Checklist item not found" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        // Update the Deliverables Checklist item approval status
        task.todoCheckList[index].approved = true;
        task.todoCheckList[index].approvedBy = req.user._id;
        task.todoCheckList[index].approvedAt = new Date();
        task.todoCheckList[index].rejected = false;
        task.todoCheckList[index].rejectionFeedback = null;

        // Create notification for assigned users
        if (task.todoCheckList[index].assignedUsers && task.todoCheckList[index].assignedUsers.length > 0) {
          for (const userId of task.todoCheckList[index].assignedUsers) {
            const notification = {
              type: "checklist_item_approved",
              message: `Your checklist item "${task.todoCheckList[index].text}" in task "${task.title}" has been approved`,
              fromUser: req.user._id,
              toUser: userId,
              createdAt: new Date(),
              read: false
            };
            
            task.notifications.push(notification);
          }
        }

        await task.save();
        
        const updatedTask = await Task.findById(id).populate(
            "assignedTo",
            "name email profileImageUrl"
        );

        res.json({ 
            message: "Deliverables Checklist item approved successfully", 
            task: updatedTask 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Reject Deliverables Checklist item (Domain Manager only)
//@route PUT /api/tasks/:id/todo/:todoIndex/reject
//@access Private (Domain Manager)
const rejectTodoItem = async (req, res) => {
    try {
        const { id, todoIndex } = req.params;
        const { feedback } = req.body;
        
        if (!feedback || feedback.trim() === "") {
            return res.status(400).json({ message: "Feedback is required for rejection" });
        }

        const task = await Task.findById(id).populate("createdBy");
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }
        
        // Add more detailed error handling
        try {
            // Validate task structure
            if (!task.todoCheckList || !Array.isArray(task.todoCheckList)) {
                console.error("Task todoCheckList is missing or not an array:", task.todoCheckList);
                return res.status(500).json({ message: "Task structure is invalid" });
            }
            
            // Ensure notifications array exists
            if (!task.notifications) {
                task.notifications = [];
            }
        } catch (validationError) {
            console.error("Validation error:", validationError);
            return res.status(500).json({ message: "Task validation failed", error: validationError.message });
        }



        // Convert todoIndex to number
        const index = parseInt(todoIndex);
        
        if (isNaN(index) || index < 0 || index >= task.todoCheckList.length) {
            return res.status(404).json({ message: "Deliverables Checklist item not found" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        // Update the Deliverables Checklist item rejection status
        task.todoCheckList[index].rejected = true;
        task.todoCheckList[index].rejectionFeedback = feedback;
        task.todoCheckList[index].rejectedBy = req.user._id;
        task.todoCheckList[index].rejectedAt = new Date();
        task.todoCheckList[index].approved = false;
        task.todoCheckList[index].approvedBy = null;
        task.todoCheckList[index].approvedAt = null;

        // Create notification for admin about the rejected checklist item
        const adminNotification = {
            type: "checklist_rejection",
            message: `Domain Manager ${req.user.name || "Unknown"} rejected checklist item "${task.todoCheckList[index].text}" with feedback: ${feedback}`,
            fromUser: req.user._id,
            toUser: task.createdBy._id,
            todoIndex: index,
            rejectionFeedback: feedback
        };

        // Create notification for assigned users about the rejected checklist item
        const userNotifications = [];
        if (task.todoCheckList[index].assignedUsers && task.todoCheckList[index].assignedUsers.length > 0) {
          for (const userId of task.todoCheckList[index].assignedUsers) {
            const userNotification = {
              type: "checklist_item_rejected",
              message: `Your checklist item "${task.todoCheckList[index].text}" in task "${task.title}" was rejected. Feedback: ${feedback}`,
              fromUser: req.user._id,
              toUser: userId,
              createdAt: new Date(),
              read: false
            };
            userNotifications.push(userNotification);
          }
        }
        
        if (!task.createdBy || !task.createdBy._id) {
            console.error("Task createdBy is not properly populated");
            return res.status(500).json({ message: "Task creator information is missing" });
        }
        
        // Ensure notifications array exists
        if (!task.notifications) {
            task.notifications = [];
        }
        
        // Add notifications to task
        task.notifications.push(adminNotification);
        
        // Add user notifications
        for (const userNotification of userNotifications) {
          task.notifications.push(userNotification);
        }

        // Save the task first to get the notification ID
        try {
            await task.save();
        } catch (saveError) {
            console.error("Error saving task:", saveError);
            return res.status(500).json({ message: "Failed to save task", error: saveError.message });
        }
        
        // Get the notification ID from the saved task
        let savedNotification;
        try {
            const taskWithNotification = await Task.findById(id);
            savedNotification = taskWithNotification.notifications[taskWithNotification.notifications.length - 1];
            
            if (!savedNotification || !savedNotification._id) {
                console.error("Failed to save notification properly");
                return res.status(500).json({ message: "Failed to create notification" });
            }
        } catch (retrieveError) {
            console.error("Error retrieving task with notification:", retrieveError);
            return res.status(500).json({ message: "Failed to retrieve notification", error: retrieveError.message });
        }

        // Create a message for the admin about the rejection
        try {
            const Message = require('../models/Message');
            const rejectionMessage = new Message({
                fromUser: req.user._id,
                toUser: task.createdBy._id,
                message: `I have rejected the checklist item "${task.todoCheckList[index].text}" for task "${task.title}". Feedback: ${feedback}`,
                taskId: task._id,
                notificationId: savedNotification._id // Use the saved notification ID
            });
            
            await rejectionMessage.save();
        } catch (messageError) {
            console.error("Error saving rejection message:", messageError);
            // Don't fail the entire operation if message saving fails
        }
        
                // Get the updated task with populated data
        try {
        const updatedTask = await Task.findById(id).populate(
            "assignedTo",
            "name email profileImageUrl"
        );

        res.json({ 
            message: "Deliverables Checklist item rejected successfully", 
            task: updatedTask 
        });
        } catch (finalRetrieveError) {
            console.error("Error retrieving final task:", finalRetrieveError);
            return res.status(500).json({ message: "Failed to retrieve final task", error: finalRetrieveError.message });
        }
    } catch (error) {
        console.error("Error in rejectTodoItem:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Rate task quality and time (Domain Manager only)
//@route PUT /api/tasks/:id/rate
//@access Private (Domain Manager)
const rateTask = async (req, res) => {
    try {
        const { id } = req.params;
        const { qualityRating, timeRating, reviewNotes } = req.body;
        
        const task = await Task.findById(id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }
        
        // Check if the task is completed before allowing rating
        if (task.status !== "Completed") {
            return res.status(400).json({ message: "Task must be completed before it can be rated" });
        }

        // Validate ratings
        if (qualityRating && (qualityRating < 1 || qualityRating > 5)) {
            return res.status(400).json({ message: "Quality rating must be between 1 and 5" });
        }

        if (timeRating && (timeRating < 1 || timeRating > 5)) {
            return res.status(400).json({ message: "Time rating must be between 1 and 5" });
        }

        // Update task ratings
        if (qualityRating !== undefined) task.qualityRating = qualityRating;
        if (timeRating !== undefined) task.timeRating = timeRating;
        if (reviewNotes !== undefined) task.reviewNotes = reviewNotes;
        
        task.ratedBy = req.user._id;
        task.ratedAt = new Date();

        await task.save();
        
        const updatedTask = await Task.findById(id).populate(
            "assignedTo",
            "name email profileImageUrl"
        );

        res.json({ 
            message: "Task rated successfully", 
            task: updatedTask 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get tasks pending approval (Domain Manager only)
//@route GET /api/tasks/pending-approval
//@access Private (Domain Manager)
const getTasksPendingApproval = async (req, res) => {
  try {
    // First, get all tasks assigned to this domain manager (regardless of status)
    const tasks = await Task.find({ 
      assignedDomainManagers: req.user._id
    }).populate("assignedTo", "name email profileImageUrl");



    const filteredTasks = [];

    console.log(`Found ${tasks.length} tasks assigned to domain manager ${req.user._id}`);
    
    if (tasks.length === 0) {
      console.log("No tasks found for this domain manager");
      console.log("User ID:", req.user._id);
      console.log("User role:", req.user.role);
    }

    tasks.forEach(task => {
      // Ensure todoCheckList is an array
      if (!Array.isArray(task.todoCheckList)) {
        console.log(`Task ${task._id} has no todoCheckList or it's not an array`);
        return;
      }

      console.log(`Task ${task._id} has ${task.todoCheckList.length} todo items`);

      // Check if any deliverable is completed but not approved and not rejected
      const hasUnapprovedDeliverable = task.todoCheckList.some(deliverable => {
        // Ensure deliverable is a valid object
        if (!deliverable || typeof deliverable !== 'object') {
          return false;
        }
        
        // Check if deliverable is completed but not approved and not rejected
        const isCompleted = deliverable.completed === true;
        const isNotApproved = deliverable.approved !== true;
        const isNotRejected = deliverable.rejected !== true;
        
        if (isCompleted && isNotApproved && isNotRejected) {
          console.log(`Found unapproved deliverable in task ${task._id}:`, deliverable);
        }
        
        return isCompleted && isNotApproved && isNotRejected;
      });

      if (hasUnapprovedDeliverable) {
        console.log(`Task ${task._id} has unapproved deliverables, adding to filtered list`);
        filteredTasks.push(task);
      } else {
        console.log(`Task ${task._id} has no unapproved deliverables`);
      }
    });

    console.log(`Returning ${filteredTasks.length} tasks with pending approvals`);


    res.status(200).json(filteredTasks);
  } catch (error) {
    console.error("Error in getTasksPendingApproval:", error);
    console.error("Error stack:", error.stack);
    res.status(500).json({ message: "Failed to fetch tasks pending approval", error: error.message });
  }
};



//@desc Get tasks pending rating (Domain Manager only)
//@route GET /api/tasks/pending-rating
//@access Private (Domain Manager)
const getTasksPendingRating = async (req, res) => {
    try {
        const tasks = await Task.find({
            $and: [
                { status: "Completed" },
                { assignedDomainManagers: req.user._id },
                {
                    $or: [
                        { qualityRating: { $exists: false } },
                        { qualityRating: null },
                        { timeRating: { $exists: false } },
                        { timeRating: null }
                    ]
                }
            ]
        }).populate("assignedTo", "name email profileImageUrl");

        res.json(tasks);
    } catch (error) {
        console.error("Error in getTasksPendingRating:", error); // Add this for debugging
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Assign users to specific checklist item (Domain Manager only)
//@route PUT /api/tasks/:id/todo/:todoIndex/assign-users
//@access Private (Domain Manager)
const assignUsersToChecklistItem = async (req, res) => {
    try {
        const { id, todoIndex } = req.params;
        const { assignedUsers } = req.body;
        
        if (!Array.isArray(assignedUsers)) {
            return res.status(400).json({ message: "assignedUsers must be an array of user IDs" });
        }

        const task = await Task.findById(id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Convert todoIndex to number
        const index = parseInt(todoIndex);
        
        if (isNaN(index) || index < 0 || index >= task.todoCheckList.length) {
            return res.status(404).json({ message: "Checklist item not found" });
        }

        // Only domain managers can assign users to checklist items
        if (req.user.role !== "domain_manager") {
            return res.status(403).json({ message: "Only domain managers can assign users to checklist items" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        // Update the specific checklist item with assigned users
        task.todoCheckList[index].assignedUsers = assignedUsers;

        // Create notifications for assigned users
        for (const userId of assignedUsers) {
          const notification = {
            type: "checklist_item_assigned",
            message: `You have been assigned to checklist item "${task.todoCheckList[index].text}" in task "${task.title}"`,
            fromUser: req.user._id,
            toUser: userId,
            createdAt: new Date(),
            read: false
          };
          
          task.notifications.push(notification);
        }

        await task.save();
        
        // Automatically assign users to the project
        if (task.projectId) {
            try {
                const Project = require('../models/Project');
                const project = await Project.findById(task.projectId);
                
                if (project) {
                    // Add new users to project if they're not already assigned
                    const newUsers = assignedUsers.filter(userId => 
                        !project.assignedUsers.includes(userId)
                    );
                    
                    if (newUsers.length > 0) {
                        project.assignedUsers = [...new Set([...project.assignedUsers, ...newUsers])];
                        await project.save();
                        
                        console.log(`Automatically assigned ${newUsers.length} users to project: ${project.title} via checklist item assignment`);
                    }
                }
            } catch (projectError) {
                console.error("Error auto-assigning users to project:", projectError);
                // Don't fail the checklist assignment if project assignment fails
            }
        }
        
        const updatedTask = await Task.findById(id).populate([
            { path: "todoCheckList.assignedUsers", select: "name email profileImageUrl skills overallRating" },
            { path: "assignedDomainManagers", select: "name email profileImageUrl" },
            { path: "projectId", select: "title status" }
        ]);

        res.json({ 
            message: "Users assigned to checklist item successfully", 
            task: updatedTask 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get users suitable for checklist item based on skills
//@route GET /api/tasks/:id/todo/:todoIndex/suitable-users
//@access Private (Domain Manager)
const getSuitableUsersForChecklistItem = async (req, res) => {
    try {
        const { id, todoIndex } = req.params;
        
        const task = await Task.findById(id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Convert todoIndex to number
        const index = parseInt(todoIndex);
        
        if (isNaN(index) || index < 0 || index >= task.todoCheckList.length) {
            return res.status(404).json({ message: "Checklist item not found" });
        }

        // Only domain managers can get suitable users
        if (req.user.role !== "domain_manager") {
            return res.status(403).json({ message: "Only domain managers can get suitable users" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        const requiredSkills = task.todoCheckList[index].requiredSkills || [];
        
        // Get users with matching skills, sorted by rating
        let query = { role: { $in: ['member', 'user'] } };
        
        if (requiredSkills.length > 0) {
            query['skills.name'] = { $in: requiredSkills };
        }
        
        const users = await User.find(query)
            .select("-password")
            .sort({ overallRating: -1 });
        
        // Sort by skill match and rating
        const sortedUsers = users.map(user => {
            const skillMatchScore = requiredSkills.length > 0 
                ? user.skills.filter(skill => requiredSkills.includes(skill.name)).length / requiredSkills.length
                : 0;
            
            return {
                ...user._doc,
                skillMatchScore,
                matchedSkills: user.skills.filter(skill => requiredSkills.includes(skill.name))
            };
        }).sort((a, b) => {
            // Sort by skill match first, then by overall rating
            if (a.skillMatchScore !== b.skillMatchScore) {
                return b.skillMatchScore - a.skillMatchScore;
            }
            return b.overallRating - a.overallRating;
        });
        
        res.json(sortedUsers);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Complete individual checklist item (User only)
//@route PUT /api/tasks/:id/todo/:todoIndex/complete
//@access Private (Assigned users only)
const completeChecklistItem = async (req, res) => {
  try {
    const { description } = req.body;
    const { id: taskId, todoIndex } = req.params;

    if (!description || description.trim() === "") {
      return res.status(400).json({
        message: "Description is required when completing a checklist item"
      });
    }

    const task = await Task.findById(taskId);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Check if user is assigned to this task
    const isAssigned = task.assignedTo.some(
      (userId) => userId.toString() === req.user._id.toString()
    );

    if (!isAssigned && req.user.role !== "admin") {
      return res.status(403).json({ 
        message: "You are not assigned to this task" 
      });
    }

    // Check if checklist item exists
    if (todoIndex < 0 || todoIndex >= task.todoCheckList.length) {
      return res.status(404).json({ 
        message: "Checklist item not found" 
      });
    }

    const checklistItem = task.todoCheckList[todoIndex];

    // Check if item is already completed
    if (checklistItem.completed) {
      return res.status(400).json({ 
        message: "This checklist item is already completed" 
      });
    }

    // Check if item is approved by domain manager
    if (!checklistItem.approved) {
      return res.status(400).json({ 
        message: "Cannot complete checklist item that is not approved by domain manager" 
      });
    }
    
    // Check if the checklist item was approved by a domain manager assigned to this task
    if (checklistItem.approvedBy && !task.assignedDomainManagers.includes(checklistItem.approvedBy)) {
      return res.status(400).json({ 
        message: "Cannot complete checklist item that was not approved by an assigned domain manager" 
      });
    }

    // Complete the checklist item
    checklistItem.completed = true;
    checklistItem.description = description.trim();
    checklistItem.completedBy = req.user._id;
    checklistItem.completedAt = new Date();

    // Update task progress
    const completedCount = task.todoCheckList.filter(item => item.completed).length;
    const totalItems = task.todoCheckList.length;
    task.progress = totalItems > 0 ? Math.round((completedCount / totalItems) * 100) : 0;

            // Update task status if all items are completed
        const allCompleted = task.todoCheckList.every(item => item.completed);
        if (allCompleted) {
          task.status = "Completed";
          // When task is completed, add a notification for domain managers to rate it
          if (!task.notifications) {
            task.notifications = [];
          }
          
          // Create notification for domain managers to rate the completed task
          const ratingNotification = {
            type: "task_completed_for_rating",
            message: `Task "${task.title}" has been completed and is ready for rating`,
            fromUser: req.user._id,
            toUser: null, // Will be sent to all assigned domain managers
            createdAt: new Date(),
            read: false
          };
          
          task.notifications.push(ratingNotification);

          // Create notification for the user who completed the item
          const userNotification = {
            type: "task_completed",
            message: `You completed a checklist item in task "${task.title}"`,
            fromUser: req.user._id,
            toUser: req.user._id,
            createdAt: new Date(),
            read: false
          };
          
          task.notifications.push(userNotification);
        } else if (task.progress > 0) {
          task.status = "In Progress";
        }

    await task.save();

    // Populate the updated task
    const updatedTask = await Task.findById(taskId)
      .populate("assignedTo", "name email profileImageUrl")
      .populate("createdBy", "name email profileImageUrl");

    res.json({
      message: "Checklist item completed successfully",
      task: updatedTask
    });

  } catch (error) {
    console.error("Error completing checklist item:", error);
    res.status(500).json({ 
      message: "Server error", 
      error: error.message 
    });
  }
};

//@desc Rate user performance on checklist item completion
//@route PUT /api/tasks/:id/todo/:todoIndex/rate-user
//@access Private (Domain Manager)
const rateUserPerformance = async (req, res) => {
    try {
        const { id, todoIndex } = req.params;
        const { userId, rating, feedback } = req.body;
        

        
        if (!userId || !rating || rating < 1 || rating > 5) {
            return res.status(400).json({ message: "Valid userId and rating (1-5) are required" });
        }

        const task = await Task.findById(id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Convert todoIndex to number
        const index = parseInt(todoIndex);
        
        if (isNaN(index) || index < 0 || index >= task.todoCheckList.length) {
            return res.status(404).json({ message: "Checklist item not found" });
        }



        // Check if the user is a domain manager or if they are rating their own completed task
        const checklistItem = task.todoCheckList[index];
        const isDomainManager = req.user.role === "domain_manager";
        const isRatingOwnTask = checklistItem.completedBy && checklistItem.completedBy.toString() === req.user._id.toString();
        
        if (!isDomainManager && !isRatingOwnTask) {
            return res.status(403).json({ 
                message: "You can only rate tasks that you have completed, or you must be a domain manager" 
            });
        }
        
        // If it's a domain manager, check if they're assigned to this task
        if (isDomainManager && !task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ 
                message: "You are not assigned to this task" 
            });
        }
        
        // For domain managers, ensure the specific checklist item being rated is completed
        const specificItemCompleted = task.todoCheckList[index].completed;
        if (isDomainManager && !specificItemCompleted) {
            return res.status(400).json({ 
                message: "This checklist item must be completed before user performance can be rated" 
            });
        }

        // Determine which user to update the rating for
        let targetUserId = userId;

        // For domain managers, ensure the user being rated is assigned to this specific checklist item
        if (isDomainManager) {
            // Check both possible field names for assigned users
            const itemAssignedUsers = task.todoCheckList[index].assignedTo || 
                                    task.todoCheckList[index].assignedUsers || [];
            
            // Convert all IDs to strings for comparison
            const itemAssignedUsersStrings = itemAssignedUsers.map(id => id.toString());
            const targetUserIdString = targetUserId.toString();
            
            if (!itemAssignedUsersStrings.includes(targetUserIdString)) {
                return res.status(400).json({ 
                    message: "This user is not assigned to the checklist item being rated" 
                });
            }
        }

        // Update user's overall rating
        const user = await User.findById(targetUserId);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // Calculate new overall rating (simple average for now)
        const currentRating = user.overallRating || 0;
        const newRating = (currentRating + rating) / 2;
        user.overallRating = Math.round(newRating * 10) / 10; // Round to 1 decimal

        try {
            await user.save();
        } catch (error) {
            console.error("Error saving user:", error);
            return res.status(500).json({ message: "Error updating user rating", error: error.message });
        }

        // Add rating feedback to the checklist item
        if (!task.todoCheckList[index].userRatings) {
            task.todoCheckList[index].userRatings = [];
        }
        
        task.todoCheckList[index].userRatings.push({
            userId: targetUserId,
            rating: rating,
            feedback: feedback || "",
            ratedBy: req.user._id,
            ratedAt: new Date()
        });

        try {
            await task.save();
        } catch (error) {
            console.error("Error saving task:", error);
            return res.status(500).json({ message: "Error updating task rating", error: error.message });
        }

        // Send feedback message to the rated user if feedback is provided
        if (feedback && feedback.trim() && !isRatingOwnTask) {
            try {
                const feedbackMessage = new Message({
                    fromUser: req.user._id,
                    toUser: targetUserId,
                    message: `Performance Feedback: ${feedback}`,
                    taskId: id
                });

                await feedbackMessage.save();
                console.log(`Feedback message sent to user ${targetUserId} from ${req.user._id}`);

                // Create notification for the rated user
                const feedbackNotification = {
                    type: "feedback_received",
                    message: `You received performance feedback from ${req.user.name}: ${feedback}`,
                    fromUser: req.user._id,
                    toUser: targetUserId,
                    createdAt: new Date(),
                    read: false
                };
                
                task.notifications.push(feedbackNotification);
                await task.save();
            } catch (messageError) {
                console.error("Error sending feedback message:", messageError);
                // Don't fail the rating if message fails
            }
        }
        
        const updatedTask = await Task.findById(id).populate([
            { path: "todoCheckList.userRatings.userId", select: "name email" },
            { path: "todoCheckList.userRatings.ratedBy", select: "name email" }
        ]);

        res.json({ 
            message: isRatingOwnTask ? "Task rated successfully" : "User performance rated successfully", 
            task: updatedTask,
            userRating: user.overallRating
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Assign users to task (Domain Manager only)
//@route PUT /api/tasks/:id/assign
//@access Private (Domain Manager)
const assignUsersToTask = async (req, res) => {
    try {
        const { assignedTo } = req.body;
        
        if (!Array.isArray(assignedTo)) {
            return res.status(400).json({ message: "assignedTo must be an array of user IDs" });
        }

        const task = await Task.findById(req.params.id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Only domain managers can assign users
        if (req.user.role !== "domain_manager") {
            return res.status(403).json({ message: "Only domain managers can assign users to tasks" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        // Update task assignment and status
        task.assignedTo = assignedTo;
        task.status = "Pending"; // Change status to pending when assigned

        // Create notifications for assigned users
        for (const userId of assignedTo) {
          const notification = {
            type: "task_assigned",
            message: `You have been assigned to task "${task.title}"`,
            fromUser: req.user._id,
            toUser: userId,
            createdAt: new Date(),
            read: false
          };
          
          task.notifications.push(notification);
        }

        await task.save();
        
        // Automatically assign users to the project
        if (task.projectId) {
            try {
                const Project = require('../models/Project');
                const project = await Project.findById(task.projectId);
                
                if (project) {
                    // Add new users to project if they're not already assigned
                    const newUsers = assignedTo.filter(userId => 
                        !project.assignedUsers.includes(userId)
                    );
                    
                    if (newUsers.length > 0) {
                        project.assignedUsers = [...new Set([...project.assignedUsers, ...newUsers])];
                        await project.save();
                        
                        console.log(`Automatically assigned ${newUsers.length} users to project: ${project.title}`);
                    }
                }
            } catch (projectError) {
                console.error("Error auto-assigning users to project:", projectError);
                // Don't fail the task assignment if project assignment fails
            }
        }
        
        const updatedTask = await Task.findById(req.params.id).populate([
            { path: "assignedTo", select: "name email profileImageUrl" },
            { path: "projectId", select: "title status" }
        ]);

        res.json({ 
            message: "Users assigned to task successfully", 
            task: updatedTask 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Assign domain managers to task (Admin only)
//@route PUT /api/tasks/:id/assign-domain-managers
//@access Private (Admin)
const assignDomainManagersToTask = async (req, res) => {
    try {
        const { assignedDomainManagers } = req.body;
        
        if (!Array.isArray(assignedDomainManagers)) {
            return res.status(400).json({ message: "assignedDomainManagers must be an array of user IDs" });
        }

        const task = await Task.findById(req.params.id);
        
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Only admins can assign domain managers
        if (req.user.role !== "admin") {
            return res.status(403).json({ message: "Only admins can assign domain managers to tasks" });
        }

        // Update task with assigned domain managers
        task.assignedDomainManagers = assignedDomainManagers;
        task.status = "Under Review"; // Change status to under review when domain managers are assigned

        await task.save();
        
        const updatedTask = await Task.findById(req.params.id).populate([
            { path: "assignedDomainManagers", select: "name email profileImageUrl" },
            { path: "createdBy", select: "name email" }
        ]);

        res.json({ 
            message: "Domain managers assigned to task successfully", 
            task: updatedTask 
        });
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get tasks ready for assignment (Admin only)
//@route GET /api/tasks/ready-for-assignment
//@access Private (Admin)
const getTasksReadyForAssignment = async (req, res) => {
    try {
        const tasks = await Task.find({ status: "Ready for Assignment" }).populate([
            { path: "createdBy", select: "name email" },
            { path: "assignedDomainManagers", select: "name email profileImageUrl" }
        ]);

        res.json(tasks);
    } catch (error) {
        console.error("Error in getTasksReadyForAssignment:", error); // Add this for debugging
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get rejected tasks (Admin only)
//@route GET /api/tasks/rejected
//@access Private (Admin)
const getRejectedTasks = async (req, res) => {
    try {
        const tasks = await Task.find({ status: "Rejected" }).populate([
            { path: "createdBy", select: "name email" },
            { path: "rejectedByDomainManager", select: "name email" }
        ]);

        res.json(tasks);
    } catch (error) {
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Send feedback to admin (Domain Manager only)
//@route PUT /api/tasks/:id/feedback-to-admin
//@access Private (Domain Manager)
const sendFeedbackToAdmin = async (req, res) => {
  try {
    const { feedback } = req.body;
    const task = await Task.findById(req.params.id).populate("createdBy");

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

            // Only domain managers can send feedback to admin
        if (req.user.role !== "domain_manager") {
            return res.status(403).json({ message: "Only domain managers can send feedback to admin" });
        }

        // Check if the domain manager is assigned to this task
        if (!task.assignedDomainManagers.includes(req.user._id)) {
            return res.status(403).json({ message: "You are not assigned to this task" });
        }

        // Format feedback message
        let feedbackMessage = "";
    if (Array.isArray(feedback)) {
      feedbackMessage = feedback.map(item => 
        `"${item.itemText}": ${item.feedback}`
      ).join("; ");
    } else {
      feedbackMessage = feedback;
    }

    // Update task with rejection feedback
    task.adminRejectionFeedback = feedbackMessage;
    task.rejectedByDomainManager = req.user._id;
    task.rejectedAt = new Date();
    task.status = "Rejected";

    // Create notification for admin
    task.notifications.push({
      type: "feedback",
      message: `Domain Manager ${req.user.name} provided feedback about checklist items: ${feedbackMessage}`,
      fromUser: req.user._id,
      toUser: task.createdBy._id
    });

    await task.save();

    res.json({
      message: "Feedback sent to admin successfully",
      task: task
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

//@desc Get notifications for admin and domain managers
//@route GET /api/tasks/notifications
//@access Private (Admin, Domain Manager)
const getNotifications = async (req, res) => {
  try {
    // Allow all authenticated users to view notifications
    let allTasks;
    if (req.user.role === "admin") {
      // Admin can see notifications for all tasks
      allTasks = await Task.find({}).populate("createdBy");
    } else if (req.user.role === "domain_manager") {
      // Domain managers can see notifications for tasks they're assigned to
      allTasks = await Task.find({ assignedDomainManagers: req.user._id }).populate("createdBy");
    } else {
      // Regular users can see notifications for tasks they're assigned to or involved with
      // Also include tasks that have notifications for them (like messages)
      allTasks = await Task.find({
        $or: [
          { assignedUsers: req.user._id },
          { "todoCheckList.assignedUsers": req.user._id },
          { "notifications.toUser": req.user._id }
        ]
      }).populate("createdBy");
    }

    const notifications = [];
    
    for (const task of allTasks) {
      if (task.notifications && task.notifications.length > 0) {
        
        for (const notification of task.notifications) {
          
          // Check if this notification is relevant to the current user
          let shouldInclude = false;
          
          if (req.user.role === "admin") {
            // Admin can see all notifications
            shouldInclude = true;
          } else if (req.user.role === "domain_manager") {
            // Domain managers can see notifications for tasks they're assigned to
            // BUT exclude notifications they created themselves
            shouldInclude = notification.fromUser.toString() !== req.user._id.toString();
          } else {
            // Regular users can see notifications related to their tasks
            // Include if they're the recipient, or if it's a task-related notification
            shouldInclude = (
              (notification.toUser && notification.toUser.toString() === req.user._id.toString()) ||
              notification.type === "task_assigned" ||
              notification.type === "task_completed" ||
              notification.type === "feedback_received" ||
              notification.type === "checklist_item_assigned" ||
              notification.type === "checklist_item_approved" ||
              notification.type === "checklist_item_rejected"
            );
          }
          
          if (shouldInclude) {
            try {
              // Get user details
              const fromUser = await User.findById(notification.fromUser);
              const toUser = await User.findById(notification.toUser);
              
              notifications.push({
                _id: notification._id,
                type: notification.type,
                message: notification.message,
                fromUser: fromUser,
                toUser: toUser,
                createdAt: notification.createdAt,
                read: notification.read,
                taskId: task._id,
                taskTitle: task.title,
                todoIndex: notification.todoIndex,
                rejectionFeedback: notification.rejectionFeedback
              });
            } catch (userError) {
              console.error("Error fetching user details:", userError);
            }
          }
        }
      }
    }

    // Sort by creation date (newest first)
    notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Debug logging
    console.log(`User ${req.user._id} (${req.user.role}) - Found ${notifications.length} notifications from ${allTasks.length} tasks`);
    
    // Log notification details for debugging
    if (notifications.length > 0) {
      console.log("Notifications:", notifications.map(n => ({
        type: n.type,
        message: n.message.substring(0, 50) + "...",
        fromUser: n.fromUser?.name || "Unknown",
        toUser: n.toUser?.name || "Unknown",
        isRecipient: n.toUser && n.toUser._id.toString() === req.user._id.toString()
      })));
    }

    res.json(notifications);
    
  } catch (error) {
    console.error("Error in getNotifications:", error);
    console.error("Error stack:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

//@desc Mark notification as read
//@route PUT /api/tasks/notifications/:notificationId/read
//@access Private (All authenticated users)
const markNotificationAsRead = async (req, res) => {
  try {
    const { notificationId } = req.params;
    console.log(`Marking notification as read: ${notificationId} for user: ${req.user._id} (${req.user.role})`);

    // Allow all authenticated users to mark notifications as read
    let query = { "notifications._id": notificationId };
    
    // Filter by user role and permissions
    if (req.user.role === "admin") {
      // Admin can mark any notification as read
      console.log("Admin marking notification as read");
    } else if (req.user.role === "domain_manager") {
      // Domain managers can mark notifications as read for tasks they're assigned to
      // OR if they're the recipient of the notification
      query.$or = [
        { assignedDomainManagers: req.user._id },
        { "notifications.toUser": req.user._id }
      ];
      console.log("Domain manager marking notification as read with query:", JSON.stringify(query));
    } else {
      // Regular users can mark notifications as read for tasks they're assigned to or involved with
      // OR if they're the recipient of the notification
      query.$or = [
        { assignedUsers: req.user._id },
        { "todoCheckList.assignedUsers": req.user._id },
        { "notifications.toUser": req.user._id }
      ];
      console.log("Regular user marking notification as read with query:", JSON.stringify(query));
    }
    
    console.log("Final query:", JSON.stringify(query));
    
    const result = await Task.updateOne(
      query,
      { $set: { "notifications.$.read": true } }
    );

    console.log("Update result:", result);

    if (result.modifiedCount === 0) {
      console.log("No notification found or updated");
      return res.status(404).json({ message: "Notification not found" });
    }

    console.log("Notification marked as read successfully");
    res.json({ message: "Notification marked as read" });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

//@desc Get User's Assigned Checklist Items
//@route GET /api/tasks/user-checklist-items
//@access Private (User)
const getUserChecklistItems = async (req, res) => {
    try {
        const userId = req.user._id;

        // Find all tasks where the user is assigned to any checklist item
        const tasksWithUserChecklist = await Task.find({
            "todoCheckList.assignedUsers": userId
        }).populate({
            path: "todoCheckList.assignedUsers",
            select: "name email profileImageUrl skills overallRating"
        }).populate({
            path: "assignedDomainManagers",
            select: "name email"
        }).select("title status priority dueDate todoCheckList assignedDomainManagers");

        // Extract and format checklist items assigned to this user
        const userChecklistItems = [];
        const checklistStats = {
            total: 0,
            pending: 0,
            inProgress: 0,
            completed: 0,
            overdue: 0
        };

        tasksWithUserChecklist.forEach(task => {
            task.todoCheckList.forEach((checklistItem, index) => {
                if (checklistItem.assignedUsers.some(user => user._id.toString() === userId.toString())) {
                    const isOverdue = task.dueDate && new Date() > new Date(task.dueDate) && !checklistItem.completed;
                    
                    const item = {
                        taskId: task._id.toString(),
                        taskTitle: task.title,
                        taskStatus: task.status,
                        taskPriority: task.priority,
                        taskDueDate: task.dueDate,
                        domainManagers: task.assignedDomainManagers,
                        checklistIndex: index,
                        text: checklistItem.text,
                        description: checklistItem.description,
                        completed: checklistItem.completed,
                        completedAt: checklistItem.completedAt,
                        approved: checklistItem.approved,
                        rejected: checklistItem.rejected,
                        rejectionFeedback: checklistItem.rejectionFeedback,
                        isOverdue: isOverdue,
                        assignedAt: checklistItem.assignedAt || task.createdAt
                    };

                    userChecklistItems.push(item);

                    // Update stats
                    checklistStats.total++;
                    if (checklistItem.completed) {
                        checklistStats.completed++;
                    } else if (checklistItem.rejected) {
                        checklistStats.pending++;
                    } else if (isOverdue) {
                        checklistStats.overdue++;
                    } else {
                        checklistStats.pending++;
                    }
                }
            });
        });

        // Sort by priority and due date
        userChecklistItems.sort((a, b) => {
            const priorityOrder = { "High": 3, "Medium": 2, "Low": 1 };
            const priorityDiff = (priorityOrder[b.taskPriority] || 0) - (priorityOrder[a.taskPriority] || 0);
            if (priorityDiff !== 0) return priorityDiff;
            
            if (a.isOverdue && !b.isOverdue) return -1;
            if (!a.isOverdue && b.isOverdue) return 1;
            
            return new Date(a.taskDueDate) - new Date(b.taskDueDate);
        });

        res.status(200).json({
            checklistItems: userChecklistItems,
            statistics: checklistStats,
            totalTasks: tasksWithUserChecklist.length
        });

    } catch (error) {
        console.error("Error fetching user checklist items:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Update checklist item status
//@route PUT /api/tasks/:taskId/todo/:todoIndex/status
//@access Private (Assigned users only)
const updateChecklistItemStatus = async (req, res) => {
    try {
        const { id: taskId, todoIndex } = req.params;
        const { completed, rejected } = req.body;

        // Find the task
        const task = await Task.findById(taskId);
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Check if user is assigned to this checklist item
        const checklistItem = task.todoCheckList[todoIndex];
        if (!checklistItem) {
            return res.status(404).json({ message: "Checklist item not found" });
        }

        // Check if assignedUsers exists and has users
        if (!checklistItem.assignedUsers || !Array.isArray(checklistItem.assignedUsers) || checklistItem.assignedUsers.length === 0) {
            return res.status(403).json({ 
                message: "This checklist item has no assigned users. Please contact a domain manager to assign users to this item."
            });
        }

        const isUserAssigned = checklistItem.assignedUsers.some(
            user => user.toString() === req.user._id.toString()
        );

        // Fallback: Check if user is assigned to the task itself
        const isUserAssignedToTask = task.assignedTo && task.assignedTo.some(
            user => user.toString() === req.user._id.toString()
        );

        if (!isUserAssigned && !isUserAssignedToTask) {
            return res.status(403).json({ 
                message: "You are not assigned to this checklist item or the task. Please contact a domain manager for access."
            });
        }

        // Update the specific checklist item using findByIdAndUpdate
        const updatedTask = await Task.findByIdAndUpdate(
            taskId,
            {
                $set: {
                    [`todoCheckList.${todoIndex}.completed`]: completed,
                    [`todoCheckList.${todoIndex}.rejected`]: rejected,
                    ...(completed && { 
                        [`todoCheckList.${todoIndex}.completedAt`]: new Date(),
                        [`todoCheckList.${todoIndex}.completedBy`]: req.user._id
                    }),
                    ...(rejected && { 
                        [`todoCheckList.${todoIndex}.rejectedAt`]: new Date(),
                        [`todoCheckList.${todoIndex}.rejectedBy`]: req.user._id
                    })
                }
            },
            { new: true, runValidators: true }
        );

        if (!updatedTask) {
            return res.status(400).json({ message: "Failed to update checklist item status" });
        }

        res.status(200).json({ 
            message: "Checklist item status updated successfully",
            completed,
            rejected,
            updatedItem: updatedTask.todoCheckList[todoIndex]
        });

    } catch (error) {
        console.error("Error updating checklist item status:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Update checklist item description
//@route PUT /api/tasks/:taskId/todo/:todoIndex/description
//@access Private (Assigned users only)
const updateChecklistItemDescription = async (req, res) => {
    try {
        const { id: taskId, todoIndex } = req.params;
        const { description } = req.body;

        if (!description || description.trim() === "") {
            return res.status(400).json({ message: "Description is required" });
        }

        // Find the task
        const task = await Task.findById(taskId);
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Check if user is assigned to this checklist item
        const checklistItem = task.todoCheckList[todoIndex];
        if (!checklistItem) {
            return res.status(404).json({ message: "Checklist item not found" });
        }



        // Check if assignedUsers exists and has users
        if (!checklistItem.assignedUsers || !Array.isArray(checklistItem.assignedUsers) || checklistItem.assignedUsers.length === 0) {
            return res.status(403).json({ 
                message: "This checklist item has no assigned users. Please contact a domain manager to assign users to this item.",
                debug: {
                    hasAssignedUsers: !!checklistItem.assignedUsers,
                    isArray: Array.isArray(checklistItem.assignedUsers),
                    length: checklistItem.assignedUsers?.length
                }
            });
        }

        const isUserAssigned = checklistItem.assignedUsers.some(
            user => user.toString() === req.user._id.toString()
        );

        // Fallback: Check if user is assigned to the task itself
        const isUserAssignedToTask = task.assignedTo && task.assignedTo.some(
            user => user.toString() === req.user._id.toString()
        );

        console.log("Is User Assigned to Item:", isUserAssigned);
        console.log("Is User Assigned to Task:", isUserAssignedToTask);
        console.log("================================");

        if (!isUserAssigned && !isUserAssignedToTask) {
            return res.status(403).json({ 
                message: "You are not assigned to this checklist item or the task. Please contact a domain manager for access.",
                debug: {
                    isUserAssignedToItem: isUserAssigned,
                    isUserAssignedToTask: isUserAssignedToTask,
                    taskAssignedTo: task.assignedTo
                }
            });
        }

        // Update the checklist item description
        const result = await Task.updateOne(
            { 
                _id: taskId,
                [`todoCheckList.${todoIndex}.assignedUsers`]: req.user._id
            },
            {
                $set: {
                    [`todoCheckList.${todoIndex}.description`]: description.trim()
                }
            }
        );

        if (result.modifiedCount === 0) {
            return res.status(400).json({ message: "Failed to update checklist item description" });
        }

        res.status(200).json({ 
            message: "Checklist item description updated successfully",
            description: description.trim()
        });

    } catch (error) {
        console.error("Error updating checklist item description:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//@desc Get user tasks (tasks assigned to the user directly or through project assignment, and approved by domain managers)
//@route GET /api/tasks/user/my-tasks
//@access Private
const getUserTasks = async (req, res) => {
    try {
        const { status } = req.query;
        
        // Find projects where the user is assigned
        const userProjects = await Project.find({ 
            assignedUsers: req.user._id 
        }).select('_id');
        
        const userProjectIds = userProjects.map(project => project._id);
        
        // Build filter to get tasks that are:
        // 1. Directly assigned to the user, OR
        // 2. Belong to projects where the user is assigned
        let filter = {
            $or: [
                { assignedTo: req.user._id }, // Directly assigned tasks
                { projectId: { $in: userProjectIds } } // Tasks in user's projects
            ]
        };
        
        if (status && status !== "All") {
            filter.status = status;
        }

        // Get tasks that meet the criteria
        const tasks = await Task.find(filter).populate([
            { path: "assignedTo", select: "name email profileImageUrl" },
            { path: "assignedDomainManagers", select: "name email profileImageUrl" },
            { path: "projectId", select: "title status" }
        ]);

        // For now, show all tasks that the user has access to (either directly assigned or through project)
        // The domain manager approval logic can be refined based on specific requirements
        const approvedTasks = tasks;

        // Add completed Deliverables Checklist count to each task
        const tasksWithCounts = approvedTasks.map(task => {
            const completedCount = task.todoCheckList.filter(item => item.completed).length;
            return { ...task._doc, completedTodoCount: completedCount };
        });

        // Status summary counts for user's approved tasks
        const allTasks = approvedTasks.length;
        const pendingTasks = approvedTasks.filter(task => task.status === "Pending").length;
        const inProgressTasks = approvedTasks.filter(task => task.status === "In Progress").length;
        const completedTasks = approvedTasks.filter(task => task.status === "Completed").length;

        res.json({
            tasks: tasksWithCounts,
            statusSummary: {
                all: allTasks,
                pendingTasks,
                inProgressTasks,
                completedTasks,
            },
        });
    } catch (error) {
        console.error("Error getting user tasks:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = {
    getTasks,
    getTasksById,
    createTask,
    updateTask,
    deleteTask,
    updateTaskStatus,
    updateTaskChecklist,
    getDashboardData,
    getUserDashboardData,
    getDomainManagerDashboardData,
    approveTodoItem,
    rejectTodoItem,
    rateTask,
    getTasksPendingApproval,
    getTasksPendingRating,
    assignUsersToChecklistItem,
    getSuitableUsersForChecklistItem,
    completeChecklistItem,
    rateUserPerformance,
    assignUsersToTask,
    assignDomainManagersToTask,
    getTasksReadyForAssignment,
    getRejectedTasks,
    sendFeedbackToAdmin,
    getNotifications,
    markNotificationAsRead,
    getUserChecklistItems,
    updateChecklistItemStatus,
    updateChecklistItemDescription,
    getUserTasks
};
