const mongoose = require('mongoose');
const User = require('./models/User');
const bcrypt = require('bcryptjs');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/sopra_hr_software', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

async function setupEnvironment() {
  try {
    
    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 10);
    const adminUser = new User({
      name: 'Admin User',
      email: 'admin@sopra.com',
      password: adminPassword,
      role: 'admin',
      profileImageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      overallRating: 5.0,
    });
    await adminUser.save();

    // Create domain managers with expertise
    const domainManagerPassword = await bcrypt.hash('dm123', 10);
    
    const dm1 = new User({
      name: 'Sarah Johnson',
      email: 'sarah.johnson@sopra.com',
      password: domainManagerPassword,
      role: 'domain_manager',
      profileImageUrl: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.8,
      domainExpertise: ['Web Development', 'UI/UX Design', 'Project Management'],
    });
    await dm1.save();

    const dm2 = new User({
      name: 'Michael Chen',
      email: 'michael.chen@sopra.com',
      password: domainManagerPassword,
      role: 'domain_manager',
      profileImageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.6,
      domainExpertise: ['Mobile Development', 'Backend Development', 'Database Design'],
    });
    await dm2.save();

    const dm3 = new User({
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@sopra.com',
      password: domainManagerPassword,
      role: 'domain_manager',
      profileImageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.9,
      domainExpertise: ['DevOps', 'Cloud Computing', 'System Architecture'],
    });
    await dm3.save();

    // Create team members with skills
    const memberPassword = await bcrypt.hash('member123', 10);
    
    const member1 = new User({
      name: 'Alex Thompson',
      email: 'alex.thompson@sopra.com',
      password: memberPassword,
      role: 'member',
      profileImageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.5,
      skills: [
        { name: 'React', rating: 4.5, category: 'Frontend' },
        { name: 'JavaScript', rating: 4.2, category: 'Programming' },
        { name: 'UI/UX Design', rating: 3.8, category: 'Design' }
      ],
    });
    await member1.save();

    const member2 = new User({
      name: 'Jessica Lee',
      email: 'jessica.lee@sopra.com',
      password: memberPassword,
      role: 'member',
      profileImageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.7,
      skills: [
        { name: 'Node.js', rating: 4.8, category: 'Backend' },
        { name: 'MongoDB', rating: 4.3, category: 'Database' },
        { name: 'Express.js', rating: 4.1, category: 'Backend' }
      ],
    });
    await member2.save();

    const member3 = new User({
      name: 'David Kim',
      email: 'david.kim@sopra.com',
      password: memberPassword,
      role: 'member',
      profileImageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.3,
      skills: [
        { name: 'Python', rating: 4.6, category: 'Programming' },
        { name: 'Django', rating: 4.0, category: 'Backend' },
        { name: 'Data Analysis', rating: 4.2, category: 'Analytics' }
      ],
    });
    await member3.save();

    const member4 = new User({
      name: 'Lisa Wang',
      email: 'lisa.wang@sopra.com',
      password: memberPassword,
      role: 'member',
      profileImageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.8,
      skills: [
        { name: 'React Native', rating: 4.9, category: 'Mobile' },
        { name: 'TypeScript', rating: 4.5, category: 'Programming' },
        { name: 'Mobile UI/UX', rating: 4.7, category: 'Design' }
      ],
    });
    await member4.save();

    const member5 = new User({
      name: 'Robert Garcia',
      email: 'robert.garcia@sopra.com',
      password: memberPassword,
      role: 'member',
      profileImageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      overallRating: 4.4,
      skills: [
        { name: 'DevOps', rating: 4.6, category: 'Infrastructure' },
        { name: 'Docker', rating: 4.3, category: 'Infrastructure' },
        { name: 'AWS', rating: 4.1, category: 'Cloud' }
      ],
    });
    await member5.save();
    
  } catch (error) {
    console.error('Error setting up environment:', error);
  } finally {
    mongoose.connection.close();
  }
}

setupEnvironment(); 