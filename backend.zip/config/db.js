const mongoose = require("mongoose");
require("dotenv").config();


const connectDB = async () => {
    try {
        console.log("Connecting to database...");
        const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/sopra_hr_software';
        console.log("Using MongoDB URI:", mongoUri);
        await mongoose.connect(mongoUri, {});
        console.log("Database connected successfully");
        
    } catch (error) {
        console.error("Database connection error:", error);
        process.exit(1); // Exit process with failure
    }
};

module.exports = connectDB;