import React, { createContext, useEffect, useState } from "react";
import { API_PATHS } from "../utils/apiPaths";
import axiosInstance from "../utils/axiosInstance";

export const UserContext = createContext();

const UserProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);   // New state to track loading

    useEffect(
        () => {
            if (user) return;

            const accessToken = localStorage.getItem("token");
            if (!accessToken) {
                setLoading(false);
                return;
            }

            const fetchUser = async () => {
                try {
                    const response = await axiosInstance.get(API_PATHS.AUTH.GET_PROFILE);
                    setUser(response.data);
                } catch (error) {
                    console.error("User not authenticated", error);
                    clearUser();
                } finally {
                    setLoading(false);
                }
            };

            fetchUser();
        }, []);
    
    const updateUser = (userData) => {
        console.log("=== updateUser called ===");
        console.log("Previous user:", user);
        console.log("New user data:", userData);
        console.log("Existing token:", localStorage.getItem("token"));
        console.log("New token:", userData.token);
        
        // Preserve the existing token when updating user data
        const existingToken = localStorage.getItem("token");
        setUser(userData);
        
        // Only update token if a new one is provided, otherwise keep the existing one
        if (userData.token) {
            console.log("Setting new token:", userData.token);
            localStorage.setItem("token", userData.token);
        } else if (existingToken) {
            // Ensure the token is preserved in localStorage
            console.log("Preserving existing token:", existingToken);
            localStorage.setItem("token", existingToken);
        }
        
        setLoading(false);
        console.log("=== updateUser completed ===");
    };
    const clearUser = () => {
        setUser(null);
        localStorage.removeItem("token");
    };
    return (
        <UserContext.Provider value={{ user, updateUser, clearUser, loading }}>
            {children}
            </UserContext.Provider>
    );

}

export default UserProvider;
