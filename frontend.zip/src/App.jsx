import React, { useContext } from "react";
import { Navigate, Outlet, Route, BrowserRouter as Router, Routes } from "react-router-dom";
import CreateTask from "./pages/Admin/CreateTask";
import Dashboard from "./pages/Admin/Dashboard";
import ManageTasks from "./pages/Admin/ManageTasks";
import ManageUsers from "./pages/Admin/ManageUsers";
import Messages from "./pages/Admin/Messages";
import ProjectManagement from "./pages/Admin/ProjectManagement";
import Login from "./pages/Auth/Login";
import SignUp from "./pages/Auth/Signup";
import MyTasks from "./pages/User/MyTasks";
import Profile from "./pages/User/Profile";
import TaskManager from "./pages/User/TaskManager";
import UserDashboard from "./pages/User/UserDashboard";
import UserMessages from "./pages/User/UserMessages";
import ViewTaskDetails from "./pages/User/ViewTaskDetails";
import PrivateRoute from "./routes/PrivateRoute";
// Domain Manager imports
import { Toaster } from "react-hot-toast";
import UserProvider, { UserContext } from "./context/userContext";
import DomainManagerCreateTask from "./pages/DomainManager/CreateTask";
import DomainManagerDashboard from "./pages/DomainManager/Dashboard";
import DomainManagerTasks from "./pages/DomainManager/ManageTasks";
import DomainManagerUsers from "./pages/DomainManager/ManageUsers";
import DomainManagerMessages from "./pages/DomainManager/Messages";
import PendingApprovals from "./pages/DomainManager/PendingApprovals";
import PendingRatings from "./pages/DomainManager/PendingRatings";
import TaskReview from "./pages/DomainManager/TaskReview";


const App = () => {
  return (
    <UserProvider>
      <div>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signUp" element={<SignUp />} />

            {/* Admin Routes */}
            <Route element={<PrivateRoute allowedRoles={["admin"]} />}>
              <Route path="/admin/dashboard" element={<Dashboard />} />
              <Route path="/admin/tasks" element={<ManageTasks />} />
              <Route path="/admin/create-task" element={<CreateTask />} />
              <Route path="/admin/users" element={<ManageUsers />} />
              <Route path="/admin/messages" element={<Messages />} />
              <Route path="/admin/project-management" element={<ProjectManagement />} />
            </Route>

            {/* Domain Manager Routes */}
            <Route element={<PrivateRoute allowedRoles={["domain_manager"]} />}>
              <Route path="/domain-manager/dashboard" element={<DomainManagerDashboard />} />
              <Route path="/domain-manager/tasks" element={<DomainManagerTasks />} />
              <Route path="/domain-manager/create-task" element={<DomainManagerCreateTask />} />
              <Route path="/domain-manager/users" element={<DomainManagerUsers />} />
              <Route path="/domain-manager/messages" element={<DomainManagerMessages />} />
              <Route path="/domain-manager/pending-approvals" element={<PendingApprovals />} />
              <Route path="/domain-manager/pending-ratings" element={<PendingRatings />} />
              <Route path="/domain-manager/task-report/:id" element={<TaskReview />} />

            </Route>

            {/* User Routes */}
            <Route element={<PrivateRoute allowedRoles={["member", "user"]} />}>
              <Route path="/user/dashboard" element={<UserDashboard />} />
              <Route path="/user/tasks" element={<MyTasks />} />
              <Route path="/user/task-manager" element={<TaskManager />} />
              <Route path="/user/task-manager/:projectId" element={<TaskManager />} />
              <Route path="/user/profile" element={<Profile />} />
              <Route path="/user/messages" element={<UserMessages />} />
              <Route path="/user/task-details/:id" element={<ViewTaskDetails />} />
            </Route>

            {/* Default Route */}
            <Route path="/" element={<Root />} />
          </Routes>
        </Router>
      </div>

      <Toaster 
        toasterOptions={{
          className: "text-sm",
          style: {
            fontSize: "13px",
          },
      }}
      />
    </UserProvider>
  );
};

export default App;

const Root = () => {
  const { user, loading } = useContext(UserContext);

  if (loading) return <Outlet />;

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (user.role === "admin") {
    return <Navigate to="/admin/dashboard" />;
  } else if (user.role === "domain_manager") {
    return <Navigate to="/domain-manager/dashboard" />;
  } else {
    return <Navigate to="/user/dashboard" />;
  }
};

