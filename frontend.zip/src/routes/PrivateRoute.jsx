import React, { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { UserContext } from '../context/userContext'

const PrivateRoute = ({allowedRoles}) => {
  const { user, loading } = useContext(UserContext)

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Redirect based on user role
    if (user.role === "admin") {
      return <Navigate to="/admin/dashboard" replace />
    } else if (user.role === "domain_manager") {
      return <Navigate to="/domain-manager/dashboard" replace />
    } else {
      return <Navigate to="/user/dashboard" replace />
    }
  }

  return <Outlet />
}

export default PrivateRoute