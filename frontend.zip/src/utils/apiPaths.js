export const BASE_URL = "http://localhost:8000";

// utils/apiPaths.js
export const API_PATHS = {
  AUTH: {
    REGISTER: "/api/auth/register", // Register a new user (Admin or Member)
    LOGIN: "/api/auth/login", // Authenticate user and return JWT token
    GET_PROFILE: "/api/auth/profile", // Get logged-in user details
    UPDATE_PROFILE: "/api/auth/profile", // Update logged-in user profile
  },
  USERS: {
    GET_ALL_USERS: "/api/users", // Get all users (Admin only)
    GET_USER_BY_ID: (userId) => `/api/users/${userId}`, // Get user by ID
    CREATE_USER: "/api/users", // Create a new user (Admin only)
    UPDATE_USER: (userId) => `/api/users/${userId}`, // Update user details
    DELETE_USER: (userId) => `/api/users/${userId}`, // Delete a user
    GET_DOMAIN_MANAGERS: "/api/users/domain-managers", // Get domain managers with expertise
    GET_USERS_BY_SKILLS: "/api/users/by-skills", // Get users by skills for assignment
    SEARCH_USERS: "/api/users/search", // Search users by name or email
    UPDATE_USER_SKILLS: (userId) => `/api/users/${userId}/skills`, // Update user skills and ratings
    UPDATE_DOMAIN_MANAGER_EXPERTISE: (userId) => `/api/users/${userId}/expertise`, // Update domain manager expertise
  },

  TASKS: {
    GET_DASHBOARD_DATA: "/api/tasks/dashboard-data", // Get Dashboard Data
    GET_USER_DASHBOARD_DATA: "/api/tasks/user-dashboard-data", // Get User Dashboard Data
    GET_USER_CHECKLIST_ITEMS: "/api/tasks/user-checklist-items", // Get User's Assigned Checklist Items
    GET_USER_TASKS: "/api/tasks/user/my-tasks", // Get User's Assigned Tasks
    GET_DOMAIN_MANAGER_DASHBOARD_DATA: "/api/tasks/domain-manager-dashboard-data", // Get Domain Manager Dashboard Data
    GET_ALL_TASKS: "/api/tasks", // Get all tasks (Admin: all, User: assigned)
    GET_TASK_BY_ID: (taskId) => `/api/tasks/${taskId}`, // Get task by ID
    CREATE_TASK: "/api/tasks", // Create a new task (Admin or Domain Manager)
    UPDATE_TASK: (taskId) => `/api/tasks/${taskId}`, // Update task details
    DELETE_TASK: (taskId) => `/api/tasks/${taskId}`, // Delete a task (Admin only)

    UPDATE_TASK_STATUS: (taskId) => `/api/tasks/${taskId}/status`, // Update task status
    UPDATE_TODO_CHECKLIST: (taskId) => `/api/tasks/${taskId}/todo`, // Update todo checklist
    
    // User checklist item management endpoints
    UPDATE_CHECKLIST_ITEM_STATUS: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/status`, // Update checklist item status
    UPDATE_CHECKLIST_ITEM_DESCRIPTION: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/description`, // Update checklist item description
    
    // Domain Manager specific endpoints
    GET_PENDING_APPROVAL: "/api/tasks/pending-approval", // Get tasks pending approval
    GET_PENDING_RATING: "/api/tasks/pending-rating", // Get tasks pending rating
    APPROVE_TODO_ITEM: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/approve`, // Approve todo item
    REJECT_TODO_ITEM: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/reject`, // Reject todo item with feedback
    ASSIGN_USERS_TO_CHECKLIST_ITEM: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/assign-users`, // Assign users to specific checklist item
    GET_SUITABLE_USERS_FOR_CHECKLIST_ITEM: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/suitable-users`, // Get suitable users for checklist item
    COMPLETE_CHECKLIST_ITEM: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/complete`, // Complete checklist item (Assigned users only)
    RATE_USER_PERFORMANCE: (taskId, todoIndex) => `/api/tasks/${taskId}/todo/${todoIndex}/rate-user`, // Rate user performance on checklist item
    RATE_TASK: (taskId) => `/api/tasks/${taskId}/rate`, // Rate task quality and time
    ASSIGN_USERS: (taskId) => `/api/tasks/${taskId}/assign`, // Assign users to task (Domain Manager only)
    
    // Admin specific endpoints
    GET_READY_FOR_ASSIGNMENT: "/api/tasks/ready-for-assignment", // Get tasks ready for assignment
    GET_REJECTED_TASKS: "/api/tasks/rejected", // Get rejected tasks
    SEND_FEEDBACK_TO_ADMIN: (taskId) => `/api/tasks/${taskId}/feedback-to-admin`, // Send feedback to admin
    ASSIGN_DOMAIN_MANAGERS: (taskId) => `/api/tasks/${taskId}/assign-domain-managers`, // Assign domain managers to task (Admin only)
    GET_NOTIFICATIONS: "/api/tasks/notifications", // Get notifications for admin
    MARK_NOTIFICATION_READ: (notificationId) => `/api/tasks/notifications/${notificationId}/read`, // Mark notification as read
  },
  REPORTS: {
    EXPORT_TASKS: "/api/reports/export/tasks", // Download all tasks as an Excel
    EXPORT_USERS: "/api/reports/export/users", // Download user–task report
  },

  MESSAGES: {
    SEND_MESSAGE: "/api/messages", // Send a message
    GET_CONVERSATION: (userId) => `/api/messages/conversation/${userId}`, // Get conversation with specific user
    GET_CONVERSATIONS: "/api/messages/conversations", // Get all conversations
    MARK_MESSAGES_READ: (userId) => `/api/messages/read/${userId}`, // Mark messages as read
    GET_UNREAD_COUNT: "/api/messages/unread-count", // Get unread message count
    DEBUG_MESSAGES: "/api/messages/debug/messages", // Debug endpoint to check all messages
  },

  PROJECTS: {
    CREATE_PROJECT: "/api/projects", // Create a new project
    GET_ALL_PROJECTS: "/api/projects", // Get all projects (with filtering)
    GET_PROJECT_BY_ID: (projectId) => `/api/projects/${projectId}`, // Get project by ID
    UPDATE_PROJECT: (projectId) => `/api/projects/${projectId}`, // Update project
    DELETE_PROJECT: (projectId) => `/api/projects/${projectId}`, // Delete project
    ASSIGN_USERS_TO_PROJECT: (projectId) => `/api/projects/${projectId}/assign-users`, // Assign users to project
    GET_USER_PROJECTS: "/api/projects/user/my-projects", // Get user's assigned projects
  },

  IMAGE: {
    UPLOAD_IMAGE: "api/auth/upload-image",
  },
};