import {
    LuClipboardCheck,
    LuLayoutDashboard,
    LuMessageSquare,
    LuSquarePlus,
    LuUser,
    LuUsers
} from "react-icons/lu";

export const SIDE_MENU_DATA = [
    {
        id: "01",
        label: "Dashboard",
        icon: LuLayoutDashboard,
        path: "/admin/dashboard",
    },

    {
        id: "03",
        label: "Manage Projects",
        icon: LuClipboardCheck,
        path: "/admin/tasks",
    },
    {
        id: "04",
        label: "Create Task",
        icon: LuSquarePlus,
        path: "/admin/create-task",
    },
    {
        id: "05",
        label: "Team Members",
        icon: LuUsers,
        path: "/admin/users",
    },


];

export const SIDE_MENU_USER_DATA = [
  {
    id: "01",
    label: "Dashboard",
    icon: LuLayoutDashboard,
    path: "/user/dashboard",
  },
  {
    id: "02",
    label: "My Projects",
    icon: LuClipboardCheck,
    path: "/user/tasks",
  },
  {
    id: "03",
    label: "Task Manager",
    icon: LuClipboardCheck,
    path: "/user/task-manager",
  },
  {
    id: "04",
    label: "Profile",
    icon: LuUser,
    path: "/user/profile",
  },

];

export const SIDE_MENU_DOMAIN_MANAGER_DATA = [
  {
    id: "01",
    label: "Dashboard",
    icon: LuLayoutDashboard,
    path: "/domain-manager/dashboard",
  },
  {
    id: "02",
    label: "Manage Projects",
    icon: LuClipboardCheck,
    path: "/domain-manager/tasks",
  },
  {
    id: "03",
    label: "Create Task",
    icon: LuSquarePlus,
    path: "/domain-manager/create-task",
  },
  {
    id: "04",
    label: "Pending Approvals",
    icon: LuClipboardCheck,
    path: "/domain-manager/pending-approvals",
  },

  {
    id: "06",
    label: "Team Members",
    icon: LuUsers,
    path: "/domain-manager/users",
  },


];

export const PRIORITY_DATA = [
  { label: "Low", value: "Low" },
  { label: "Medium", value: "Medium" },
  { label: "High", value: "High" },
];
export const STATUS_DATA = [
  { label: "Pending", value: "Pending" },
  { label: "In Progress", value: "In Progress" },
  { label: "Completed", value: "Completed" },
];
