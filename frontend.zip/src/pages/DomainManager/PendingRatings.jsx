import React, { useContext, useEffect, useState } from "react";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import axiosInstance from "../../utils/axiosInstance";
import { API_PATHS } from "../../utils/apiPaths";
import { LuStar, LuClock } from "react-icons/lu";
import { useNavigate } from "react-router-dom";

const PendingRatings = () => {
  const { user } = useContext(UserContext);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPendingRatings();
  }, []);

  const fetchPendingRatings = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_PENDING_RATING);
      setTasks(response.data);
    } catch (error) {
      console.error("Error fetching pending ratings:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">
            Pending Ratings
          </h1>
          <p className="text-gray-600">
            Rate the quality and time efficiency of completed projects
          </p>
        </div>

        <div className="space-y-6">
          {tasks.map((task) => (
            <div
              key={task._id}
              className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 cursor-pointer"
              onClick={() => navigate(`/domain-manager/task-report/${task._id}`)}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    {task.title}
                  </h3>
                  <p className="text-gray-600 text-sm mt-1">
                    Assigned to: {task.assignedTo.map(user => user.name).join(", ")}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                    <LuClock className="w-3 h-3 mr-1" />
                    Pending Rating
                  </span>
                </div>
              </div>
              <p className="text-gray-700 mb-2 line-clamp-2">{task.description}</p>
              <div className="flex flex-wrap gap-2 mt-2">
                {(!task.qualityRating || !task.timeRating) && (
                  <span className="inline-flex items-center px-3 py-1 bg-orange-50 text-orange-800 text-xs rounded">
                    <LuStar className="w-3 h-3 mr-1" /> Needs Rating
                  </span>
                )}
              </div>
            </div>
          ))}

          {tasks.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 text-6xl mb-4">⭐</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No pending ratings
              </h3>
              <p className="text-gray-500">
                All completed projects have been rated.
              </p>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PendingRatings;
