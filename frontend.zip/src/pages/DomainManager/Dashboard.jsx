import moment from "moment";
import React, { useContext, useEffect, useState } from "react";
import {
  LuArrowDownRight,
  LuArrowUpRight,
  LuBell,
  LuCalendar,
  LuCheck,
  LuCircle,
  LuClock,
  LuDownload,
  LuPlus,
  LuSettings,
  LuStar,
  LuUsers
} from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import CustomBarChart from "../../components/Charts/CustomBarChart";
import CustomPieChart from "../../components/Charts/CustomPieChart";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const DomainManagerDashboard = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pendingApprovals, setPendingApprovals] = useState(0);
  const [pendingRatings, setPendingRatings] = useState(0);
  const [recentActivity, setRecentActivity] = useState([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [dashboardResponse, approvalsResponse, ratingsResponse] = await Promise.all([
          axiosInstance.get(API_PATHS.TASKS.GET_DOMAIN_MANAGER_DASHBOARD_DATA),
          axiosInstance.get(API_PATHS.TASKS.GET_PENDING_APPROVAL),
          axiosInstance.get(API_PATHS.TASKS.GET_PENDING_RATING)
        ]);

        setDashboardData(dashboardResponse.data);
        setPendingApprovals(approvalsResponse.data.length);
        setPendingRatings(ratingsResponse.data.length);
        
        // Debug: Log the dashboard data
        console.log('Dashboard Data:', dashboardResponse.data);
        console.log('Charts Data:', dashboardResponse.data?.charts);
        console.log('Task Distribution Raw:', dashboardResponse.data?.charts?.taskDistribution);
        console.log('Task Priority Levels Raw:', dashboardResponse.data?.charts?.taskPriorityLevels);
        console.log('Task Approval Status Raw:', dashboardResponse.data?.charts?.taskApprovalStatus);
        console.log('Task Approval Status Breakdown:', {
          approved: dashboardResponse.data?.charts?.taskApprovalStatus?.Approved || 0,
          partiallyApproved: dashboardResponse.data?.charts?.taskApprovalStatus?.PartiallyApproved || 0,
          notApproved: dashboardResponse.data?.charts?.taskApprovalStatus?.NotApproved || 0,
          rejected: dashboardResponse.data?.charts?.taskApprovalStatus?.Rejected || 0,
          waitingForApproval: dashboardResponse.data?.charts?.taskApprovalStatus?.WaitingforApproval || 0
        });
        console.log('Statistics:', dashboardResponse.data?.statistics);
        
        // Transform recent tasks into activity items
        if (dashboardResponse.data?.recentTasks) {
          const activities = dashboardResponse.data.recentTasks.map(task => {
            const timeAgo = moment(task.createdAt).fromNow();
            let type, message;
            
            if (task.status === 'Completed') {
              type = 'task_completed';
              message = `Project "${task.title}" completed successfully`;
            } else if (task.status === 'Pending') {
              type = 'approval_needed';
              message = `Task "${task.title}" requires attention`;
            } else if (task.status === 'In Progress') {
              type = 'task_in_progress';
              message = `Project "${task.title}" is in progress`;
            } else {
              type = 'task_created';
              message = `Project "${task.title}" created`;
            }
            
            return {
              type,
              message,
              time: timeAgo,
              priority: task.priority?.toLowerCase() || 'medium',
              taskId: task._id,
              taskTitle: task.title,
              taskStatus: task.status
            };
          });
          setRecentActivity(activities);
        }
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
        setError("Failed to load dashboard data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const getActivityIcon = (type) => {
    switch (type) {
      case 'task_created': return <LuPlus className="w-4 h-4 text-blue-600" />;
      case 'user_assigned': return <LuUsers className="w-4 h-4 text-green-600" />;
      case 'task_completed': return <LuCheck className="w-4 h-4 text-green-600" />;
      case 'task_in_progress': return <LuClock className="w-4 h-4 text-blue-600" />;
      case 'approval_needed': return <LuBell className="w-4 h-4 text-yellow-600" />;
      case 'rating_pending': return <LuStar className="w-4 h-4 text-purple-600" />;
      default: return <LuBell className="w-4 h-4 text-gray-600" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const handleActivityClick = (activity) => {
    if (activity.taskId) {
      navigate(`/domain-manager/task-report/${activity.taskId}`);
    }
  };

  // Transform data for charts
  const transformChartData = (data, keyName) => {
    console.log(`Transforming ${keyName} data:`, data);
    
    if (!data || typeof data !== 'object') {
      console.log(`No data or invalid data for ${keyName}:`, data);
      return [];
    }
    
    // Handle the backend's space-removed format
    const transformed = Object.entries(data)
      .filter(([key, value]) => key !== 'All' && value > 0)
      .map(([key, value]) => {
        // Convert backend format back to display format
        let displayKey = key;
        if (key === 'InProgress') {
          displayKey = 'In Progress';
        } else if (key === 'InReview') {
          displayKey = 'In Review';
        } else if (key === 'PartiallyApproved') {
          displayKey = 'Partially Approved';
        } else if (key === 'WaitingforApproval') {
          displayKey = 'Waiting for Approval';
        } else if (key === 'NotApproved') {
          displayKey = 'Not Approved';
        } else if (key === 'Rejected') {
          displayKey = 'Rejected';
        }
        
        return {
          [keyName]: displayKey,
          count: value
        };
      });
    
    console.log(`Transformed ${keyName} data:`, transformed);
    return transformed;
  };

  // Get chart data with fallbacks
  const getPieChartData = () => {
    console.log('Raw taskApprovalStatus data:', dashboardData?.charts?.taskApprovalStatus);
    const data = transformChartData(dashboardData?.charts?.taskApprovalStatus, 'status');
    console.log('Transformed pie chart data:', data);
    if (data.length === 0) {
      console.log('No pie chart data, returning fallback');
      return [
        { status: 'No Tasks', count: 1 }
      ];
    }
    return data;
  };

  const getBarChartData = () => {
    console.log('Raw taskPriorityLevels data:', dashboardData?.charts?.taskPriorityLevels);
    const data = transformChartData(dashboardData?.charts?.taskPriorityLevels, 'priority');
    if (data.length === 0) {
      console.log('No bar chart data, returning fallback');
      return [
        { priority: 'No Data', count: 1 }
      ];
    }
    return data;
  };

  // Colors for charts
  const pieChartColors = ['#10B981', '#F59E0B', '#EF4444', '#DC2626', '#3B82F6']; // Green (Approved), Yellow (Partially Approved), Red (Not Approved), Dark Red (Rejected), Blue (Waiting)

  const quickActions = [
    {
      title: "Create New Project",
      description: "Start a new project with team assignments",
      icon: <LuPlus className="w-6 h-6" />,
      color: "bg-blue-500 hover:bg-blue-600",
      action: () => navigate("/domain-manager/create-task")
    },
    {
      title: "Manage Team",
      description: "View and manage team members",
      icon: <LuUsers className="w-6 h-6" />,
      color: "bg-green-500 hover:bg-green-600",
      action: () => navigate("/domain-manager/users")
    },
    {
      title: "Pending Approvals",
      description: "Review tasks awaiting approval",
      icon: <LuCheck className="w-6 h-6" />,
      color: "bg-yellow-500 hover:bg-yellow-600",
      action: () => navigate("/domain-manager/pending-approvals")
    },

  ];

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <p className="text-red-500 mb-4">{error}</p>
            <button 
              onClick={() => window.location.reload()} 
              className="btn btn-primary"
            >
              Retry
            </button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const infoCards = [
    {
      title: "Total Projects",
      value: dashboardData?.statistics?.totalTasks || 0,
      icon: <LuUsers />,
      color: "blue",
      change: "+12%",
      changeType: "increase"
    },
    {
      title: "Active Projects",
      value: dashboardData?.statistics?.pendingTasks || 0,
      icon: <LuUsers />,
      color: "yellow",
      change: "+8%",
      changeType: "increase"
    },
    {
      title: "Completed Projects",
      value: dashboardData?.statistics?.completedTasks || 0,
      icon: <LuUsers />,
      color: "green",
      change: "+15%",
      changeType: "increase"
    },
    {
      title: "Team Members",
      value: dashboardData?.statistics?.totalTeamMembers || 0,
      icon: <LuUsers />,
      color: "purple",
      change: "+3",
      changeType: "increase"
    }
  ];

  const performanceMetrics = [
    {
      label: "Project Completion Rate",
      value: "87%",
      change: "+5%",
      changeType: "increase",
      color: "text-green-600"
    },
    {
      label: "Average Task Duration",
      value: "3.2 days",
      change: "-0.5 days",
      changeType: "decrease",
      color: "text-blue-600"
    },
    {
      label: "Team Satisfaction",
      value: "4.6/5",
      change: "+0.2",
      changeType: "increase",
      color: "text-yellow-600"
    },
    {
      label: "On-Time Delivery",
      value: "92%",
      change: "+3%",
      changeType: "increase",
      color: "text-green-600"
    }
  ];

  return (
    <DashboardLayout>
      <div className="p-6 bg-gray-50 min-h-screen">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                Welcome back, {user?.name}! 👋
          </h1>
              <p className="text-gray-600 text-lg">
                Here's what's happening with your domain today
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-white rounded-lg transition-colors">
                <LuSettings className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-white rounded-lg transition-colors">
                <LuDownload className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          {/* Date and Time */}
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <LuCalendar className="w-4 h-4" />
            <span>{new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</span>
          </div>
        </div>
        
        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={action.action}
                className={`${action.color} text-white p-4 rounded-xl transition-all duration-200 transform hover:scale-105 hover:shadow-lg text-left`}
              >
                <div className="flex items-center gap-3">
                  {action.icon}
                  <div>
                    <h3 className="font-semibold text-sm">{action.title}</h3>
                    <p className="text-xs opacity-90">{action.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Main Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {infoCards.map((card, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-${card.color}-100 text-${card.color}-600`}>
                  {card.icon}
                </div>
                <div className="flex items-center gap-1 text-sm">
                  {card.changeType === 'increase' ? (
                    <LuArrowUpRight className="w-4 h-4 text-green-600" />
                  ) : (
                    <LuArrowDownRight className="w-4 h-4 text-red-600" />
                  )}
                  <span className={card.changeType === 'increase' ? 'text-green-600' : 'text-red-600'}>
                    {card.change}
                  </span>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-1">{card.value}</h3>
              <p className="text-gray-600 text-sm">{card.title}</p>
            </div>
          ))}
        </div>

        {/* Performance Metrics */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Performance Metrics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {performanceMetrics.map((metric, index) => (
              <div key={index} className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">{metric.label}</span>
                  <div className="flex items-center gap-1 text-xs">
                    {metric.changeType === 'increase' ? (
                      <LuArrowUpRight className="w-3 h-3 text-green-600" />
                    ) : (
                      <LuArrowDownRight className="w-3 h-3 text-blue-600" />
                    )}
                    <span className={metric.changeType === 'increase' ? 'text-green-600' : 'text-blue-600'}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className={`text-2xl font-bold ${metric.color}`}>{metric.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
              Task Approval Status
            </h3>
              <LuCircle className="w-5 h-5 text-gray-400" />
            </div>
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <>
                {console.log('Pie Chart Data being passed:', getPieChartData())}
                {getPieChartData().length > 0 && getPieChartData()[0].status !== 'No Tasks' ? (
                  <CustomPieChart data={getPieChartData()} colors={pieChartColors} />
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    <div className="text-center">
                      <p className="text-lg font-medium mb-2">No Task Data Available</p>
                      <p className="text-sm">Create your first task to see the approval and rejection status chart</p>
                      <button 
                        onClick={() => navigate("/domain-manager/create-task")}
                        className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                      >
                        Create Task
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
              Project Priority Levels
            </h3>
              <LuUsers className="w-5 h-5 text-gray-400" />
            </div>
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <>
                {console.log('Bar Chart Data being passed:', getBarChartData())}
                {getBarChartData().length > 0 && getBarChartData()[0].priority !== 'No Data' ? (
                  <CustomBarChart data={getBarChartData()} />
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    <div className="text-center">
                      <p className="text-lg font-medium mb-2">No Priority Data Available</p>
                      <p className="text-sm">Create projects with different priorities to see the chart</p>
                      <button 
                        onClick={() => navigate("/domain-manager/create-task")}
                        className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                      >
                        Create Project
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Recent Activity and Recent Projects */}
        <div className="grid grid-cols-1 lg:grid-cols-1 gap-6 mb-8">
        

          {/* Recent Projects */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Recent Projects</h3>
              <button 
                onClick={() => navigate("/domain-manager/tasks")}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                View All
              </button>
            </div>
            <div className="space-y-3">
              {dashboardData?.recentTasks?.slice(0, 5).map((task) => (
                <div key={task._id} className="p-3 rounded-lg border border-gray-100 hover:border-gray-200 transition-colors cursor-pointer"
                     onClick={() => navigate(`/domain-manager/task-report/${task._id}`)}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-800 text-sm truncate">{task.title}</h4>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        task.status === "Completed" ? "bg-green-100 text-green-800" :
                        task.status === "In Progress" ? "bg-blue-100 text-blue-800" :
                        "bg-yellow-100 text-yellow-800"
                      }`}>
                        {task.status}
                      </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                        task.priority === "High" ? "bg-red-100 text-red-800" :
                        task.priority === "Medium" ? "bg-yellow-100 text-yellow-800" :
                        "bg-green-100 text-green-800"
                      }`}>
                        {task.priority}
                      </span>
                  </div>
                </div>
              ))}
              {(!dashboardData?.recentTasks || dashboardData.recentTasks.length === 0) && (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-sm">No recent projects found</p>
                  <p className="text-xs mt-1">Create your first project to get started</p>
                </div>
              )}
            </div>
          </div>
        </div>



        {/* Team Performance Summary */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-800">Team Performance Summary</h3>
        
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">87%</div>
              <div className="text-sm text-gray-600">Task Completion Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">4.6/5</div>
              <div className="text-sm text-gray-600">Average Team Rating</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600 mb-2">92%</div>
              <div className="text-sm text-gray-600">On-Time Delivery</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">15</div>
              <div className="text-sm text-gray-600">Active Team Members</div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default DomainManagerDashboard;
