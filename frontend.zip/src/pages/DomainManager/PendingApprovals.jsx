import React, { useContext, useEffect, useState } from "react";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import axiosInstance from "../../utils/axiosInstance";
import { API_PATHS } from "../../utils/apiPaths";
import { LuCheck, LuX, LuClock } from "react-icons/lu";
import { useNavigate } from "react-router-dom";

const PendingApprovals = () => {
  const { user } = useContext(UserContext);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    console.log("PendingApprovals useEffect triggered");
    console.log("User:", user);
    if (user) {
      console.log("User role:", user.role);
      console.log("User ID:", user._id);
      fetchPendingApprovals();
    } else {
      console.log("No user found in context");
    }
  }, [user]);

  const fetchPendingApprovals = async () => {
    try {
      setLoading(true);
      console.log("Making API call to:", API_PATHS.TASKS.GET_PENDING_APPROVAL);
      console.log("User token:", localStorage.getItem('token'));
      
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_PENDING_APPROVAL);
      console.log("Pending approvals response:", response);
      console.log("Response data:", response.data);
      console.log("Response status:", response.status);
      
      setTasks(response.data || []);
    } catch (error) {
      console.error("Error fetching pending approvals:", error);
      console.error("Error response:", error.response);
      console.error("Error status:", error.response?.status);
      console.error("Error data:", error.response?.data);
      
      // Show user-friendly error message
      if (error.response?.status === 401) {
        console.error("Unauthorized - User not logged in or not a domain manager");
      } else if (error.response?.status === 403) {
        console.error("Forbidden - User doesn't have permission");
      } else if (error.response?.status === 500) {
        console.error("Server error - Backend issue");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">
            Pending Approvals
          </h1>
          <p className="text-gray-600">
            Review and approve completed todo items from projects
          </p>
        </div>

        <div className="space-y-6">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading pending approvals...</p>
            </div>
          ) : tasks.length > 0 ? (
            tasks.map((task) => {
              // Get pending approval items
              const pendingItems = task.todoCheckList?.filter(todo => 
                todo && typeof todo === 'object' && 
                todo.completed === true && 
                todo.approved !== true && 
                todo.rejected !== true
              ) || [];

              return (
                <div
                  key={task._id}
                  className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigate(`/domain-manager/task-report/${task._id}`)}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-800">
                        {task.title || 'Untitled Task'}
                      </h3>
                      <p className="text-gray-600 text-sm mt-1">
                        Assigned to: {task.assignedTo?.map(user => user.name).join(", ") || 'No users assigned'}
                      </p>
                      <p className="text-gray-500 text-xs mt-1">
                        Status: {task.status || 'Unknown'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        <LuClock className="w-3 h-3 mr-1" />
                        {pendingItems.length} Pending
                      </span>
                    </div>
                  </div>
                  
                  {task.description && (
                    <p className="text-gray-700 mb-3 line-clamp-2">{task.description}</p>
                  )}
                  
                  {pendingItems.length > 0 && (
                    <div className="mt-3">
                      <p className="text-sm font-medium text-gray-700 mb-2">Items pending approval:</p>
                      <div className="flex flex-wrap gap-2">
                        {pendingItems.map((todo, idx) => (
                          <span key={idx} className="inline-flex items-center px-3 py-1 bg-yellow-50 text-yellow-800 text-xs rounded-full border border-yellow-200">
                            {todo.text || `Item ${idx + 1}`}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 text-6xl mb-4">✅</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No pending approvals
              </h3>
              <p className="text-gray-500">
                All completed todo items have been approved.
              </p>
              
              {/* Debug information */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200 text-left">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Debug Information:</h4>
                <p className="text-xs text-gray-600 mb-1">Tasks received: {tasks.length}</p>
                <p className="text-xs text-gray-600 mb-1">User role: {user?.role}</p>
                <p className="text-xs text-gray-600">User ID: {user?._id}</p>
                {tasks.length > 0 && (
                  <details className="mt-2">
                    <summary className="text-xs text-blue-600 cursor-pointer">Show raw task data</summary>
                    <pre className="text-xs text-gray-500 mt-2 bg-white p-2 rounded border overflow-auto max-h-32">
                      {JSON.stringify(tasks, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PendingApprovals;
