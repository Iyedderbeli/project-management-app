import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useNavigate, useParams } from "react-router-dom";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import TaskReviewModal from "../../components/Modal/TaskReviewModal";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const TaskReview = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchTask();
    }
  }, [id]);

  const fetchTask = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_TASK_BY_ID(id));
      if (response.data) {
        setTask(response.data);
      } else {
        toast.error("Task not found");
        navigate("/domain-manager/tasks");
      }
    } catch (error) {
      console.error("Error fetching task:", error);
      toast.error("Failed to fetch task");
      navigate("/domain-manager/tasks");
    } finally {
      setLoading(false);
    }
  };

  const handleTaskUpdated = () => {
    // Refresh task data after update
    fetchTask();
  };

  const handleAssignUsers = () => {
    // Handle user assignment if needed
    fetchTask();
  };

  const handleClose = () => {
    navigate("/domain-manager/tasks");
  };

  if (loading) {
    return (
      <DashboardLayout activeMenu="Tasks">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading task...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (!task) {
    return (
      <DashboardLayout activeMenu="Tasks">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <p className="text-gray-600 mb-4">Task not found</p>
            <button
              onClick={() => navigate("/domain-manager/tasks")}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Back to Tasks
            </button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout activeMenu="Tasks">
      <div className="mt-5">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Task Review</h2>
          <button
            onClick={handleClose}
            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
          >
            Close
          </button>
        </div>
        
        {/* Task Review Modal - Always open in this context */}
        <TaskReviewModal
          isOpen={true}
          onClose={handleClose}
          task={task}
          onTaskUpdated={handleTaskUpdated}
          onAssignUsers={handleAssignUsers}
        />
      </div>
    </DashboardLayout>
  );
};

export default TaskReview;
