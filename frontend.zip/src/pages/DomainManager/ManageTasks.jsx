import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuPlus, LuUsers, LuX } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import TaskCard from "../../components/Cards/TaskCard";
import SelectUsers from "../../components/Inputs/SelectUsers";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import MessagingInterface from "../../components/MessagingInterface";
import TaskReviewModal from "../../components/Modal/TaskReviewModal";
import TaskStatusTabs from "../../components/TaskStatusTabs";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const DomainManagerTasks = () => {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showTaskReviewModal, setShowTaskReviewModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showMessagingModal, setShowMessagingModal] = useState(false);
  const [selectedAdminForMessaging, setSelectedAdminForMessaging] = useState(null);
  const [selectedTaskForMessaging, setSelectedTaskForMessaging] = useState(null);

  const tabs = [
    { id: "all", label: "All Tasks" },
    { id: "pending", label: "Pending Approval" },
    { id: "rating", label: "Pending Rating" },
  ];

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_ALL_TASKS);
      setTasks(response.data.tasks || []);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      toast.error("Failed to fetch tasks");
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = (status) => {
    setActiveTab(status);
  };

  const handleCreateTask = () => {
    navigate("/domain-manager/create-task");
  };

  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setShowTaskReviewModal(true);
  };

  const handleAssignUsers = (task) => {
    setSelectedTask(task);
    setSelectedUsers(task.assignedTo?.map(user => user._id) || []);
    setShowAssignModal(true);
  };

  const handleTaskUpdated = () => {
    fetchTasks(); // Refresh the tasks list
  };

  const handleAssignSubmit = async () => {
    if (selectedUsers.length === 0) {
      toast.error("Please select at least one user");
      return;
    }

    try {
      await axiosInstance.put(API_PATHS.TASKS.ASSIGN_USERS(selectedTask._id), {
        assignedTo: selectedUsers
      });
      
      toast.success("Users assigned successfully");
      setShowAssignModal(false);
      fetchTasks(); // Refresh the tasks list
    } catch (error) {
      console.error("Error assigning users:", error);
      toast.error("Failed to assign users");
    }
};

  const handleRejectTodo = (taskId) => {
    // Navigate to task report page where domain manager can reject specific items
    navigate(`/domain-manager/task-report/${taskId}`);
  };

  const handleStartConversation = (admin, task) => {
    setSelectedAdminForMessaging(admin);
    setSelectedTaskForMessaging(task);
    setShowMessagingModal(true);
  };

  const handleCloseMessaging = () => {
    setShowMessagingModal(false);
    setSelectedAdminForMessaging(null);
    setSelectedTaskForMessaging(null);
  };

  const getCurrentTasks = () => {
    switch (activeTab) {
      case "pending":
        return tasks.filter(task => 
          task.todoCheckList?.some(deliverable => !deliverable.approved && !deliverable.rejected)
        );
      case "rating":
        return tasks.filter(task => 
          task.status === "Completed" && (!task.qualityRating || !task.timeRating)
        );
      default:
        return tasks;
    }
  };

  const getTabLabel = (tabId) => {
    const currentTasks = getCurrentTasks();
    switch (tabId) {
      case "pending":
        return `Pending Approval/Rejection (${currentTasks.length})`;
      case "rating":
        return `Pending Rating (${currentTasks.length})`;
      default:
        return `All Tasks (${tasks.length})`;
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <DashboardLayout activeMenu="Manage Projects">
      <div className="mt-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Manage Projects</h2>
          <div className="flex items-center gap-3">
            <button
              onClick={handleCreateTask}
              className="btn-primary flex items-center gap-2"
            >
              <LuPlus className="w-4 h-4" />
              Create Task
            </button>
          </div>
        </div>

 

        <div className="mt-6">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-gray-500 mt-2">Loading tasks...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getCurrentTasks().map((task) => (
                <TaskCard
                  key={task._id}
                  title={task.title}
                  description={task.description}
                  priority={task.priority}
                  status={task.status}
                  progress={task.progress}
                  createdAt={task.createdAt}
                  dueDate={task.dueDate}
                  assignedTo={task.assignedTo || []}
                  attachmentCount={task.attachments?.length || 0}
                  completedTodoCount={task.completedTodoCount || 0}
                  todoCheckList={task.todoCheckList || []}
                  onClick={() => handleTaskClick(task)}
                  showActions={true}
                  userRole="domain_manager"
                  onAssignUsers={() => handleAssignUsers(task)}
                  onRejectTodo={handleRejectTodo}
                  onStartConversation={handleStartConversation}
                  onRateTask={() => handleTaskClick(task)} // This will open the TaskReviewModal for rating
                  task={task}
                />
              ))}
            </div>
          )}

          {!loading && getCurrentTasks().length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">
                {activeTab === "pending" 
                  ? "No tasks pending approval or rejection" 
                  : activeTab === "rating" 
                  ? "No tasks pending rating" 
                  : "No tasks found"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Task Review Modal */}
      <TaskReviewModal
        isOpen={showTaskReviewModal}
        onClose={() => setShowTaskReviewModal(false)}
        task={selectedTask}
        onTaskUpdated={handleTaskUpdated}
        onAssignUsers={handleAssignUsers}
      />

      {/* Assign Users Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="relative bg-white rounded-lg shadow-sm max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">Assign Users to Task</h3>
              <button 
                className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center cursor-pointer" 
                onClick={() => setShowAssignModal(false)}
              >
                <LuX className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 md:p-5">
              <div className="p-4">
                <div className="mb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {selectedTask?.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Select users to assign to this task
                  </p>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Assign To
                  </label>
                  <SelectUsers
                    selectedUsers={selectedUsers}
                    setSelectedUsers={setSelectedUsers}
                  />
                </div>

                <div className="flex justify-end gap-2 mt-6">
                  <button
                    onClick={() => setShowAssignModal(false)}
                    className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAssignSubmit}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center gap-2"
                  >
                    <LuUsers className="w-4 h-4" />
                    Assign Users
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Messaging Interface Modal */}
      {showMessagingModal && selectedAdminForMessaging && selectedTaskForMessaging && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl h-5/6 flex flex-col shadow-2xl border border-gray-200">
            <MessagingInterface
              taskId={selectedTaskForMessaging._id}
              domainManagerId={selectedAdminForMessaging._id}
              onClose={handleCloseMessaging}
            />
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default DomainManagerTasks;