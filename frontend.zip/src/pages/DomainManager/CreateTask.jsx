import moment from "moment";
import { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuTrash2, LuUsers } from "react-icons/lu";
import { useLocation, useNavigate } from "react-router-dom";
import DeleteAlert from "../../components/DeleteAlert";
import AddAttahchmentsInput from "../../components/Inputs/AddAttahchmentsInput";
import SelectDropdown from "../../components/Inputs/SelectDropdown";
import SelectUsers from "../../components/Inputs/SelectUsers";
import TodoListInput from "../../components/Inputs/TodoListInput";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import Modal from "../../components/Modal";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import { PRIORITY_DATA } from "../../utils/data";

const CreateTask = () => {
  const location = useLocation();
  const { taskId } = location.state || {};
  const navigate = useNavigate();
  const { user } = useContext(UserContext);

  const [taskData, setTaskData] = useState({
    title: "",
    description: "",
    priority: "Low",
    dueDate: null,
    assignedTo: [],
    assignedDomainManagers: [], // Add field for assigned domain managers
    todoCheckList: [],
    attachments: [],
    requiredSkills: [], // Add required skills field
  });

  const [currentTask, setCurrentTask] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [openDeleteAlert, setOpenDeleteAlert] = useState(false);
  const [newSkill, setNewSkill] = useState("");

  const handleValueChange = (key, value) => {
    setTaskData((prevData) => ({ ...prevData, [key]: value }));
  };

  const addRequiredSkill = () => {
    if (newSkill.trim() && !taskData.requiredSkills.includes(newSkill.trim())) {
      setTaskData(prev => ({
        ...prev,
        requiredSkills: [...prev.requiredSkills, newSkill.trim()]
      }));
      setNewSkill("");
    }
  };

  const removeRequiredSkill = (skillToRemove) => {
    setTaskData(prev => ({
      ...prev,
      requiredSkills: prev.requiredSkills.filter(skill => skill !== skillToRemove)
    }));
  };

  const clearData = () => {
    setTaskData({
      title: "",
      description: "",
      priority: "Low",
      dueDate: null,
      assignedTo: [],
      assignedDomainManagers: [], // Add field for assigned domain managers
      todoCheckList: [],
      attachments: [],
      requiredSkills: [],
    });
    setNewSkill("");
  };

  // Create Task
  const createTask = async () => {
    setLoading(true);
    try {
      const todolist = taskData.todoCheckList?.map((item) => ({
        text: item,
        completed: false,
      }));

      const payload = {
        ...taskData,
        dueDate: new Date(taskData.dueDate).toISOString(),
        todoCheckList: todolist,
      };



      const response = await axiosInstance.post(
        API_PATHS.TASKS.CREATE_TASK,
        payload
      );

      toast.success("Project created successfully.");
      clearData();
      navigate("/domain-manager/tasks");
    } catch (error) {
      console.error("Error creating task:", error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  // Update Task
  const updateTask = async () => {
    setLoading(true);
    try {
      const todolist = taskData.todoCheckList?.map((item) => {
        const prevTodoCheckList = currentTask?.todoCheckList || [];
        const matchedTask = prevTodoCheckList.find(
          (task) => task.text === item
        );

        return {
          text: item,
          completed: matchedTask ? matchedTask.completed : false,
        };
      });

      const response = await axiosInstance.put(
        API_PATHS.TASKS.UPDATE_TASK(taskId),
        {
          ...taskData,
          dueDate: new Date(taskData.dueDate).toISOString(),
          todoCheckList: todolist,
        }
      );

      toast.success("Project Updated Successfully");
      navigate("/domain-manager/tasks");
    } catch (error) {
      console.error("Error Updating Task: ", error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    setError(null);

    // Input validation
    if (!taskData.title.trim()) {
      setError("Project title is required.");
      return;
    }
    if (!taskData.description.trim()) {
      setError("Project description is required.");
      return;
    }

    if (!taskData.dueDate) {
      setError("Project due date is required.");
      return;
    }

    if (taskData.assignedTo?.length === 0) {
      setError("Project not assigned to any Member.");
      return;
    }

    if (taskData.todoCheckList?.length === 0) {
      setError("Add atleast one To-Do task.");
      return;
    }
    if (taskId) {
      updateTask();
      return;
    }

    createTask();
  };

  // get Task info by ID
  const getTaskDetailsByID = async () => {
    try {
      const response = await axiosInstance.get(
        API_PATHS.TASKS.GET_TASK_BY_ID(taskId)
      );
      if (response.data) {
        const taskInfo = response.data;
        setCurrentTask(taskInfo);

        setTaskData((prevState) => ({
          title: taskInfo.title,
          description: taskInfo.description,
          priority: taskInfo.priority,
          dueDate: taskInfo.dueDate
            ? moment(taskInfo.dueDate).format("YYYY-MM-DD")
            : null,
          assignedTo: Array.isArray(taskInfo?.assignedTo)
            ? taskInfo.assignedTo.map((item) => item?._id)
            : taskInfo?.assignedTo
            ? [taskInfo.assignedTo._id]
            : [],
          assignedDomainManagers: Array.isArray(taskInfo?.assignedDomainManagers)
            ? taskInfo.assignedDomainManagers
            : taskInfo?.assignedDomainManagers
            ? [taskInfo.assignedDomainManagers]
            : [],
          todoCheckList:
            taskInfo?.todoCheckList?.map((item) => item?.text) || [],
          attachments: taskInfo?.attachments || [],
          requiredSkills: taskInfo?.requiredSkills || [],
        }));
      }
    } catch (error) {
      console.error("Error fetching task details:", error);
    }
  };

  // Delete Task
  const deleteTask = async () => {
    try {
      await axiosInstance.delete(API_PATHS.TASKS.DELETE_TASK(taskId));
      setOpenDeleteAlert(false);
      toast.success("Deleted Successfully");
      navigate("/domain-manager/tasks");
    } catch (error) {
      console.error(
        "Error Deleting: ",
        error.response?.data?.message || error.message
      );
    }
  };

  useEffect(() => {
    if (taskId) {
      getTaskDetailsByID(taskId);
    }

    return () => {};
  }, [taskId]);

  return (
    <DashboardLayout activeMenu="Create Project">
      <div className="mt-5">
        <div className="grid grid-cols-1 md:grid-cols-4 mt-4">
          <div className="form-card col-span-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xl md:text-xl font-medium">
                {taskId ? "Update Project" : "Create Project"}
              </h2>

              {taskId && (
                <button
                  className="flex items-center gap-1.5 text-[13px] font-medium text-rose-500 bg-rose-50 rounded px-2 py-1 border border-rose-100 hover:border-rose-300 cursor-pointer"
                  onClick={() => {
                    setOpenDeleteAlert(true);
                  }}
                >
                  <LuTrash2 className="text-base" />
                  Delete
                </button>
              )}
            </div>
            <div className="mt-4">
              <label className="text-xs font-medium text-slate-600">
                Project Title
              </label>
              <input
                placeholder="Create App UI"
                className="form-input focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                value={taskData.title}
                onChange={({ target }) =>
                  handleValueChange("title", target.value)
                }
              />
            </div>

            <div className="mt-3">
              <label className="text-xs font-medium text-slate-600">
                Description
              </label>
              <textarea
                placeholder="Describe project"
                className="form-input focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                rows={4}
                value={taskData.description}
                onChange={({ target }) =>
                  handleValueChange("description", target.value)
                }
              />
            </div>

            <div className="grid grid-cols-12 gap-4 mt-2">
              <div className="col-span-6 md:col-span-4">
                <label className="text-xs font-medium text-slate-600 ">
                  Priority
                </label>
                <SelectDropdown
                  options={PRIORITY_DATA}
                  value={taskData.priority}
                  onChange={(value) => handleValueChange("priority", value)}
                  placeholder="Select Priority"
                  className="form-input "
                />
              </div>

              <div className="col-span-6 md:col-span-4 text-black">
                <label className="text-xs font-medium text-slate-600">
                  Due Date
                </label>
                <input
                  placeholder="Create App UI"
                  className="w-full text-sm text-black bg-white rounded-md px-2.5 py-3 mt-0 border border-slate-100 outline-none placeholder:text-gray-500 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={taskData.dueDate || ""}
                  onChange={({ target }) =>
                    handleValueChange("dueDate", target.value)
                  }
                  type="date"
                />
              </div>
              <div className="col-span-12 md:col-span-4">
                <label className="text-xs font-medium text-slate-600">
                  Required Skills
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g., JavaScript, Project Management"
                    value={newSkill}
                    onChange={({ target }) => setNewSkill(target.value)}
                    className="flex-1 text-sm text-black bg-white rounded-md px-2.5 py-3 mt-0 border border-slate-100 outline-none placeholder:text-gray-500 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    onKeyPress={(e) => e.key === 'Enter' && addRequiredSkill()}
                  />
                  <button
                    type="button"
                    onClick={addRequiredSkill}
                    className="px-3 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                  >
                    Add
                  </button>
                </div>
                {taskData.requiredSkills.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {taskData.requiredSkills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                      >
                        {skill}
                        <button
                          type="button"
                          onClick={() => removeRequiredSkill(skill)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="grid grid-cols-12 gap-4 mt-2">
              <div className="col-span-12">
                <label className="text-xs font-medium text-slate-600">
                  Assign To
                </label>

                <SelectUsers
                  selectedUsers={taskData.assignedTo}
                  setSelectedUsers={(value) => {
                    handleValueChange("assignedTo", value);
                  }}
                  requiredSkills={taskData.requiredSkills}
                  showSkills={true}
                />
              </div>
            </div>

            {/* Display Assigned Domain Managers */}
            <div className="mt-3">
              <label className="text-xs font-medium text-slate-600 flex items-center gap-2">
                <LuUsers className="w-4 h-4" />
                Assigned Domain Managers
              </label>
              {taskData.assignedDomainManagers && taskData.assignedDomainManagers.length > 0 ? (
                <div className="mt-2 p-3 bg-blue-50 rounded-md border border-blue-200">
                  <div className="flex flex-wrap gap-2">
                    {taskData.assignedDomainManagers.map((domainManager, index) => {
                      const isCurrentUser = typeof domainManager === 'object' && domainManager._id === user?._id;
                      const domainManagerName = typeof domainManager === 'object' && domainManager.name 
                        ? domainManager.name 
                        : `Domain Manager ${index + 1}`;
                      
                      return (
                        <span
                          key={index}
                          className={`inline-flex items-center gap-2 px-3 py-1.5 text-sm rounded-full font-medium ${
                            isCurrentUser 
                              ? 'bg-green-100 text-green-800 border border-green-200' 
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          <span className={`w-2 h-2 rounded-full ${
                            isCurrentUser ? 'bg-green-600' : 'bg-blue-600'
                          }`}></span>
                          {domainManagerName}
                          {isCurrentUser && (
                            <span className="text-xs bg-green-200 text-green-700 px-1.5 py-0.5 rounded-full">
                              You
                            </span>
                          )}
                        </span>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-blue-600">
                      {taskData.assignedDomainManagers.length} domain manager{taskData.assignedDomainManagers.length !== 1 ? 's' : ''} assigned
                    </p>
                    <p className="text-xs text-blue-600">
                      These domain managers are responsible for overseeing this project
                    </p>
                  </div>
                </div>
              ) : (
                <div className="mt-2 p-3 bg-gray-50 rounded-md border border-gray-200">
                  <div className="flex items-center gap-2 text-gray-500">
                    <span className="w-2 h-2 bg-gray-400 rounded-full"></span>
                    <span className="text-sm">No domain managers assigned yet</span>
                  </div>
                  <div className="mt-2">
                    <p className="text-xs text-gray-500">
                      Domain managers will be assigned by administrators to oversee this project
                    </p>
                    {user && (
                      <p className="text-xs text-gray-400 mt-1">
                        You are currently viewing this project as a domain manager
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="mt-3">
              <label className="text-xs font-medium text-slate-600">
                Tasks List
              </label>

              <TodoListInput
                todoList={taskData?.todoCheckList}
                setTodoList={(value) =>
                  handleValueChange("todoCheckList", value)
                }
              />
            </div>
            <div className="mt-3">
              <label className="text-xs font-medium text-slate-600">
                Add Attachments
              </label>

              <AddAttahchmentsInput
                attachments={taskData?.attachments}
                setAttachments={(value) =>
                  handleValueChange("attachments", value)
                }
              />
            </div>

            {error && (
              <p className="text-red-500 text-xs font-medium mt-5">{error}</p>
            )}

            <div className="flex justify-end mt-7">
              <button
                className="add-btn"
                onClick={handleSubmit}
                disabled={loading}
              >
                {taskId ? "Update Project" : "Create Project"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <Modal
        isOpen={openDeleteAlert}
        onClose={() => setOpenDeleteAlert(false)}
        title="Delete Project"
      >
        <DeleteAlert
          content="Are you sure you want to delete this project?"
          onDelete={() => deleteTask()}
        />
      </Modal>
    </DashboardLayout>
  );
};
export default CreateTask; 