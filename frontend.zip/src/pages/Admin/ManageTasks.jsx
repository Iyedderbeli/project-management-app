import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuDownload, LuPlus, LuUsers } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import TaskCard from "../../components/Cards/TaskCard";
import SelectDomainManagers from "../../components/Inputs/SelectDomainManagers";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import MessagingInterface from "../../components/MessagingInterface";
import TaskStatusTabs from "../../components/TaskStatusTabs";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const ManageTasks = () => {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const [readyForAssignmentTasks, setReadyForAssignmentTasks] = useState([]);
  const [rejectedTasks, setRejectedTasks] = useState([]);
  const [showAssignDomainManagersModal, setShowAssignDomainManagersModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedDomainManagers, setSelectedDomainManagers] = useState([]);
  const [showMessagingModal, setShowMessagingModal] = useState(false);
  const [selectedDomainManagerForMessaging, setSelectedDomainManagerForMessaging] = useState(null);
  const [selectedTaskForMessaging, setSelectedTaskForMessaging] = useState(null);

  const tabs = [
    { id: "all", label: "All Tasks" },
    { id: "ready", label: "Ready for Assignment" },
    { id: "rejected", label: "Rejected Tasks" },
  ];

  const getAllTasks = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_ALL_TASKS);
      setTasks(response.data.tasks || []);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      toast.error("Failed to fetch tasks");
    } finally {
      setLoading(false);
    }
  };

  const getReadyForAssignmentTasks = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_READY_FOR_ASSIGNMENT);
      setReadyForAssignmentTasks(response.data || []);
    } catch (error) {
      console.error("Error fetching ready for assignment tasks:", error);
    }
  };

  const getRejectedTasks = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_REJECTED_TASKS);
      setRejectedTasks(response.data || []);
    } catch (error) {
      console.error("Error fetching rejected tasks:", error);
    }
  };

  const handleClick = (taskData) => {
    navigate("/admin/create-task", { state: { taskId: taskData._id } });
  };

  const handleAssignDomainManagers = (task) => {
    setSelectedTask(task);
    setSelectedDomainManagers(task.assignedDomainManagers?.map(user => user._id) || []);
    setShowAssignDomainManagersModal(true);
  };

  const handleAssignDomainManagersSubmit = async () => {
    if (selectedDomainManagers.length === 0) {
      toast.error("Please select at least one domain manager");
      return;
    }

    try {
      await axiosInstance.put(API_PATHS.TASKS.ASSIGN_DOMAIN_MANAGERS(selectedTask._id), {
        assignedDomainManagers: selectedDomainManagers
      });
      
      toast.success("Domain managers assigned successfully");
      setShowAssignDomainManagersModal(false);
      getAllTasks(); // Refresh tasks list
      getReadyForAssignmentTasks(); // Refresh ready for assignment tasks
    } catch (error) {
      console.error("Error assigning domain managers:", error);
      toast.error("Failed to assign domain managers");
    }
  };

  const handleStartConversation = (domainManager, task) => {
    setSelectedDomainManagerForMessaging(domainManager);
    setSelectedTaskForMessaging(task);
    setShowMessagingModal(true);
  };

  const handleCloseMessaging = () => {
    setShowMessagingModal(false);
    setSelectedDomainManagerForMessaging(null);
    setSelectedTaskForMessaging(null);
  };

  const handleDownloadReport = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.REPORTS.EXPORT_TASKS, {
        responseType: "blob",
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "tasks-report.xlsx");
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success("Report downloaded successfully");
    } catch (error) {
      console.error("Error downloading report:", error);
      toast.error("Failed to download report");
    }
  };

  useEffect(() => {
    getAllTasks();
    getReadyForAssignmentTasks();
    getRejectedTasks();
  }, []);

  const getCurrentTasks = () => {
    switch (activeTab) {
      case "ready":
        return readyForAssignmentTasks;
      case "rejected":
        return rejectedTasks;
      default:
        return tasks;
    }
  };

  const getTabLabel = (tabId) => {
    switch (tabId) {
      case "ready":
        return `Ready for Assignment (${readyForAssignmentTasks.length})`;
      case "rejected":
        return `Rejected Tasks (${rejectedTasks.length})`;
      default:
        return `All Tasks (${tasks.length})`;
    }
  };

  return (
    <DashboardLayout activeMenu="Manage Tasks">
      <div className="mt-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">Manage Tasks</h2>
          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadReport}
              className="download-btn flex items-center gap-2"
            >
              <LuDownload className="w-4 h-4" />
              Download Report
            </button>
            <button
              onClick={() => navigate("/admin/create-task")}
              className="btn-primary flex items-center gap-2"
            >
              <LuPlus className="w-4 h-4" />
              Create Task
            </button>
          </div>
        </div>

        <div className="mt-6">
          <TaskStatusTabs
            tabs={tabs.map(tab => ({ ...tab, label: getTabLabel(tab.id) }))}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />
        </div>

        <div className="mt-6">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-gray-500 mt-2">Loading tasks...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getCurrentTasks().map((task) => (
                <TaskCard
                  key={task._id}
                  title={task.title}
                  description={task.description}
                  priority={task.priority}
                  status={task.status}
                  progress={task.progress}
                  createdAt={task.createdAt}
                  dueDate={task.dueDate}
                  assignedTo={task.assignedTo || []}
                  attachmentCount={task.attachments?.length || 0}
                  completedTodoCount={task.completedTodoCount || 0}
                  todoCheckList={task.todoCheckList || []}
                  onClick={() => handleClick(task)}
                  showActions={true}
                  userRole="admin"
                  onAssignDomainManagers={handleAssignDomainManagers}
                  onStartConversation={handleStartConversation}
                  task={task}
                />
              ))}
            </div>
          )}

          {!loading && getCurrentTasks().length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">
                {activeTab === "ready" 
                  ? "No tasks ready for assignment" 
                  : activeTab === "rejected" 
                  ? "No rejected tasks" 
                  : "No tasks found"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Assign Domain Managers Modal */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 ${showAssignDomainManagersModal ? 'block' : 'hidden'}`}
        onClick={() => setShowAssignDomainManagersModal(false)}
      >
        <div
          className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full"
          onClick={(e) => e.stopPropagation()}
        >
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {selectedTask?.title}
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Select domain managers to review this task
          </p>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Assign Domain Managers
            </label>
            <SelectDomainManagers
              selectedDomainManagers={selectedDomainManagers}
              setSelectedDomainManagers={setSelectedDomainManagers}
              requiredExpertise={selectedTask?.requiredSkills || []}
            />
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <button
              onClick={() => setShowAssignDomainManagersModal(false)}
              className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleAssignDomainManagersSubmit}
              className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex items-center gap-2"
            >
              <LuUsers className="w-4 h-4" />
              Assign Domain Managers
            </button>
          </div>
        </div>
      </div>

      {/* Messaging Interface Modal */}
      {showMessagingModal && selectedDomainManagerForMessaging && selectedTaskForMessaging && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl h-5/6 flex flex-col shadow-2xl border border-gray-200">
            <MessagingInterface
              taskId={selectedTaskForMessaging._id}
              domainManagerId={selectedDomainManagerForMessaging._id}
              onClose={handleCloseMessaging}
            />
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default ManageTasks;
