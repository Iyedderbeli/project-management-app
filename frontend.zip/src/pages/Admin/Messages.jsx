import React from 'react';
import MessagingSystem from '../../components/MessagingSystem';

const Messages = () => {
  return (
    <div className="h-full">
      <MessagingSystem />
    </div>
  );
};

export default Messages; 