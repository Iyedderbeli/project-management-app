import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuFileSpreadsheet } from "react-icons/lu";
import UserCard from "../../components/Cards/UserCard";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const ManageUsers = () => {
  const [allUsers, setAllUsers] = useState([]);
  const [groupedUsers, setGroupedUsers] = useState({});

  const getAllUsers = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.USERS.GET_ALL_USERS);
      if (response.data?.length > 0) {
        setAllUsers(response.data);
        
        // Group users by role
        const grouped = response.data.reduce((acc, user) => {
          const role = user.role || 'other';
          if (!acc[role]) {
            acc[role] = [];
          }
          acc[role].push(user);
          return acc;
        }, {});
        
        setGroupedUsers(grouped);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  //Download Task Report
  const handleDownloadReport = async (userId) => {
    try {
      const response = await axiosInstance.get(API_PATHS.REPORTS.EXPORT_USERS, {
        responseType: "blob",
      });
      // Create a URL for the blob
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "user_details.xlsx");
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading expense details:", error);
      toast.error("Failed to download expense details. Please try again.");
    }

  };

  useEffect(() => {
    getAllUsers();

    return () => {};
  }, []);

  return (
    <DashboardLayout activeMenu="Team Members">
      <div className="mt-5 mb-10">
        <div className="flex md:flex-row md:items-center justify-between">
          <div>
            <h2 className="text-xl md:text-xl font-medium">Team Members & Domain Managers</h2>
            <p className="text-sm text-gray-500 mt-1">View all team members including domain managers</p>
          </div>
          <button
            className="flex md:flex download-btn"
            onClick={handleDownloadReport}
          >
            <LuFileSpreadsheet className="text-lg" />
            Download Report
          </button>
        </div>
        {/* Domain Managers Section */}
        {groupedUsers.domain_manager && groupedUsers.domain_manager.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
              Domain Managers ({groupedUsers.domain_manager.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {groupedUsers.domain_manager.map((user) => (
                <UserCard key={user._id} userInfo={user} />
              ))}
            </div>
          </div>
        )}

        {/* Team Members Section */}
        {(groupedUsers.member || groupedUsers.user) && (
          <div className="mt-6">
            <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Team Members ({(groupedUsers.member?.length || 0) + (groupedUsers.user?.length || 0)})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[...(groupedUsers.member || []), ...(groupedUsers.user || [])].map((user) => (
                <UserCard key={user._id} userInfo={user} />
              ))}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ManageUsers;
