import moment from "moment";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuTrash2 } from "react-icons/lu";
import { useLocation, useNavigate } from "react-router-dom";
import DeleteAlert from "../../components/DeleteAlert";
import AddAttahchmentsInput from "../../components/Inputs/AddAttahchmentsInput";
import SelectDomainManagers from "../../components/Inputs/SelectDomainManagers";
import SelectDropdown from "../../components/Inputs/SelectDropdown";
import TodoListInput from "../../components/Inputs/TodoListInput";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import { PRIORITY_DATA } from "../../utils/data";

const CreateTask = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Get taskId from either location.state or URL query parameter
  const { taskId: stateTaskId } = location.state || {};
  const searchParams = new URLSearchParams(location.search);
  const queryTaskId = searchParams.get('id');
  const taskId = stateTaskId || queryTaskId;

  const [taskData, setTaskData] = useState({
    title: "",
    description: "",
    priority: "Low",
    dueDate: null,
    assignedTo: [], // Admin cannot assign users - only domain managers can
    assignedDomainManagers: [], // Admin can assign domain managers
    todoCheckList: [],
    attachments: [],
    requiredSkills: [], // Skills required for this task
  });

  const [currentTask, setCurrentTask] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [openDeleteAlert, setOpenDeleteAlert] = useState(false);
  const [newSkill, setNewSkill] = useState("");

  const handleValueChange = (key, value) => {
    setTaskData((prevData) => ({ ...prevData, [key]: value }));
  };

  const clearData = () => {
    setTaskData({
      title: "",
      description: "",
      priority: "Low",
      dueDate: null,
      assignedTo: [],
      assignedDomainManagers: [],
      todoCheckList: [],
      attachments: [],
      requiredSkills: [],
    });
    setNewSkill("");
  };

  const addSkill = () => {
    if (newSkill.trim() && !taskData.requiredSkills.includes(newSkill.trim())) {
      setTaskData(prev => ({
        ...prev,
        requiredSkills: [...prev.requiredSkills, newSkill.trim()]
      }));
      setNewSkill("");
    }
  };

  const removeSkill = (skillToRemove) => {
    setTaskData(prev => ({
      ...prev,
      requiredSkills: prev.requiredSkills.filter(skill => skill !== skillToRemove)
    }));
  };

  // Create Task
  const createTask = async () => {
    setLoading(true);
    try {
      const todolist = taskData.todoCheckList?.map((item) => ({
        text: item,
        completed: false,
        requiredSkills: [], // Individual checklist items can have their own skill requirements
      }));

      const payload = {
        ...taskData,
        dueDate: new Date(taskData.dueDate).toISOString(),
        todoCheckList: todolist,
        assignedTo: [], // Admin cannot assign users
      };

      const response = await axiosInstance.post(
        API_PATHS.TASKS.CREATE_TASK,
        payload
      );

      // If domain managers are assigned, assign them to the task
      if (taskData.assignedDomainManagers.length > 0) {
        await axiosInstance.put(
          API_PATHS.TASKS.ASSIGN_DOMAIN_MANAGERS(response.data.task._id),
          {
            assignedDomainManagers: taskData.assignedDomainManagers
          }
        );
      }

      toast.success("Task created successfully.");
      clearData();
    } catch (error) {
      console.error("Error creating task:", error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  // Update Task
  const updateTask = async () => {
    setLoading(true);
    try {
      const todolist = taskData.todoCheckList?.map((item) => {
        const prevTodoCheckList = currentTask?.todoCheckList || [];
        const matchedTask = prevTodoCheckList.find(
          (task) => task.text === item
        );

        return {
          text: item,
          completed: matchedTask ? matchedTask.completed : false,
        };
      });

      const payload = {
        ...taskData,
        dueDate: new Date(taskData.dueDate).toISOString(),
        todoCheckList: todolist,
        assignedTo: currentTask?.assignedTo || [], // Keep existing assignments
      };

      const response = await axiosInstance.put(
        API_PATHS.TASKS.UPDATE_TASK(taskId),
        payload
      );

      // Update domain manager assignment
      if (taskData.assignedDomainManagers.length > 0) {
        await axiosInstance.put(
          API_PATHS.TASKS.ASSIGN_DOMAIN_MANAGERS(taskId),
          {
            assignedDomainManagers: taskData.assignedDomainManagers
          }
        );
      }

      toast.success("Task updated successfully.");
      navigate("/admin/tasks");
    } catch (error) {
      console.error("Error updating task:", error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!taskData.title.trim()) {
      setError("Title is required");
      return;
    }

    if (!taskData.dueDate) {
      setError("Due date is required");
      return;
    }

    if (taskData.todoCheckList.length === 0) {
      setError("At least one todo item is required");
      return;
    }

    if (taskData.assignedDomainManagers.length === 0) {
      setError("At least one domain manager must be assigned");
      return;
    }

    setError("");

    if (taskId) {
      await updateTask();
    } else {
      await createTask();
    }
  };

  const getTaskDetailsByID = async () => {
    try {
      const response = await axiosInstance.get(
        API_PATHS.TASKS.GET_TASK_BY_ID(taskId)
      );

      if (response.data) {
        const taskInfo = response.data;
        setCurrentTask(taskInfo);
        setTaskData({
          title: taskInfo.title || "",
          description: taskInfo.description || "",
          priority: taskInfo.priority || "Low",
          dueDate: taskInfo.dueDate
            ? moment(taskInfo.dueDate).format("YYYY-MM-DD")
            : null,
          assignedTo: taskInfo.assignedTo || [],
          assignedDomainManagers: taskInfo.assignedDomainManagers || [],
          todoCheckList:
            taskInfo.todoCheckList?.map((item) => item.text) || [],
          attachments: taskInfo.attachments || [],
          requiredSkills: taskInfo.requiredSkills || [],
        });
      }
    } catch (error) {
      console.error("Error Fetching Task Details: ", error);
    }
  };

  const deleteTask = async () => {
    try {
      await axiosInstance.delete(API_PATHS.TASKS.DELETE_TASK(taskId));
      toast.success("Task deleted successfully");
      navigate("/admin/tasks");
    } catch (error) {
      console.error("Error deleting task:", error);
      toast.error("Failed to delete task");
    }
  };

  useEffect(() => {
    if (taskId) {
      getTaskDetailsByID();
    }
  }, [taskId]);

  return (
    <DashboardLayout activeMenu="Create Task">
      <div className="mt-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-800">
            {taskId ? "Edit Task" : "Create Task"}
          </h2>
          {taskId && (
            <button
              onClick={() => setOpenDeleteAlert(true)}
              className="flex items-center gap-2 px-4 py-2 text-red-600 border border-red-300 rounded-md hover:bg-red-50"
            >
              <LuTrash2 className="w-4 h-4" />
              Delete Task
            </button>
          )}
        </div>

        <div className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Task Title *
              </label>
              <input
                type="text"
                value={taskData.title}
                onChange={(e) => handleValueChange("title", e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter task title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority
              </label>
              <SelectDropdown
                options={PRIORITY_DATA}
                value={taskData.priority}
                onChange={(value) => handleValueChange("priority", value)}
                placeholder="Select priority"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              value={taskData.description}
              onChange={(e) => handleValueChange("description", e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={4}
              placeholder="Enter task description"
            />
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Due Date *
            </label>
            <input
              type="date"
              value={taskData.dueDate || ""}
              onChange={(e) => handleValueChange("dueDate", e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Assign Domain Managers *
            </label>
            <SelectDomainManagers
              selectedDomainManagers={taskData.assignedDomainManagers}
              setSelectedDomainManagers={(value) => handleValueChange("assignedDomainManagers", value)}
              requiredExpertise={taskData.requiredSkills}
            />
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Todo Checklist *
            </label>
            <TodoListInput
              todoList={taskData.todoCheckList}
              setTodoList={(value) => handleValueChange("todoCheckList", value)}
            />
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Required Skills
            </label>
            <div className="flex flex-wrap items-center gap-2 p-3 border border-gray-300 rounded-md focus-within:ring-2 focus-within:ring-blue-500">
              {taskData.requiredSkills.map((skill, index) => (
                <span
                  key={index}
                  className="flex items-center bg-blue-100 text-blue-800 text-sm font-medium px-2.5 py-0.5 rounded-full"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => removeSkill(skill)}
                    className="ml-1 text-blue-800 hover:text-blue-900 focus:outline-none"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="w-4 h-4"
                    >
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                      <path d="M15 3h6v6" />
                      <path d="M10 14L21 3" />
                    </svg>
                  </button>
                </span>
              ))}
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    addSkill();
                  }
                }}
                placeholder="Add new skill (press Enter to add)"
                className="flex-grow p-0 bg-transparent outline-none"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Attachments
            </label>
            <AddAttahchmentsInput
              attachments={taskData.attachments}
              setAttachments={(value) => handleValueChange("attachments", value)}
            />
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="btn-primary flex items-center gap-2"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : null}
              {taskId ? "Update Task" : "Create Task"}
            </button>
            <button
              onClick={() => navigate("/admin/tasks")}
              className="px-6 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>

      <DeleteAlert
        content="Are you sure you want to delete this task? This action cannot be undone."
        onDelete={deleteTask}
        isOpen={openDeleteAlert}
        onClose={() => setOpenDeleteAlert(false)}
      />
    </DashboardLayout>
  );
};

export default CreateTask;