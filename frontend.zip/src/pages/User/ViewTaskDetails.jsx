import moment from "moment";
import { useContext, useEffect, useState } from "react";
import { LuArrowLeft, LuTarget } from "react-icons/lu";
import { useNavigate, useParams } from "react-router-dom";
import ChecklistItemManager from "../../components/ChecklistItemManager";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const ViewTaskDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(UserContext);
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [completedUsersDetails, setCompletedUsersDetails] = useState({});

  useEffect(() => {
    fetchTask();
  }, [id]);

  const fetchTask = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_TASK_BY_ID(id));
      setTask(response.data);
      
      // Debug: Log the full task data
      console.log("Full task data:", response.data);
      console.log("TodoCheckList:", response.data?.todoCheckList);
      console.log("Current user:", user);
      
      // Check user assignments
      if (response.data?.todoCheckList && user) {
        response.data.todoCheckList.forEach((item, index) => {
          console.log(`Item ${index}:`, {
            text: item.text,
            assignedUsers: item.assignedUsers,
            isUserAssigned: item.assignedUsers?.some(uid => uid.toString() === user._id.toString()),
            userID: user._id,
            userIDType: typeof user._id
          });
        });
      }
      
      // Fetch user details for completed items
      if (response.data?.todoCheckList) {
        const completedUserIds = response.data.todoCheckList
          .filter(item => item.completedBy)
          .map(item => item.completedBy);
        
        if (completedUserIds.length > 0) {
          await fetchCompletedUsersDetails(completedUserIds);
        }
      }
    } catch (error) {
      console.error("Error fetching task:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCompletedUsersDetails = async (userIds) => {
    if (!userIds || userIds.length === 0) return;
    
    try {
      const userDetails = {};
      for (const userId of userIds) {
        try {
          const response = await axiosInstance.get(API_PATHS.USERS.GET_USER_BY_ID(userId));
          userDetails[userId] = response.data;
        } catch (error) {
          console.error(`Error fetching user ${userId}:`, error);
        }
      }
      setCompletedUsersDetails(prev => ({ ...prev, ...userDetails }));
    } catch (error) {
      console.error("Error fetching completed users details:", error);
    }
  };

  const updateTask = async (updatedChecklist) => {
    try {
      setUpdating(true);
      
      console.log("Sending to backend:", {
        taskId: id,
        todoCheckList: updatedChecklist
      });
      
        await axiosInstance.put(API_PATHS.TASKS.UPDATE_TODO_CHECKLIST(id), {
          todoCheckList: updatedChecklist
        });
      await fetchTask(); // Refresh task data
    } catch (error) {
      console.error("Error updating task:", error);
      console.error("Error response:", error.response?.data);
      alert(error.response?.data?.message || "Error updating task");
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!task) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Task not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <LuArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-2xl font-bold text-gray-900">{task.title}</h1>
          <button
            onClick={() => navigate(`/user/task-manager/${id}`)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <LuTarget className="w-4 h-4" />
            Manage Project Tasks
          </button>
        </div>

        {/* Task Details */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Task Information</h2>
              <div className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-gray-500">Description:</span>
                  <p className="text-sm text-gray-900 mt-1">{task.description}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Priority:</span>
                  <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                    task.priority === "High" ? "bg-red-100 text-red-800" :
                    task.priority === "Medium" ? "bg-yellow-100 text-yellow-800" :
                    "bg-green-100 text-green-800"
                  }`}>
                    {task.priority}
                  </span>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Status:</span>
                  <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                    task.status === "Completed" ? "bg-green-100 text-green-800" :
                    task.status === "In Progress" ? "bg-blue-100 text-blue-800" :
                    "bg-gray-100 text-gray-800"
                  }`}>
                    {task.status}
                  </span>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Due Date:</span>
                  <p className="text-sm text-gray-900 mt-1">
                    {moment(task.dueDate).format("MMMM DD, YYYY")}
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Progress</h2>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Progress</span>
                    <span>{(() => {
                      const approvedItems = task.todoCheckList.filter(item => item.approved);
                      const completedApprovedItems = approvedItems.filter(item => item.completed);
                      return approvedItems.length > 0 ? Math.round((completedApprovedItems.length / approvedItems.length) * 100) : 0;
                    })()}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ 
                        width: `${(() => {
                          const approvedItems = task.todoCheckList.filter(item => item.approved);
                          const completedApprovedItems = approvedItems.filter(item => item.completed);
                          return approvedItems.length > 0 ? Math.round((completedApprovedItems.length / approvedItems.length) * 100) : 0;
                        })()}%` 
                      }}
                    ></div>
                  </div>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Completed Items:</span>
                  <p className="text-sm text-gray-900 mt-1">
                    {task.todoCheckList.filter(item => item.approved && item.completed).length} of {task.todoCheckList.filter(item => item.approved).length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Deliverables Checklist */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Deliverables Checklist</h2>
          
          {/* Filter to show only approved items */}
          {task.todoCheckList.filter(item => item.approved).length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-2">
                <LuTarget className="w-12 h-12 mx-auto" />
              </div>
              <p className="text-gray-500 text-sm">
                No approved checklist items yet. Please wait for the domain manager to approve items.
              </p>
            </div>
          ) : (
            <ChecklistItemManager
              checklistItems={task.todoCheckList
                .map((item, originalIndex) => ({ item, originalIndex }))
                .filter(({ item }) => item.approved)
                .map(({ item, originalIndex }) => ({
                  ...item,
                  taskId: id,
                  checklistIndex: originalIndex, // Use original index, not filtered index
                  text: item.text,
                  completed: item.completed || false,
                  rejected: item.rejected || false,
                  description: item.description || "",
                  taskTitle: task.title,
                  taskPriority: task.priority,
                  taskStatus: task.status,
                  taskDueDate: task.dueDate,
                  domainManagers: task.assignedDomainManagers || [],
                  _id: item._id || `item-${originalIndex}` // Ensure unique ID
                }))}
              onStatusUpdate={async (item, newStatus) => {
                try {
                  console.log("Status update:", item, newStatus);
                  console.log("API path:", API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_STATUS(id, item.checklistIndex));
                  console.log("Checklist item details:", item);
                  console.log("Current user ID:", user?._id);
                  console.log("Assigned users:", item.assignedUsers);
                  
                  // Use the specific endpoint for updating individual item status
                  const response = await axiosInstance.put(
                    API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_STATUS(id, item.checklistIndex),
                    {
                      completed: newStatus === 'completed',
                      rejected: newStatus === 'rejected'
                    }
                  );

                  if (response.data.success) {
                    // Refresh task data to get the updated state
                    await fetchTask();
                  }
                } catch (error) {
                  console.error("Error updating item status:", error);
                  console.error("Error response:", error.response?.data);
                  alert(error.response?.data?.message || "Error updating item status");
                }
              }}
              onDescriptionUpdate={async (item, description) => {
                try {
                  console.log("Description update:", item, description);
                  console.log("API path:", API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_DESCRIPTION(id, item.checklistIndex));
                  
                  // Use the specific endpoint for updating individual item description
                  const response = await axiosInstance.put(
                    API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_DESCRIPTION(id, item.checklistIndex),
                    { description }
                  );

                  if (response.data.success) {
                    // Refresh task data to get the updated state
                    await fetchTask();
                  }
                } catch (error) {
                  console.error("Error updating item description:", error);
                  console.error("Error response:", error.response?.data);
                  alert(error.response?.data?.message || "Error updating item description");
                }
              }}
            />
          )}
              </div>
      </div>
    </div>
  );
};

export default ViewTaskDetails;
