import React, { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuArrowLeft, LuCheck, LuCircle, LuPlus, LuSquare, LuStar, LuUser, LuX } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import Input from "../../components/Inputs/Input";
import ProfilePhotoSelector from "../../components/Inputs/ProfilePhotoSelector";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import uploadImage from "../../utils/uploadImage";

const Profile = () => {
  const { user, updateUser } = useContext(UserContext);
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  
  const [profilePic, setProfilePic] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPasswordFields, setShowPasswordFields] = useState(false);
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState({ name: "", rating: 5 });

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setSkills(user.skills || []);
    }
  }, [user]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSkillChange = (field, value) => {
    setNewSkill(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addSkill = () => {
    if (!newSkill.name.trim()) {
      toast.error("Skill name is required");
      return;
    }
    
    if (skills.some(skill => skill.name.toLowerCase() === newSkill.name.toLowerCase())) {
      toast.error("This skill already exists");
      return;
    }

    setSkills(prev => [...prev, { ...newSkill, name: newSkill.name.trim() }]);
    setNewSkill({ name: "", rating: 5 });
    toast.success("Skill added successfully!");
  };

  const removeSkill = (skillToRemove) => {
    setSkills(prev => prev.filter(skill => skill.name !== skillToRemove.name));
    toast.success("Skill removed successfully!");
  };

  const updateSkillRating = (skillName, newRating) => {
    setSkills(prev => prev.map(skill => 
      skill.name === skillName ? { ...skill, rating: newRating } : skill
    ));
  };

  const renderStars = (rating, onChange) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className={`text-lg transition-colors ${
              star <= rating ? 'text-yellow-400' : 'text-gray-300'
            } hover:text-yellow-400`}
          >
            <LuStar className="w-4 h-4 fill-current" />
          </button>
        ))}
      </div>
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (showPasswordFields) {
      if (!formData.currentPassword) {
        toast.error("Current password is required");
        return;
      }
      if (formData.newPassword !== formData.confirmPassword) {
        toast.error("New passwords do not match");
        return;
      }
      if (formData.newPassword.length < 6) {
        toast.error("New password must be at least 6 characters");
        return;
      }
    }

    setLoading(true);
    try {
      let profileImageUrl = user?.profileImageUrl || "";
      
      // Upload new profile picture if selected
      if (profilePic) {
        const imgUploadRes = await uploadImage(profilePic);
        profileImageUrl = imgUploadRes.imageUrl || "";
      }

      const updateData = {
        name: formData.name,
        email: formData.email,
        profileImageUrl,
        skills: skills,
      };

      console.log("Sending update data:", updateData);
      console.log("Skills being sent:", skills);

      if (showPasswordFields) {
        updateData.currentPassword = formData.currentPassword;
        updateData.newPassword = formData.newPassword;
      }

      const response = await axiosInstance.put(API_PATHS.AUTH.UPDATE_PROFILE, updateData);
      
      console.log("Backend response:", response.data);
      console.log("Response success:", response.data.success);
      console.log("Response user data:", response.data.user);
      console.log("Response token:", response.data.user?.token);
      
      if (response.data.success) {
        // Update local user context
        const updatedUserData = {
          ...user,
          name: formData.name,
          email: formData.email,
          profileImageUrl,
          skills: skills,
        };
        
        console.log("Updating user context with:", updatedUserData);
        console.log("Skills in updatedUserData:", updatedUserData.skills);
        console.log("Current user context before update:", user);
        
        updateUser(updatedUserData);
        
        console.log("User context updated successfully");
        
        // Small delay to ensure context update is processed
        setTimeout(() => {
          console.log("User context after update:", user);
          console.log("Skills in user context after update:", user?.skills);
          
          // Verify the update was successful
          if (user?.skills && user.skills.length > 0) {
            console.log("✅ Skills successfully updated in user context");
          } else {
            console.log("❌ Skills not found in user context after update");
          }
        }, 100);
        
        toast.success("Profile updated successfully!");
        
        // Reset password fields
        if (showPasswordFields) {
          setFormData(prev => ({
            ...prev,
            currentPassword: "",
            newPassword: "",
            confirmPassword: "",
          }));
          setShowPasswordFields(false);
        }
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error(error.response?.data?.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  const togglePasswordFields = () => {
    setShowPasswordFields(!showPasswordFields);
    if (!showPasswordFields) {
      setFormData(prev => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      }));
    }
  };

  return (
    <DashboardLayout activeMenu="profile">
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/user/dashboard")}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <LuArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Profile Settings</h1>
            <p className="text-gray-600">Manage your account information and preferences</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Profile Photo Section */}
            <div className="text-center">
              <div className="mb-4">
                <ProfilePhotoSelector image={profilePic} setImage={setProfilePic} />
              </div>
              <p className="text-sm text-gray-500">
                Click to upload a new profile photo
              </p>
            </div>

            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <LuUser className="w-5 h-5 text-blue-600" />
                Basic Information
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Full Name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter your full name"
                  icon={<LuUser className="w-4 h-4" />}
                />
                
                <Input
                  label="Email Address"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Enter your email"
                  type="email"
                  icon={<LuCircle className="w-4 h-4" />}
                />
              </div>
            </div>

            {/* Skills Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <LuStar className="w-5 h-5 text-yellow-600" />
                Skills & Expertise
              </h3>
              
              {/* Add New Skill */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Add New Skill</h4>
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <Input
                      label="Skill Name"
                      value={newSkill.name}
                      onChange={(e) => handleSkillChange("name", e.target.value)}
                      placeholder="e.g., JavaScript, Project Management"
                      icon={<LuStar className="w-4 h-4" />}
                    />
                  </div>
                  <div className="flex flex-col">
                    <label className="text-xs text-gray-600 mb-1">Rating</label>
                    {renderStars(newSkill.rating, (rating) => handleSkillChange("rating", rating))}
                  </div>
                  <button
                    type="button"
                    onClick={addSkill}
                    className="mt-6 p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <LuPlus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Current Skills */}
              {skills.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-gray-700">Your Skills</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {skills.map((skill, index) => (
                      <div key={index} className="flex items-center justify-between bg-white border border-gray-200 rounded-lg p-3">
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-gray-900">{skill.name}</span>
                            <button
                              type="button"
                              onClick={() => removeSkill(skill)}
                              className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors"
                            >
                              <LuX className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500">Rating:</span>
                            {renderStars(skill.rating, (rating) => updateSkillRating(skill.name, rating))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {skills.length === 0 && (
                <div className="text-center py-4 text-gray-500">
                  <LuStar className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No skills added yet. Add your first skill above!</p>
                </div>
              )}
            </div>

            {/* Password Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                  <LuSquare className="w-5 h-5 text-blue-600" />
                  Password
                </h3>
                <button
                  type="button"
                  onClick={togglePasswordFields}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                  {showPasswordFields ? "Cancel" : "Change Password"}
                </button>
              </div>
              
              {showPasswordFields && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                  <Input
                    label="Current Password"
                    value={formData.currentPassword}
                    onChange={(e) => handleInputChange("currentPassword", e.target.value)}
                    placeholder="Enter current password"
                    type="password"
                    icon={<LuSquare className="w-4 h-4" />}
                  />
                  
                  <Input
                    label="New Password"
                    value={formData.newPassword}
                    onChange={(e) => handleInputChange("newPassword", e.target.value)}
                    placeholder="Enter new password"
                    type="password"
                    icon={<LuSquare className="w-4 h-4" />}
                  />
                  
                  <Input
                    label="Confirm New Password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                    placeholder="Confirm new password"
                    type="password"
                    icon={<LuSquare className="w-4 h-4" />}
                  />
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-4 border-t border-gray-200">
              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <LuCheck className="w-4 h-4" />
                {loading ? "Updating..." : "Save Changes"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Profile;
