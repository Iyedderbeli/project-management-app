import React, { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuArrowLeft, LuMessageSquare, LuSearch, LuSend, LuUser } from "react-icons/lu";
import { useNavigate, useSearchParams } from "react-router-dom";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const UserMessages = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [conversationMessages, setConversationMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [messagesLoading, setMessagesLoading] = useState(false);

  useEffect(() => {
    fetchConversations();
    
    // Set up periodic refresh of conversations (every 30 seconds)
    const intervalId = setInterval(() => {
      fetchConversations();
    }, 30000);
    
    // Cleanup function to clear search timeout and interval
    return () => {
      if (window.searchTimeout) {
        clearTimeout(window.searchTimeout);
      }
      clearInterval(intervalId);
    };
  }, []);

  // Handle URL parameters to automatically open conversations
  useEffect(() => {
    const userId = searchParams.get('userId');
    const notificationType = searchParams.get('type');
    
    if (userId && conversations.length > 0) {
      // Find the conversation with the specified user
      const targetConversation = conversations.find(conv => 
        conv.user?._id === userId || conv._id === userId
      );
      
      if (targetConversation) {
        console.log("Auto-opening conversation with:", targetConversation.user?.name);
        setSelectedConversation(targetConversation);
        fetchConversationMessages(targetConversation);
        
        // Clear the URL parameters after opening the conversation
        navigate("/user/messages", { replace: true });
      } else if (notificationType === 'message') {
        // If it's a message notification but conversation doesn't exist yet,
        // try to create a new conversation or show a message
        toast.success("Opening conversation with the user who sent you a message");
      }
    }
  }, [conversations, searchParams, navigate]);

  const fetchConversations = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATIONS);
      console.log("Fetched conversations:", response.data);
      setConversations(response.data || []);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      toast.error("Failed to load conversations");
    } finally {
      setLoading(false);
    }
  };

  const fetchConversationMessages = async (conversation) => {
    if (!conversation) return;
    
    try {
      setMessagesLoading(true);
      // Get the other user's ID from the conversation
      const otherUserId = conversation.user?._id || conversation._id;
      
      if (!otherUserId) {
        console.error("No user ID found in conversation:", conversation);
        return;
      }

      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATION(otherUserId));
      console.log("Fetched conversation messages:", response.data);
      setConversationMessages(response.data || []);
    } catch (error) {
      console.error("Error fetching conversation messages:", error);
      toast.error("Failed to load conversation messages");
      setConversationMessages([]);
    } finally {
      setMessagesLoading(false);
    }
  };

  const searchUsers = async (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearchLoading(true);
      // Search for users by name or email containing the query
      const response = await axiosInstance.get(`${API_PATHS.USERS.SEARCH_USERS}?q=${encodeURIComponent(query.trim())}`);
      
      // Filter out the current user from search results
      const filteredResults = response.data?.filter(searchUser => searchUser._id !== user?._id) || [];
      setSearchResults(filteredResults);
      
      // Show feedback if no results found
      if (filteredResults.length === 0 && query.trim().length > 0) {
        console.log(`No users found for query: "${query}"`);
      }
    } catch (error) {
      console.error("Error searching users:", error);
      if (error.response?.status === 400) {
        toast.error("Please enter a valid search term");
      } else {
        toast.error("Failed to search users");
      }
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    // Clear previous timeout
    if (window.searchTimeout) {
      clearTimeout(window.searchTimeout);
    }
    
    if (query.trim()) {
      // Debounce search to avoid too many API calls
      window.searchTimeout = setTimeout(() => {
        searchUsers(query);
      }, 300);
    } else {
      setSearchResults([]);
    }
  };

  const startNewConversation = async (user) => {
    try {
      // Check if conversation already exists
      const existingConversation = conversations.find(conv => conv.user?._id === user._id || conv._id === user._id);
      
      if (existingConversation) {
        setSelectedConversation(existingConversation);
        fetchConversationMessages(existingConversation);
        setSearchQuery("");
        setSearchResults([]);
        return;
      }

      // Create a new conversation object
      const newConversation = {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        lastMessage: null,
        unreadCount: 0
      };

      setSelectedConversation(newConversation);
      setSearchQuery("");
      setSearchResults([]);
      
      // Refresh conversations list to include this new conversation
      await fetchConversations();
      
      toast.success(`Started conversation with ${user.name}`);
    } catch (error) {
      console.error("Error starting conversation:", error);
      toast.error("Failed to start conversation");
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return;

    try {
      const response = await axiosInstance.post(API_PATHS.MESSAGES.SEND_MESSAGE, {
        toUserId: selectedConversation.user?._id || selectedConversation._id,
        message: newMessage.trim()
      });

      if (response.data) {
        setNewMessage("");
        
        // Refresh both conversation messages and conversations list
        if (selectedConversation) {
          fetchConversationMessages(selectedConversation);
        }
        
        // Refresh conversations list to show the new conversation
        await fetchConversations();
        
        toast.success("Message sent successfully");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getConversationName = (conversation) => {
    // Handle different conversation data structures
    if (conversation.name) {
      if (conversation.role === "admin") {
        return `${conversation.name} (Admin)`;
      } else if (conversation.role === "domain_manager") {
        return `${conversation.name} (Domain Manager)`;
      }
      return conversation.name;
    }
    
    // Handle conversation objects with user details
    if (conversation.user && conversation.user.name) {
      return conversation.user.name;
    }
    
    // Handle message-based conversations (from backend)
    if (conversation.fromUser && conversation.fromUser.name) {
      return conversation.fromUser.name;
    }
    
    if (conversation.toUser && conversation.toUser.name) {
      return conversation.toUser.name;
    }
    
    // Handle direct user objects
    if (conversation._id && !conversation.name) {
      return `User ${conversation._id.slice(-6)}`;
    }
    
    return "Unknown User";
  };

  const getRoleBadge = (conversation) => {
    // Extract role from different conversation data structures
    let role = null;
    
    if (conversation.role) {
      role = conversation.role;
    } else if (conversation.user && conversation.user.role) {
      role = conversation.user.role;
    } else if (conversation.fromUser && conversation.fromUser.role) {
      role = conversation.fromUser.role;
    } else if (conversation.toUser && conversation.toUser.role) {
      role = conversation.toUser.role;
    }
    
    if (role === "admin") {
      return <span className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">Admin</span>;
    } else if (role === "domain_manager") {
      return <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">Domain Manager</span>;
    }
    return <span className="px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">User</span>;
  };

  const handleConversationSelect = (conversation) => {
    setSelectedConversation(conversation);
    fetchConversationMessages(conversation);
  };

  const getProfileImageUrl = (conversation) => {
    return conversation.user?.profileImageUrl || 
           conversation.lastMessage?.fromUser?.profileImageUrl || 
           conversation.profileImageUrl;
  };

  const handleImageError = (e) => {
    // Hide the broken image and show the fallback icon
    e.target.style.display = 'none';
    const fallback = e.target.nextSibling;
    if (fallback) {
      fallback.style.display = 'flex';
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto">
                 {/* Header */}
         <div className="flex items-center justify-between mb-6">
           <div className="flex items-center gap-3">
             <button
               onClick={() => navigate(-1)}
               className="p-2 text-gray-600 hover:text-gray-800 transition-colors"
             >
               <LuArrowLeft className="w-5 h-5" />
             </button>
             <div>
               <h1 className="text-2xl font-bold text-gray-800">Messages</h1>
                               <p className="text-gray-600">Communicate with anyone in the system</p>
             </div>
           </div>
           
           
         </div>

                   {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <LuSearch className="h-5 w-5 text-gray-400" />
              </div>
                             <input
                 type="text"
                 value={searchQuery}
                 onChange={handleSearchChange}
                 placeholder="Type to search users by name or email..."
                 className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
               />
               <p className="text-xs text-gray-500 mt-2">
                 Start typing to find users. You can search by name or email address.
               </p>
            </div>
            
            {/* Search Results */}
            {searchQuery.trim() && (
              <div className="mt-3 bg-white border border-gray-200 rounded-lg shadow-lg max-h-64 overflow-y-auto">
                {searchLoading ? (
                  <div className="p-4 text-center text-gray-500">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-2">Searching...</p>
                  </div>
                ) : searchResults.length > 0 ? (
                  searchResults.map((user) => (
                    <div
                      key={user._id}
                      onClick={() => startNewConversation(user)}
                      className="p-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors"
                    >
                                             <div className="flex items-center gap-3">
                         {(user.profileImageUrl || user.profileImage) ? (
                           <img
                             src={user.profileImageUrl || user.profileImage}
                             alt={user.name}
                             className="w-10 h-10 rounded-full object-cover border-2 border-gray-200 shadow-sm hover:scale-105 transition-transform duration-200"
                                                      onError={handleImageError}
                           />
                         ) : null}
                         <div className={`w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center ${(user.profileImageUrl || user.profileImage) ? 'hidden' : 'flex'}`}>
                           <LuUser className="w-5 h-5 text-blue-600" />
                         </div>
                         <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium text-gray-800">{user.name}</p>
                            {getRoleBadge(user.role)}
                          </div>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                      </div>
                    </div>
                  ))
                                 ) : (
                   <div className="p-4 text-center text-gray-500">
                     <p className="font-medium">No users found</p>
                     <p className="text-sm text-gray-400 mt-1">
                       Try searching with a different term or check the spelling
                     </p>
                   </div>
                 )}
              </div>
            )}
          </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Conversations List */}
          <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-800">Conversations</h2>
            </div>
            <div className="max-h-96 overflow-y-auto">
                             {conversations.length === 0 ? (
                 <div className="p-6 text-center text-gray-500">
                   <LuMessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                                       <p>No conversations yet</p>
                    <p className="text-sm">Search for users to start new conversations</p>
                 </div>
               ) : (
                 conversations.map((conversation) => {
                   console.log("Rendering conversation:", conversation);
                   return (
                     <div
                       key={conversation._id || `conv-${Math.random()}`}
                       onClick={() => handleConversationSelect(conversation)}
                       className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                         selectedConversation?._id === conversation._id ? "bg-blue-50 border-blue-200" : ""
                       }`}
                     >
                                         <div className="flex items-center gap-3">
                       {getProfileImageUrl(conversation) ? (
                         <img
                           src={getProfileImageUrl(conversation)}
                           alt={getConversationName(conversation)}
                           className="w-10 h-10 rounded-full object-cover border-2 border-gray-200 shadow-sm hover:scale-105 transition-transform duration-200"
                           onError={handleImageError}
                         />
                       ) : null}
                       <div className={`w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center ${getProfileImageUrl(conversation) ? 'hidden' : 'flex'}`}>
                         <LuUser className="w-5 h-5 text-blue-600" />
                       </div>
                       <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-gray-800 truncate">
                            {getConversationName(conversation)}
                          </p>
                          {getRoleBadge(conversation)}
                        </div>
                        {conversation.lastMessage && conversation.lastMessage.message && (
                          <p className="text-sm text-gray-600 truncate">
                            {conversation.lastMessage.message}
                          </p>
                        )}
                        {conversation.unreadCount && typeof conversation.unreadCount === 'number' && conversation.unreadCount > 0 ? (
                          <span className="inline-block mt-1 px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">
                            {conversation.unreadCount} new
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>
                );
                })
              )}
            </div>
          </div>

          {/* Messages Area */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200">
            {selectedConversation ? (
              <div className="flex flex-col h-96">
                {/* Conversation Header */}
                <div className="p-4 border-b border-gray-200">
                                     <div className="flex items-center gap-3">
                     {getProfileImageUrl(selectedConversation) ? (
                       <img
                         src={getProfileImageUrl(selectedConversation)}
                         alt={getConversationName(selectedConversation)}
                         className="w-10 h-10 rounded-full object-cover border-2 border-gray-200 shadow-sm hover:scale-105 transition-transform duration-200"
                         onError={handleImageError}
                       />
                     ) : null}
                     <div className={`w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center ${getProfileImageUrl(selectedConversation) ? 'hidden' : 'flex'}`}>
                       <LuUser className="w-5 h-5 text-blue-600" />
                     </div>
                     <div>
                      <h3 className="font-semibold text-gray-800">
                        {getConversationName(selectedConversation)}
                      </h3>
                      <div className="flex items-center gap-2">
                        {getRoleBadge(selectedConversation)}
                        {selectedConversation.online && typeof selectedConversation.online === 'boolean' && selectedConversation.online && (
                          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 p-4 overflow-y-auto">
                  {messagesLoading ? (
                    <div className="text-center text-gray-500 text-sm">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto mb-2"></div>
                      <p>Loading messages...</p>
                    </div>
                  ) : conversationMessages.length === 0 ? (
                    <div className="text-center text-gray-500 text-sm">
                      <LuMessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                      <p>No messages yet. Start the conversation!</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {conversationMessages.map((message) => (
                        <div
                          key={message._id}
                          className={`flex ${message.fromUser?._id === user?._id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs px-3 py-2 rounded-lg ${
                              message.fromUser?._id === user?._id
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            <p className="text-sm">{message.message}</p>
                            <p className="text-xs opacity-70 mt-1">
                              {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Type your message..."
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <button
                      onClick={sendMessage}
                      disabled={!newMessage.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <LuSend className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <LuMessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-800 mb-2">Select a conversation</h3>
                <p>Choose a conversation from the list to start messaging</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default UserMessages;
