import moment from "moment";
import React, { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuArrowRight, LuCalendar, LuCheck, LuChevronLeft, LuChevronRight, LuCircle, LuClock, LuExternalLink, LuSquare, LuTarget, LuTrendingUp, LuUsers } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import ChecklistItemCard from "../../components/Cards/ChecklistItemCard";
import InfoCard from "../../components/Cards/InfoCard";
import CustomBarChart from "../../components/Charts/CustomBarChart";
import CustomPieChart from "../../components/Charts/CustomPieChart";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import TaskListTable from "../../components/TaskListTable";
import { UserContext } from "../../context/userContext";
import { useUserAuth } from "../../hooks/useUserAuth";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import { addThousandsSeparator } from "../../utils/helper";

const COLORS = ["#8D51FF", "#00B8DB", "#7BCE00", "#C084FC", "#E879F9"];

const UserDashboard = () => {
  useUserAuth();

  const { user } = useContext(UserContext);
  const navigate = useNavigate();

  const [dashboardData, setDashboardData] = useState(null);
  const [checklistData, setChecklistData] = useState(null);
  const [pieChartData, setPieChartData] = useState([]);
  const [barChartData, setBarChartData] = useState([]);
  const [checklistPieChartData, setChecklistPieChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [checklistLoading, setChecklistLoading] = useState(true);

  // Prepare the Chart data
  const prepareChartData = (data) => {
    const taskDistribution = data?.taskDistribution || null;
    const taskPriorityLevels = data?.taskPriorityLevels || null;

    const taskDistributionData = [
      { status: "Pending", count: taskDistribution?.Pending || 0 },
      { status: "In Progress", count: taskDistribution?.InProgress || 0 },
      { status: "Completed", count: taskDistribution?.Completed || 0 },
    ];

    setPieChartData(taskDistributionData);

    const PriorityLevelData = [
      { priority: "Low", count: taskPriorityLevels?.Low || 0 },
      { priority: "Medium", count: taskPriorityLevels?.Medium || 0 },
      { priority: "High", count: taskPriorityLevels?.High || 0 },
    ];

    setBarChartData(PriorityLevelData);
  };

  // Prepare checklist chart data
  const prepareChecklistChartData = (data) => {
    if (!data?.statistics) return;

    const checklistDistributionData = [
      { status: "Completed", count: data.statistics.completed || 0 },
      { status: "Pending", count: data.statistics.pending || 0 },
      { status: "Overdue", count: data.statistics.overdue || 0 },
    ];

    setChecklistPieChartData(checklistDistributionData);
  };

  const getDashboardData = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(
        API_PATHS.TASKS.GET_USER_DASHBOARD_DATA
      );
      if (response.data) {
        setDashboardData(response.data);
        prepareChartData(response.data?.charts || null);
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getChecklistData = async () => {
    try {
      setChecklistLoading(true);
      const response = await axiosInstance.get(
        API_PATHS.TASKS.GET_USER_CHECKLIST_ITEMS
      );
      if (response.data) {
        setChecklistData(response.data);
        prepareChecklistChartData(response.data);
      }
    } catch (error) {
      console.error("Error fetching checklist data:", error);
    } finally {
      setChecklistLoading(false);
    }
  };

  const handleCompleteChecklistItem = async (item) => {
    try {
      await axiosInstance.put(
        API_PATHS.TASKS.COMPLETE_CHECKLIST_ITEM(item.taskId, item.checklistIndex)
      );
      toast.success("Checklist item marked as complete!");
      getChecklistData(); // Refresh data
    } catch (error) {
      console.error("Error completing checklist item:", error);
      toast.error("Failed to mark item as complete");
    }
  };

  const handleViewChecklistDetails = (item) => {
    navigate(`/user/task-details/${item.taskId}`);
  };

  const onSeeMore = () => {
    navigate("/user/tasks");
  };

  const onSeeMoreChecklist = () => {
    navigate("/user/tasks");
  };

  useEffect(() => {
    getDashboardData();
    getChecklistData();
    return () => {};
  }, []);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  // Calendar state and functions
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedDateTasks, setSelectedDateTasks] = useState([]);

  const getCalendarDays = () => {
    const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const days = [];

    // Add days from previous month to fill the first row
    for (let i = 0; i < firstDayOfMonth.getDay(); i++) {
      days.push(null);
    }

    // Add days of the current month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(currentMonth.getFullYear(), currentMonth.getMonth(), i));
    }

    return days;
  };

  const isToday = (date) => {
    const today = new Date();
    return date.getFullYear() === today.getFullYear() &&
           date.getMonth() === today.getMonth() &&
           date.getDate() === today.getDate();
  };

  const getDateHasProjects = (date) => {
    if (!checklistData) return false;
    return checklistData.checklistItems.some(item => {
      const itemDate = new Date(item.taskDueDate);
      return itemDate.getFullYear() === date.getFullYear() &&
             itemDate.getMonth() === date.getMonth() &&
             itemDate.getDate() === date.getDate();
    });
  };

  const handleDateClick = (date) => {
    setSelectedDate(date);
    setSelectedDateTasks(checklistData.checklistItems.filter(item => {
      const itemDate = new Date(item.taskDueDate);
      return itemDate.getFullYear() === date.getFullYear() &&
             itemDate.getMonth() === date.getMonth() &&
             itemDate.getDate() === date.getDate();
    }));
  };

  return (
    <DashboardLayout activeMenu="Dashboard">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white mb-6">
        <div className="flex items-center justify-between">
        <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">
              {getGreeting()}, {user?.name}!
            </h1>
            <p className="text-blue-100 text-sm md:text-base">
              {moment().format("dddd, MMMM Do YYYY")}
            </p>
            <p className="text-blue-100 text-sm mt-2">
              Welcome back! Here's what's happening with your projects today.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="text-right">
              <div className="text-4xl font-bold text-blue-200">
                {dashboardData?.statistics?.totalTasks || 0}
              </div>
              <div className="text-blue-100 text-sm">Total Projects</div>
            </div>
          </div>
          </div>
        </div>

      {/* Project Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <InfoCard
            label="Total Projects"
            value={addThousandsSeparator(
            dashboardData?.charts?.taskDistribution?.All || 0
            )}
          color="bg-blue-500"
          icon={<LuTarget className="w-5 h-5" />}
          />
          <InfoCard
            label="Pending Projects"
            value={addThousandsSeparator(
            dashboardData?.charts?.taskDistribution?.Pending || 0
            )}
            color="bg-violet-500"
          icon={<LuClock className="w-5 h-5" />}
          />
          <InfoCard
          label="In Progress"
            value={addThousandsSeparator(
            dashboardData?.charts?.taskDistribution?.InProgress || 0
            )}
            color="bg-cyan-500"
          icon={<LuTrendingUp className="w-5 h-5" />}
          />
          <InfoCard
          label="Completed"
            value={addThousandsSeparator(
            dashboardData?.charts?.taskDistribution?.Completed || 0
          )}
          color="bg-green-500"
          icon={<LuCheck className="w-5 h-5" />}
        />
      </div>

      {/* Project Calendar */}
      {checklistData && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <LuCalendar className="w-5 h-5 text-blue-600" />
            Project Calendar
          </h3>
          <div className={`grid gap-6 ${
            selectedDate 
              ? 'grid-cols-1 lg:grid-cols-2' 
              : 'grid-cols-1'
          }`}>
            {/* Calendar View */}
            <div className={`bg-gray-50 rounded-lg transition-all duration-300 ${
              selectedDate 
                ? 'lg:col-span-1 p-4' 
                : 'w-full p-4'
            }`}>
              <div className="flex items-center justify-between mb-4 ">
                <h4 className={`font-medium text-gray-700 transition-all duration-300 ${
                  selectedDate ? 'text-md' : 'text-lg'
                }`}>Calendar View</h4>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1))}
                    className={`hover:bg-gray-200 rounded transition-colors ${
                      selectedDate ? 'p-1' : 'p-2'
                    }`}
                  >
                    <LuChevronLeft className={`transition-all duration-300 ${
                      selectedDate ? 'w-4 h-4' : 'w-5 h-5'
                    }`} />
                  </button>
                  <span className={`font-medium text-gray-600 transition-all duration-300 ${
                    selectedDate ? 'text-sm' : 'text-base'
                  }`}>
                    {currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </span>
                  <button 
                    onClick={() => setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1))}
                    className={`hover:bg-gray-200 rounded transition-colors ${
                      selectedDate ? 'p-1' : 'p-2'
                    }`}
                  >
                    <LuChevronRight className={`transition-all duration-300 ${
                      selectedDate ? 'w-4 h-4' : 'w-5 h-5'
                    }`} />
                  </button>
                </div>
              </div>
              
              {/* Calendar Grid */}
              <div className={`grid grid-cols-7 gap-1 ${
                selectedDate ? 'text-xs' : 'text-sm'
              }`}>
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className={`text-center font-medium text-gray-500 flex items-center justify-center ${
                    selectedDate ? 'p-2' : 'p-2'
                  }`}>
                    {day}
                  </div>
                ))}
                
                {getCalendarDays().map((day, index) => (
                  <div
                    key={index}
                    onClick={() => day && handleDateClick(day)}
                    className={`text-center cursor-pointer transition-all duration-200 rounded flex items-center justify-center ${
                      day ? 'hover:bg-blue-100' : ''
                    } ${
                      day && getDateHasProjects(day) 
                        ? 'bg-blue-100 text-blue-700 font-medium' 
                        : day 
                        ? 'text-gray-700' 
                        : 'text-gray-700'
                    } ${
                      day && isToday(day) 
                        ? 'ring-2 ring-blue-500 ring-offset-1' 
                        : ''
                    } ${
                      selectedDate ? 'p-2' : 'p-3'
                    }`}
                  >
                    {day?.getDate()}
                  </div>
                ))}
        </div>
      </div>

            {/* Selected Date Details - Only show when a date is selected */}
            {selectedDate && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-md font-medium text-gray-700 mb-4">
                  <span>
                    Tasks for {selectedDate.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </span>
              </h4>
              
                {selectedDateTasks.length > 0 ? (
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {selectedDateTasks.map((item, index) => (
                    <div key={index} className="bg-white rounded-lg p-3 border border-gray-200">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h5 className="font-medium text-gray-900 text-sm mb-1">
                            {item.text}
                          </h5>
                          <p 
                            className="text-xs text-gray-500 mb-2 cursor-pointer hover:text-blue-600 hover:underline transition-colors"
                            onClick={() => navigate(`/user/task-manager/${item.taskId}`)}
                            title="Click to manage all tasks for this project"
                          >
                            {item.taskTitle}
                          </p>
                          <div className="flex items-center gap-2">
                            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                              item.completed 
                                ? 'bg-green-100 text-green-800' 
                                : item.rejected 
                                ? 'bg-red-100 text-red-800' 
                                : 'bg-blue-100 text-blue-800'
                            }`}>
                              {item.completed ? 'Completed' : item.rejected ? 'Rejected' : 'Pending'}
                            </span>
                            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                              item.taskPriority === 'High' 
                                ? 'bg-red-100 text-red-800' 
                                : item.taskPriority === 'Medium' 
                                ? 'bg-yellow-100 text-yellow-800' 
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {item.taskPriority} Priority
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => handleViewChecklistDetails(item)}
                          className="p-1 text-blue-600 hover:bg-blue-100 rounded transition-colors"
                          title="View Details"
                        >
                          <LuExternalLink className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                ) : (
                <div className="text-center py-8 text-gray-500">
                  <LuCalendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No tasks assigned for this date</p>
                </div>
                )}
                </div>
              )}
          </div>
        </div>
      )}

      {/* Progress Overview */}
      {checklistData && checklistData.statistics && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <LuTrendingUp className="w-5 h-5 text-blue-600" />
            Overall Progress
          </h3>
          
          <div className="space-y-4">
            {/* Overall Completion Progress */}
        <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Task Completion</span>
                <span className="text-sm font-medium text-gray-900">
                  {checklistData.statistics.completed || 0} / {checklistData.statistics.total || 0}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-green-600 h-3 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${checklistData.statistics.total > 0 
                      ? (checklistData.statistics.completed / checklistData.statistics.total) * 100 
                      : 0}%` 
                  }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Priority Distribution */}
            {checklistData.checklistItems && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {checklistData.checklistItems.filter(item => item.taskPriority === 'High').length}
                  </div>
                  <div className="text-sm text-gray-600">High Priority</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-600">
                    {checklistData.checklistItems.filter(item => item.taskPriority === 'Medium').length}
                  </div>
                  <div className="text-sm text-gray-600">Medium Priority</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {checklistData.checklistItems.filter(item => item.taskPriority === 'Low').length}
                  </div>
                  <div className="text-sm text-gray-600">Low Priority</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <LuCircle className="w-5 h-5 text-blue-600" />
              Project Status Distribution
            </h3>
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <CustomPieChart data={pieChartData} colors={COLORS} />
          )}
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <LuSquare className="w-5 h-5 text-green-600" />
              Project Priority Levels
            </h3>
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : (
            <CustomBarChart data={barChartData} />
          )}
          </div>
        </div>

      {/* Checklist Items Dashboard */}
      {checklistData && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                              <LuCheck className="w-6 h-6 text-blue-600" />
              My Assigned Tasks
            </h2>
            <button
              onClick={onSeeMoreChecklist}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
            >
              View All <LuArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Checklist Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                                 <LuCircle className="w-5 h-5 text-purple-600" />
                Task Completion Status
              </h3>
              {checklistLoading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
                </div>
              ) : (
                <CustomPieChart data={checklistPieChartData} colors={["#10B981", "#3B82F6", "#EF4444"]} />
              )}
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button
                  onClick={() => navigate("/user/tasks")}
                  className="w-full p-3 text-left bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <LuTarget className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-medium text-blue-800">View All Tasks</span>
                  </div>
                </button>
                
                <button
                  onClick={() => navigate("/user/task-manager")}
                  className="w-full p-3 text-left bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <LuTarget className="w-4 h-4 text-purple-600" />
                    <span className="text-sm font-medium text-purple-800">Manage Tasks</span>
                  </div>
                </button>
                
                <button
                  onClick={() => navigate("/user/profile")}
                  className="w-full p-3 text-left bg-green-50 hover:bg-green-100 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <LuUsers className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-green-800">Update Profile</span>
                  </div>
                </button>
            </div>
          </div>
        </div>

          {/* Checklist Items Grid */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Assigned Tasks</h3>
            {checklistLoading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : checklistData.checklistItems && checklistData.checklistItems.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {checklistData.checklistItems.slice(0, 6).map((item, index) => (
                  <ChecklistItemCard
                    key={`${item.taskId}-${item.checklistIndex}`}
                    item={item}
                    onComplete={handleCompleteChecklistItem}
                    onViewDetails={handleViewChecklistDetails}
                    onProjectClick={() => navigate(`/user/task-manager/${item.taskId}`)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <LuCheck className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">No tasks assigned to you yet.</p>
                <p className="text-gray-400 text-xs mt-1">Domain managers will assign tasks to you based on your skills.</p>
              </div>
            )}
          </div>

          {/* Timeline View */}
          {checklistData.checklistItems && checklistData.checklistItems.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <LuCalendar className="w-5 h-5 text-blue-600" />
                Task Timeline
              </h3>
              <div className="space-y-4">
                {checklistData.checklistItems
                  .sort((a, b) => new Date(a.taskDueDate) - new Date(b.taskDueDate))
                  .slice(0, 8)
                  .map((item, index) => (
                    <div key={`timeline-${item.taskId}-${item.checklistIndex}`} className="flex items-start gap-4">
                      {/* Timeline Line */}
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full ${
                          item.completed ? 'bg-green-500' : 
                          item.isOverdue ? 'bg-red-500' : 
                          'bg-blue-500'
                        }`}></div>
                        {index < Math.min(7, checklistData.checklistItems.length - 1) && (
                          <div className="w-0.5 h-8 bg-gray-300 mt-1"></div>
                        )}
                      </div>
                      
                      {/* Task Content */}
                      <div className="flex-1 bg-gray-50 rounded-lg p-3 border border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900 text-sm">{item.text}</h4>
                          <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                            item.completed ? 'bg-green-100 text-green-800' :
                            item.isOverdue ? 'bg-red-100 text-red-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {item.completed ? 'Completed' : item.isOverdue ? 'Overdue' : 'Pending'}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mb-2">{item.taskTitle}</p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>Due: {moment(item.taskDueDate).format("MMM DD, YYYY")}</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            item.taskPriority === 'High' ? 'bg-red-100 text-red-800' :
                            item.taskPriority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {item.taskPriority} Priority
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      )}



      {/* Recent Projects */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <LuTarget className="w-6 h-6 text-blue-600" />
            Recent Projects
          </h2>
              <button className="card-btn" onClick={onSeeMore}>
                See All <LuArrowRight className="text-base" />
              </button>
            </div>

        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <TaskListTable tableData={dashboardData?.recentTasks || []} />
        )}
      </div>
    </DashboardLayout>
  );
};

export default UserDashboard;
