import moment from "moment";
import React, { useContext, useEffect, useState } from "react";
import { toast } from "react-hot-toast";
import { LuArrowLeft, LuCalendar, LuTarget, LuUsers } from "react-icons/lu";
import { useNavigate, useParams } from "react-router-dom";
import ChecklistItemManager from "../../components/ChecklistItemManager";
import DashboardLayout from "../../components/layouts/DashboardLayout";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";

const TaskManager = () => {
  const { user } = useContext(UserContext);
  const { projectId } = useParams(); // Get project ID from URL
  const navigate = useNavigate();
  
  const [checklistData, setChecklistData] = useState(null);
  const [projectDetails, setProjectDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (projectId) {
      getChecklistData();
      getProjectDetails();
    } else {
      // If no project ID, get all user tasks (existing behavior)
      getChecklistData();
    }
  }, [projectId]);

  const getChecklistData = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_USER_CHECKLIST_ITEMS);
      
      if (projectId) {
        // Filter tasks by specific project
        const filteredData = {
          ...response.data,
          checklistItems: response.data.checklistItems.filter(item => 
            item.taskId === projectId
          ),
          statistics: {
            total: response.data.checklistItems.filter(item => item.taskId === projectId).length,
            completed: response.data.checklistItems.filter(item => 
              item.taskId === projectId && item.completed
            ).length,
            rejected: response.data.checklistItems.filter(item => 
              item.taskId === projectId && item.rejected
            ).length,
            pending: response.data.checklistItems.filter(item => 
              item.taskId === projectId && !item.completed && !item.rejected
            ).length
          }
        };
        setChecklistData(filteredData);
      } else {
        setChecklistData(response.data);
      }
    } catch (error) {
      console.error("Error fetching checklist data:", error);
      setError("Failed to load tasks");
    } finally {
      setLoading(false);
    }
  };

  const getProjectDetails = async () => {
    if (!projectId) return;
    
    try {
      const response = await axiosInstance.get(`${API_PATHS.TASKS.GET_TASK_BY_ID}/${projectId}`);
      setProjectDetails(response.data);
    } catch (error) {
      console.error("Error fetching project details:", error);
    }
  };

  const handleStatusUpdate = async (item, newStatus) => {
    try {
      // Use the correct API endpoint
      const response = await axiosInstance.put(
        API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_STATUS(item.taskId, item.checklistIndex),
        {
          completed: newStatus === 'completed',
          rejected: newStatus === 'rejected'
        }
      );

      if (response.data.message) {
        // Update local state
        setChecklistData(prev => ({
          ...prev,
          checklistItems: prev.checklistItems.map(taskItem => 
            taskItem.taskId === item.taskId && taskItem.checklistIndex === item.checklistIndex
              ? { ...taskItem, completed: newStatus === 'completed', rejected: newStatus === 'rejected' }
              : taskItem
          )
        }));
        
        // Update statistics to reflect the new status
        setChecklistData(prev => {
          const updatedItems = prev.checklistItems.map(taskItem => 
            taskItem.taskId === item.taskId && taskItem.checklistIndex === item.checklistIndex
              ? { ...taskItem, completed: newStatus === 'completed', rejected: newStatus === 'rejected' }
              : taskItem
          );
          
          // Recalculate statistics
          const total = updatedItems.length;
          const completed = updatedItems.filter(item => item.completed).length;
          const rejected = updatedItems.filter(item => item.rejected).length;
          const pending = total - completed - rejected;
          
          return {
            ...prev,
            checklistItems: updatedItems,
            statistics: {
              total,
              completed,
              rejected,
              pending
            }
          };
        });
        
        // Show success message
        toast.success(`Task ${newStatus === 'completed' ? 'completed' : newStatus === 'rejected' ? 'rejected' : 'moved to pending'}`);
        
        // Show additional info for completed tasks
        if (newStatus === 'completed') {
          toast.success('Progress updated! Check "My Projects" page to see the updated progress bar.', {
            duration: 4000,
          });
        }
      }
    } catch (error) {
      console.error("Error updating task status:", error);
      toast.error("Failed to update task status");
    }
  };

  const handleDescriptionUpdate = async (item, description) => {
    try {
      const response = await axiosInstance.put(
        API_PATHS.TASKS.UPDATE_CHECKLIST_ITEM_DESCRIPTION(item.taskId, item.checklistIndex),
        { description }
      );

      if (response.data.message) {
        // Update local state
        setChecklistData(prev => ({
          ...prev,
          checklistItems: prev.checklistItems.map(taskItem => 
            taskItem.taskId === item.taskId && taskItem.checklistIndex === item.checklistIndex
              ? { ...taskItem, description }
              : taskItem
          )
        }));
        
        toast.success("Description updated successfully");
      }
    } catch (error) {
      console.error("Error updating task description:", error);
      toast.error("Failed to update description");
    }
  };

  const goBack = () => {
    if (projectId) {
      // Go back to the previous page or dashboard
      navigate(-1);
    } else {
      navigate("/user/dashboard");
    }
  };

  if (loading) {
    return (
      <DashboardLayout activeMenu="task-manager">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout activeMenu="task-manager">
        <div className="text-center py-8">
          <p className="text-red-500">{error}</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout activeMenu="task-manager">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={goBack}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <LuArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {projectId ? 'Project Task Manager' : 'Task Manager'}
              </h1>
              <p className="text-gray-600">
                {projectId 
                  ? `Manage all tasks for: ${projectDetails?.title || 'Project'}`
                  : 'Manage all your assigned tasks'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Project Details Card (if viewing specific project) */}
        {projectId && projectDetails && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center gap-3">
                <LuTarget className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-500">Project Title</p>
                  <p className="font-medium text-gray-900">{projectDetails.title}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <LuCalendar className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-500">Due Date</p>
                  <p className="font-medium text-gray-900">
                    {moment(projectDetails.dueDate).format('MMM DD, YYYY')}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <LuUsers className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-500">Priority</p>
                  <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                    projectDetails.priority === 'High' 
                      ? 'bg-red-100 text-red-800' 
                      : projectDetails.priority === 'Medium' 
                      ? 'bg-yellow-100 text-yellow-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {projectDetails.priority} Priority
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Task Statistics */}
        {checklistData && checklistData.statistics && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {checklistData.statistics.total || 0}
                </div>
                <div className="text-sm text-gray-600">Total Tasks</div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">
                  {checklistData.statistics.pending || 0}
                </div>
                <div className="text-sm text-gray-600">Pending</div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {checklistData.statistics.completed || 0}
                </div>
                <div className="text-sm text-gray-600">Completed</div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {checklistData.statistics.rejected || 0}
                </div>
                <div className="text-sm text-gray-600">Rejected</div>
              </div>
            </div>
          </div>
        )}

        {/* Overall Progress Bar */}
        {checklistData && checklistData.statistics && checklistData.statistics.total > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Overall Progress</h3>
              <span className="text-sm font-medium text-gray-600">
                {checklistData.statistics.completed} of {checklistData.statistics.total} tasks completed
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-500 ease-out"
                style={{ 
                  width: `${(checklistData.statistics.completed / checklistData.statistics.total) * 100}%` 
                }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>0%</span>
              <span>50%</span>
              <span>100%</span>
            </div>
          </div>
        )}

        {/* Checklist Manager */}
        {checklistData && checklistData.checklistItems && checklistData.checklistItems.length > 0 ? (
          <ChecklistItemManager
            checklistItems={checklistData.checklistItems}
            onStatusUpdate={handleStatusUpdate}
            onDescriptionUpdate={handleDescriptionUpdate}
          />
        ) : (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
            <LuTarget className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {projectId ? 'No tasks found for this project' : 'No tasks assigned yet'}
            </h3>
            <p className="text-gray-500">
              {projectId 
                ? 'This project doesn\'t have any tasks assigned to you yet.'
                : 'Domain managers will assign tasks to you based on your skills.'
              }
            </p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default TaskManager;
