import moment from 'moment';
import React, { useContext, useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { LuBell, LuMessageSquare, LuX } from 'react-icons/lu';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/userContext';
import { API_PATHS } from '../utils/apiPaths';
import axiosInstance from '../utils/axiosInstance';

const NotificationBell = () => {
  const navigate = useNavigate();
  const { user, loading } = useContext(UserContext);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 10000);
    return () => clearInterval(interval);
  }, [user]);

  const fetchNotifications = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_NOTIFICATIONS);
      setNotifications(response.data || []);
      const unread = (response.data || []).filter(n => !n.read).length;
      setUnreadCount(unread);
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  };

  const markAsRead = async (notificationId) => {
    try {
      await axiosInstance.put(API_PATHS.TASKS.MARK_NOTIFICATION_READ(notificationId));
      // Update local state
      setNotifications(prev => 
        prev.map(n => n._id === notificationId ? { ...n, read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const handleNotificationClick = (notification) => {
    if (!notification.read) {
      markAsRead(notification._id);
    }
    
    // Get current user role from context
    const userRole = user?.role;
    
    // Navigate to messages page based on user role with specific conversation parameters
    if (userRole === 'admin') {
      // For admin, navigate to messages with the domain manager who sent the notification
      const params = new URLSearchParams();
      if (notification.fromUser?._id) {
        params.set('userId', notification.fromUser._id);
      }
      if (notification.taskId) {
        params.set('taskId', notification.taskId);
      }
      if (notification.type) {
        params.set('type', notification.type);
      }
      navigate(`/admin/messages?${params.toString()}`);
    } else if (userRole === 'domain_manager') {
      // For domain manager, navigate to messages with the admin who created the task
      const params = new URLSearchParams();
      if (notification.toUser?._id) {
        params.set('userId', notification.toUser._id);
      } else if (notification.fromUser?._id) {
        params.set('userId', notification.fromUser._id);
      }
      if (notification.taskId) {
        params.set('taskId', notification.taskId);
      }
      if (notification.type) {
        params.set('type', notification.type);
      }
      navigate(`/domain-manager/messages?${params.toString()}`);
         } else {
       // For regular users, navigate to their messages page with conversation parameters
       const params = new URLSearchParams();
       if (notification.type === "message" && notification.fromUser?._id) {
         // For message notifications, navigate to conversation with the sender
         params.set('userId', notification.fromUser._id);
         params.set('type', 'message');
         navigate(`/user/messages?${params.toString()}`);
         toast.success(`Opening conversation with ${notification.fromUser?.name || "User"}`);
       } else {
         // For other notifications, just navigate to messages page
         navigate("/user/messages");
         toast.success("Opening your messages");
       }
       setShowDropdown(false);
       return;
     }
    
    setShowDropdown(false);
    
         // Show a toast to inform the user
     if (userRole === 'admin' || userRole === 'domain_manager') {
       if (notification.type === "checklist_rejection") {
         toast.success(`Opening messages to discuss the rejected checklist item with ${notification.fromUser?.name || "Domain Manager"}`);
       } else if (notification.type === "message") {
         toast.success(`Opening messages to read the new message from ${notification.fromUser?.name || "User"}`);
       } else {
         toast.success("Opening messages to continue the conversation");
       }
     }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case "feedback":
        return <LuMessageSquare className="w-4 h-4 text-red-500" />;
      case "checklist_rejection":
        return <LuX className="w-4 h-4 text-red-500" />;
      case "message":
        return <LuMessageSquare className="w-4 h-4 text-blue-500" />;
      case "approval":
        return <LuMessageSquare className="w-4 h-4 text-green-500" />;
      case "assignment":
        return <LuMessageSquare className="w-4 h-4 text-blue-500" />;
      default:
        return <LuMessageSquare className="w-4 h-4 text-gray-500" />;
    }
  };

  const getNotificationMessage = (notification) => {
    if (notification.type === "feedback") {
      return `Domain Manager ${notification.fromUser?.name || "Unknown"} sent feedback about checklist items`;
    }
    if (notification.type === "checklist_rejection") {
      return `Domain Manager ${notification.fromUser?.name || "Unknown"} rejected a checklist item`;
    }
    if (notification.type === "message") {
      return notification.message || `New message from ${notification.fromUser?.name || "Unknown"}`;
    }
    return notification.message;
  };

  if (loading) {
    return (
      <div className="relative">
        <div className="text-xs text-gray-500 mb-1">Loading...</div>
        <button className="relative p-2 text-gray-400 transition-colors border border-gray-300 rounded" disabled>
          <LuBell className="w-6 h-6" />
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
     
      
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        className="relative p-2 text-gray-600 hover:text-gray-800 transition-colors  rounded"
      >
        <LuBell className="w-6 h-6" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      {showDropdown && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-96 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800">Notifications</h3>
              <button
                onClick={() => setShowDropdown(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <LuX className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="p-2">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <LuBell className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p>No notifications</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification._id}
                  className={`p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${
                    !notification.read ? "bg-blue-50" : ""
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className="flex items-start gap-3">
                    {getNotificationIcon(notification.type)}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">
                        {getNotificationMessage(notification)}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        From: {notification.fromUser?.name || "Unknown"}
                      </p>
                      <p className="text-xs text-gray-500">
                        Task: {notification.taskTitle}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {moment(notification.createdAt).fromNow()}
                      </p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationBell; 