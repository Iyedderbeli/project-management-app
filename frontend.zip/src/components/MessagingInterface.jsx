import moment from "moment";
import React, { useContext, useEffect, useState } from "react";
import { LuArrowLeft, LuSend } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../context/userContext";
import { API_PATHS } from "../utils/apiPaths";
import axiosInstance from "../utils/axiosInstance";

const MessagingInterface = ({ taskId, domainManagerId, onClose, notification = null }) => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [task, setTask] = useState(null);
  const [otherUser, setOtherUser] = useState(null);
  const [rejectionContext, setRejectionContext] = useState(null);

  useEffect(() => {
    if (taskId) {
      fetchTaskDetails();
      fetchMessages();
      
      // If this is a checklist rejection notification, set up the context
      if (notification && notification.type === "checklist_rejection") {
        setRejectionContext({
          todoIndex: notification.todoIndex,
          rejectionFeedback: notification.rejectionFeedback,
          checklistItem: notification.message.split('"')[1] // Extract checklist item name from message
        });
      }
    }
  }, [taskId, notification]);

  const fetchTaskDetails = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_TASK_BY_ID(taskId));
      setTask(response.data);
      
      // Find the other user (domain manager or admin)
      if (user.role === "admin") {
        // Admin is messaging domain manager
        const dm = response.data.assignedDomainManagers?.find(dm => dm._id === domainManagerId);
        setOtherUser(dm);
      } else if (user.role === "domain_manager") {
        // Domain manager is messaging admin
        setOtherUser(response.data.createdBy);
      }
    } catch (error) {
      console.error("Error fetching task details:", error);
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATION(domainManagerId));
      if (response.data && Array.isArray(response.data)) {
        setMessages(response.data);
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    try {
      setLoading(true);
      
      const response = await axiosInstance.post(API_PATHS.MESSAGES.SEND_MESSAGE, {
        toUserId: domainManagerId,
        message: newMessage.trim(),
        taskId: taskId
      });

      if (response.data) {
        setMessages(prev => [...prev, response.data]);
        setNewMessage("");
      }
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (!task || !otherUser) {
    return (
      <div className="flex items-center justify-center h-full bg-white rounded-lg shadow-lg">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b-2 border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center gap-4">
          <button
            onClick={onClose}
            className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-all duration-200"
          >
            <LuArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold">
              {otherUser.name?.charAt(0)?.toUpperCase() || "U"}
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">
                {otherUser.name}
              </h2>
              <p className="text-sm text-gray-600 font-medium">
                {user.role === "admin" ? "Domain Manager" : "Admin"} • {task.title}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Rejection Context */}
      {rejectionContext && (
        <div className="p-4 bg-gradient-to-r from-red-50 to-pink-50 border-b-2 border-red-200">
          <div className="flex items-start gap-3">
            <div className="w-3 h-3 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
            <div className="flex-1">
              <p className="text-sm font-bold text-red-800 mb-1">
                📋 Checklist Item Rejected
              </p>
              <div className="bg-white rounded-lg p-3 border border-red-200">
                <p className="text-xs text-red-700 mb-1">
                  <span className="font-semibold">Item:</span> {rejectionContext.checklistItem}
                </p>
                <p className="text-xs text-red-700">
                  <span className="font-semibold">Feedback:</span> {rejectionContext.rejectionFeedback}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 py-12">
            <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <LuSend className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-lg font-medium text-gray-600">No messages yet</p>
            <p className="text-sm mt-2 text-gray-500">Start the conversation!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message._id}
              className={`flex ${message.fromUser._id === user._id ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-sm ${
                  message.fromUser._id === user._id
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white'
                    : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                <p className="text-sm leading-relaxed">{message.message}</p>
                <p className={`text-xs mt-2 ${message.fromUser._id === user._id ? 'text-blue-100' : 'text-gray-500'}`}>
                  {moment(message.createdAt).format('HH:mm')}
                </p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Message Input */}
      <div className="p-6 border-t-2 border-gray-100 bg-white">
        <div className="flex gap-3">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-700 placeholder-gray-400"
            disabled={loading}
          />
          <button
            onClick={sendMessage}
            disabled={!newMessage.trim() || loading}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl hover:from-blue-600 hover:to-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
          >
            <LuSend className="w-4 h-4" />
            <span className="text-sm font-medium">Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MessagingInterface; 