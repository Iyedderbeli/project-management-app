import React from "react";
import { LuX } from "react-icons/lu";

const Modal = ({ children, isOpen, onClose, title }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="relative bg-white rounded-lg shadow-sm max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">{title}</h3>
          <button 
            className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center cursor-pointer" 
            onClick={onClose}
          >
            <LuX className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 md:p-5">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;