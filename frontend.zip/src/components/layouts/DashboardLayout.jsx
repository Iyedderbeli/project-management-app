import React, { useContext } from "react";
import { UserContext } from "../../context/userContext";
import Navbar from "./Navbar";
import SideMenu from "./SideMenu";

const DashboardLayout = ({ children, activeMenu }) => {
    const { user, loading } = useContext(UserContext);
    
    if (loading) {
      return (
        <div className="flex items-center justify-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      );
    }
    
    if (!user) {
      return (
        <div className="flex items-center justify-center h-screen">
          <div>Loading user data...</div>
        </div>
      );
    }
    
    return (
      <div className="">
        <Navbar activeMenu={activeMenu} />
        <div className="flex">
          <div className="max-[1080px]:hidden">
            <SideMenu activeMenu={activeMenu} />
          </div>
          
          <div className="grow mx-5">
            {children}
          </div>
        </div>
      </div>
    );
  };

export default DashboardLayout;
