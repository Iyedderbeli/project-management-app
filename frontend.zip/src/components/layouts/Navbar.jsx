import React, { useContext } from "react";
import { LuLogOut } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../../context/userContext";
import MessageNotificationBell from "../MessageNotificationBell";
import NotificationBell from "../NotificationBell";

const Navbar = ({ activeMenu }) => {
  const { user, clearUser } = useContext(UserContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    clearUser();
    navigate("/login");
  };

  return (
    <div className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-semibold text-gray-800 capitalize">
            {activeMenu}
          </h1>
        </div>

        <div className="flex items-center gap-4">
          {/* Show message notification bell for all users */}
          <MessageNotificationBell />
          
          {/* Show notification bell for all users */}
          <NotificationBell />
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <img
                src={user?.profileImageUrl}
                alt={user?.name}
                className="w-8 h-8 rounded-full"
              />
              <div className="hidden md:block">
                <p className="text-sm font-medium text-gray-800">
                  {user?.name}
                </p>
                <p className="text-xs text-gray-500 capitalize">
                  {user?.role}
                </p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              <LuLogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;