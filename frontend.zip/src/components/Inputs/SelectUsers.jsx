import React, { useEffect, useState } from "react";
import { LuStar, LuTarget, LuUsers } from "react-icons/lu";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import AvatarGroup from "../AvatarGroup";
import Modal from "../Modal";

const SelectUsers = ({ selectedUsers, setSelectedUsers, showSkills = true, requiredSkills = [], taskId = null, todoIndex = null }) => {
  const [allUsers, setAllUsers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tempSelectedUsers, setTempSelectedUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterBySkills, setFilterBySkills] = useState(requiredSkills.length > 0);
  const [searchTerm, setSearchTerm] = useState("");

  const getAllUsers = async () => {
    try {
      setLoading(true);
      let response;
      
      if (taskId && todoIndex && requiredSkills.length > 0) {
        // Get suitable users for specific checklist item
        response = await axiosInstance.get(API_PATHS.TASKS.GET_SUITABLE_USERS_FOR_CHECKLIST_ITEM(taskId, todoIndex));
      } else if (requiredSkills.length > 0 && filterBySkills) {
        // Get users by skills
        const skillsParam = requiredSkills.join(',');
        response = await axiosInstance.get(`${API_PATHS.USERS.GET_USERS_BY_SKILLS}?skills=${skillsParam}`);
      } else {
        // Get all users
        response = await axiosInstance.get(API_PATHS.USERS.GET_ALL_USERS);
        if (response.data?.length > 0) {
          // Filter only regular users (not admins or domain managers)
          const regularUsers = response.data.filter(user => user.role === "member" || user.role === "user");
          setAllUsers(regularUsers);
          return;
        }
      }
      
      if (response.data?.length > 0) {
        setAllUsers(response.data);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleUserSelection = (userId) => {
    setTempSelectedUsers((prev) =>
      prev.includes(userId)
        ? prev.filter((id) => id !== userId)
        : [...prev, userId]
    );
  };

  const handleAssign = () => {
    setSelectedUsers(tempSelectedUsers);
    setIsModalOpen(false);
  };

  const selectedUserAvatars = allUsers
    .filter((user) => selectedUsers.includes(user._id))
    .map((user) => user.profileImageUrl);

  // Filter users based on search term and skills
  const getFilteredUsers = () => {
    let filtered = allUsers;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(user =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by required skills if enabled
    if (filterBySkills && requiredSkills.length > 0) {
      filtered = filtered.filter(user =>
        user.skills?.some(skill =>
          requiredSkills.some(requiredSkill =>
            skill.name.toLowerCase().includes(requiredSkill.toLowerCase())
          )
        )
      );
    }

    return filtered;
  };

  const filteredUsers = getFilteredUsers();

  useEffect(() => {
    getAllUsers();
  }, [taskId, todoIndex, requiredSkills, filterBySkills]);

  useEffect(() => {
    if (selectedUsers.length === 0) {
      setTempSelectedUsers([]);
    }
    return () => {};
  }, [selectedUsers]);

  const getSkillLevel = (rating) => {
    if (rating >= 4.5) return "Expert";
    if (rating >= 3.5) return "Advanced";
    if (rating >= 2.5) return "Intermediate";
    if (rating >= 1.5) return "Beginner";
    return "Novice";
  };

  const getSkillColor = (rating) => {
    if (rating >= 4.5) return "text-green-600 bg-green-100";
    if (rating >= 3.5) return "text-blue-600 bg-blue-100";
    if (rating >= 2.5) return "text-yellow-600 bg-yellow-100";
    if (rating >= 1.5) return "text-orange-600 bg-orange-100";
    return "text-red-600 bg-red-100";
  };

  const getOverallRatingColor = (rating) => {
    if (rating >= 4.5) return "text-green-600";
    if (rating >= 3.5) return "text-blue-600";
    if (rating >= 2.5) return "text-yellow-600";
    if (rating >= 1.5) return "text-orange-600";
    return "text-red-600";
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <LuStar key={i} className="w-4 h-4 fill-current text-yellow-400" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <LuStar key="half" className="w-4 h-4 fill-current text-yellow-400 opacity-50" />
      );
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <LuStar key={`empty-${i}`} className="w-4 h-4 text-gray-300" />
      );
    }

    return stars;
  };

  const hasRequiredSkills = (user) => {
    if (!filterBySkills || requiredSkills.length === 0) return true;
    
    return user.skills?.some(skill =>
      requiredSkills.some(requiredSkill =>
        skill.name.toLowerCase().includes(requiredSkill.toLowerCase())
      )
    );
  };

  const getSkillMatchScore = (user) => {
    if (!filterBySkills || requiredSkills.length === 0) return 0;
    
    let matchScore = 0;
    let totalRequired = requiredSkills.length;
    
    requiredSkills.forEach(requiredSkill => {
      const matchingSkill = user.skills?.find(skill =>
        skill.name.toLowerCase().includes(requiredSkill.toLowerCase())
      );
      if (matchingSkill) {
        matchScore += matchingSkill.rating;
      }
    });
    
    return totalRequired > 0 ? (matchScore / totalRequired).toFixed(1) : 0;
  };

  return (
    <>
      <div className="flex items-center gap-2">
        <AvatarGroup avatars={selectedUserAvatars} />
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <LuUsers className="w-4 h-4" />
          {selectedUsers.length > 0 ? `${selectedUsers.length} selected` : "Select Users"}
        </button>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Select Users">
        <div className="p-4">
          {/* Required Skills Display */}
          {requiredSkills.length > 0 && (
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <LuTarget className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">Required Skills for this Task:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {requiredSkills.map((skill, index) => (
                  <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Search and Filter */}
          <div className="mb-4">
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                placeholder="Search users by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
              {requiredSkills.length > 0 && (
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={filterBySkills}
                    onChange={(e) => setFilterBySkills(e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  Filter by required skills
                </label>
              )}
            </div>
          </div>

          {/* Users List */}
          <div className="max-h-96 overflow-y-auto space-y-3">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-gray-500 mt-2">Loading users...</p>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">
                  {searchTerm || (filterBySkills && requiredSkills.length > 0)
                    ? "No users found matching your criteria."
                    : "No users available."}
                </p>
              </div>
            ) : (
              filteredUsers.map((user) => {
                const isSelected = tempSelectedUsers.includes(user._id);
                const skillMatchScore = getSkillMatchScore(user);
                const hasSkills = hasRequiredSkills(user);

                return (
                  <div
                    key={user._id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      isSelected
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                    } ${!hasSkills && filterBySkills ? "opacity-50" : ""}`}
                    onClick={() => toggleUserSelection(user._id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleUserSelection(user._id)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <img
                          src={user.profileImageUrl}
                          alt="avatar"
                          className="w-10 h-10 rounded-full border-2 border-white"
                        />
                        <div>
                          <div className="font-medium text-gray-900">{user.name}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        {/* Skill Match Score */}
                        {filterBySkills && requiredSkills.length > 0 && (
                          <div className="text-right">
                            <div className="text-xs text-gray-500">Skill Match</div>
                            <div className="text-sm font-medium text-blue-600">
                              {skillMatchScore}/5
                            </div>
                          </div>
                        )}

                        {/* Overall Rating */}
                        {user.overallRating && (
                          <div className="text-right">
                            <div className="text-xs text-gray-500">Overall</div>
                            <div className="flex items-center gap-1">
                              {renderStars(user.overallRating)}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Skills Display */}
                    {showSkills && user.skills && user.skills.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-gray-200">
                        <div className="text-xs text-gray-500 mb-2">Skills:</div>
                        <div className="flex flex-wrap gap-1">
                          {user.skills.map((skill, index) => {
                            const isRequired = requiredSkills.some(requiredSkill =>
                              skill.name.toLowerCase().includes(requiredSkill.toLowerCase())
                            );
                            return (
                              <span
                                key={index}
                                className={`px-2 py-1 text-xs rounded ${
                                  isRequired && filterBySkills
                                    ? "bg-green-100 text-green-800 border border-green-200"
                                    : getSkillColor(skill.rating)
                                }`}
                              >
                                {skill.name} ({skill.rating}/5)
                                {isRequired && filterBySkills && (
                                  <span className="ml-1">✓</span>
                                )}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
            <button
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleAssign}
              disabled={tempSelectedUsers.length === 0}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <LuUsers className="w-4 h-4" />
              Assign {tempSelectedUsers.length > 0 ? `(${tempSelectedUsers.length})` : ""}
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default SelectUsers;
