import React, { useEffect, useState } from "react";
import { LuAward, LuStar, LuUsers } from "react-icons/lu";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import AvatarGroup from "../AvatarGroup";
import Modal from "../Modal";

const SelectDomainManagers = ({ selectedDomainManagers, setSelectedDomainManagers, requiredExpertise = [] }) => {
  const [allDomainManagers, setAllDomainManagers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tempSelectedDomainManagers, setTempSelectedDomainManagers] = useState([]);
  const [loading, setLoading] = useState(false);

  // Debug logs
  console.log("SelectDomainManagers props:", { selectedDomainManagers, requiredExpertise });
  console.log("tempSelectedDomainManagers state:", tempSelectedDomainManagers);

  const getAllDomainManagers = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.USERS.GET_DOMAIN_MANAGERS);
      if (response.data?.length > 0) {
        // Sort by expertise match if required expertise is provided
        if (requiredExpertise.length > 0) {
          const sortedManagers = response.data.map(manager => {
            const expertiseMatchScore = requiredExpertise.length > 0 
              ? manager.domainExpertise.filter(expertise => requiredExpertise.includes(expertise)).length / requiredExpertise.length
              : 0;
            
            return {
              ...manager,
              expertiseMatchScore,
              matchedExpertise: manager.domainExpertise.filter(expertise => requiredExpertise.includes(expertise))
            };
          }).sort((a, b) => {
            // Sort by expertise match first, then by overall rating
            if (a.expertiseMatchScore !== b.expertiseMatchScore) {
              return b.expertiseMatchScore - a.expertiseMatchScore;
            }
            return b.overallRating - a.overallRating;
          });
          
          setAllDomainManagers(sortedManagers);
        } else {
          setAllDomainManagers(response.data);
        }
      }
    } catch (error) {
      console.error("Error fetching domain managers:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleDomainManagerSelection = (userId) => {
    setTempSelectedDomainManagers((prev) =>
      prev.includes(userId)
        ? prev.filter((id) => id !== userId)
        : [...prev, userId]
    );
  };

  const handleAssign = () => {
    setSelectedDomainManagers(tempSelectedDomainManagers);
    setIsModalOpen(false);
  };

  const selectedDomainManagerAvatars = allDomainManagers
    .filter((manager) => selectedDomainManagers.includes(manager._id))
    .map((manager) => manager.profileImageUrl || "/default-avatar.png"); // Fallback for missing profile images

  // Debug log for selected domain managers
  console.log("Selected Domain Manager Avatars:", selectedDomainManagerAvatars);
  console.log("All Domain Managers:", allDomainManagers);
  console.log("Selected Domain Manager IDs:", selectedDomainManagers);
  
  // Debug log for filtered managers
  const filteredManagers = allDomainManagers.filter((manager) => selectedDomainManagers.includes(manager._id));
  console.log("Filtered Managers:", filteredManagers);
  console.log("Manager IDs with profileImageUrl:", filteredManagers.map(m => ({ id: m._id, name: m.name, profileImageUrl: m.profileImageUrl })));

  useEffect(() => {
    getAllDomainManagers();
  }, [requiredExpertise]);

  // Debug log for useEffect dependencies
  console.log("useEffect dependencies - requiredExpertise:", requiredExpertise);
  console.log("useEffect dependencies - allDomainManagers length:", allDomainManagers.length);

  useEffect(() => {
    // Initialize tempSelectedDomainManagers when selectedDomainManagers changes
    console.log("useEffect triggered - selectedDomainManagers changed:", selectedDomainManagers);
    setTempSelectedDomainManagers(selectedDomainManagers);
  }, [selectedDomainManagers]);

  const getOverallRatingColor = (rating) => {
    if (rating >= 4.5) return "text-green-600";
    if (rating >= 3.5) return "text-blue-600";
    if (rating >= 2.5) return "text-yellow-600";
    if (rating >= 1.5) return "text-orange-600";
    return "text-red-600";
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <LuStar
        key={i}
        className={`w-3 h-3 ${
          i < Math.floor(rating) ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="space-y-4 mt-0 h-fit w-md">
      {selectedDomainManagerAvatars.length === 0 && (
        <button
          className="whitespace-nowrap flex items-center gap-3 text-[12px] text-sm font-medium text-gray-700 hover:text-primary bg-gray-50 hover:bg-blue-50 px-4 py-3.5 rounded-lg border-gray-200/50 cursor-pointer"
          onClick={() => setIsModalOpen(true)}
        >
          <LuUsers className="text-sm" /> Add Domain Managers
        </button>
      )}

      {selectedDomainManagerAvatars.length > 0 && (
        <div className="cursor-pointer" onClick={() => setIsModalOpen(true)}>
          <AvatarGroup avatars={selectedDomainManagerAvatars} maxVisible={3} />
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Select Domain Managers"
      >
        <div className="space-y-4">
          {/* Expertise Requirements */}
          {requiredExpertise.length > 0 && (
            <div className="flex items-center gap-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2">
                <LuAward className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">Required Expertise:</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {requiredExpertise.map((expertise, index) => (
                  <span key={index} className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                    {expertise}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Domain Managers List */}
          <div className="h-[60vh] overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : allDomainManagers.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No domain managers found
              </div>
            ) : (
              allDomainManagers.map((manager) => (
                <div
                  key={manager._id}
                  className="flex items-center justify-between gap-4 p-3 border-b border-gray-200 hover:bg-gray-50"
                >
                  <div className="flex items-center gap-3 flex-1">
                    <img
                      src={manager.profileImageUrl}
                      alt={manager.name}
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-gray-800">{manager.name}</p>
                        {manager.overallRating && (
                          <div className="flex items-center gap-1">
                            {renderStars(manager.overallRating)}
                            <span className={`text-xs font-medium ${getOverallRatingColor(manager.overallRating)}`}>
                              {manager.overallRating}
                            </span>
                          </div>
                        )}
                      </div>
                      <p className="text-[13px] text-gray-500">
                        {manager.email}
                      </p>
                      {manager.domainExpertise && manager.domainExpertise.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {manager.domainExpertise.slice(0, 3).map((expertise, index) => (
                            <span
                              key={index}
                              className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700"
                            >
                              {expertise}
                            </span>
                          ))}
                          {manager.domainExpertise.length > 3 && (
                            <span className="text-xs text-gray-500">
                              +{manager.domainExpertise.length - 3} more
                            </span>
                          )}
                        </div>
                      )}
                      {manager.expertiseMatchScore !== undefined && (
                        <div className="mt-1">
                          <span className="text-xs text-purple-600 font-medium">
                            Expertise Match: {Math.round(manager.expertiseMatchScore * 100)}%
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={tempSelectedDomainManagers.includes(manager._id)}
                    onChange={() => toggleDomainManagerSelection(manager._id)}
                    className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded-sm outline-none"
                  />
                </div>
              ))
            )}
          </div>
        </div>
        <div className="flex justify-end gap-4 pt-4">
          <button className="card-btn" onClick={() => setIsModalOpen(false)}>
            CANCEL
          </button>
          <button className="card-btn-fill" onClick={handleAssign}>
            DONE
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default SelectDomainManagers; 