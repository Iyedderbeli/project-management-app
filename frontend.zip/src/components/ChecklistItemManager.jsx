import {
  closestCenter,
  defaultDropAnimationSideEffects,
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import moment from "moment";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { LuCalendar, LuCheck, LuClock, LuPencil, LuSave, LuTarget, LuUsers, LuX } from "react-icons/lu";

// Sortable Item Component
const SortableItem = ({ item, columnId, onEdit, editingItem, descriptionText, setDescriptionText, onSaveDescription, onCancelEditing }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ 
    id: `${item.taskId}-${item.checklistIndex}`,
    data: {
      type: 'item',
      item: item,
      columnId: columnId
    }
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "High":
        return "bg-red-100 text-red-800 border-red-200";
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (item) => {
    if (item.completed) {
      return <LuCheck className="w-4 h-4 text-green-600" />;
    } else if (item.rejected) {
      return <LuX className="w-4 h-4 text-red-600" />;
    } else {
      // If neither completed nor rejected, it's pending/in progress
      return <LuClock className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`drag-item bg-white rounded-lg border border-gray-200 p-4 mb-3 shadow-sm hover:shadow-md transition-all duration-200 cursor-grab active:cursor-grabbing ${
        isDragging ? "dragging opacity-50 scale-95 shadow-xl rotate-2" : ""
      }`}
    >
      {/* Task Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {getStatusIcon(item)}
          <div>
            <h4 className="font-medium text-gray-900 text-sm line-clamp-2">
              {item.text}
            </h4>
            <p className="text-xs text-gray-500">{item.taskTitle}</p>
          </div>
        </div>
        <button
          onClick={() => onEdit(item)}
          className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
          title="Edit description"
        >
          <LuPencil className="w-4 h-4" />
        </button>
      </div>

      {/* Priority Badge */}
      <div className="flex items-center justify-between mb-3">
        <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full border ${getPriorityColor(item.taskPriority)}`}>
          {item.taskPriority} Priority
        </span>
        <span className="text-xs text-gray-500">
          Due: {moment(item.taskDueDate).format("MMM DD")}
        </span>
      </div>

      {/* Completion Status */}
      {item.completed && (
        <div className="mb-3 p-2 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-center gap-2 text-xs text-green-700">
            <LuCheck className="w-4 h-4 text-green-600" />
            <span className="font-medium">Completed</span>
            {item.completedAt && (
              <span className="text-green-600">
                on {moment(item.completedAt).format("MMM DD, YYYY")}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Rejection Status */}
      {item.rejected && (
        <div className="mb-3 p-2 bg-red-50 border border-red-200 rounded-md">
          <div className="flex items-center gap-2 text-xs text-red-700">
            <LuX className="w-4 h-4 text-red-600" />
            <span className="font-medium">Rejected</span>
            {item.rejectedAt && (
              <span className="text-red-600">
                on {moment(item.rejectedAt).format("MMM DD, YYYY")}
              </span>
            )}
            {item.rejectionFeedback && (
              <span className="text-red-600">
                - {item.rejectionFeedback}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Description Section */}
      {editingItem && editingItem.taskId === item.taskId && editingItem.checklistIndex === item.checklistIndex ? (
        <div className="mb-3">
          <textarea
            value={descriptionText}
            onChange={(e) => setDescriptionText(e.target.value)}
            placeholder="Add a description for this task..."
            className="w-full p-2 border border-gray-300 rounded-md text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows="3"
          />
          <div className="flex items-center gap-2 mt-2">
            <button
              onClick={() => onSaveDescription()}
              className="flex items-center gap-1 px-3 py-1 bg-green-600 text-white text-xs rounded-md hover:bg-green-700 transition-colors"
            >
              <LuSave className="w-3 h-3" />
              Save
            </button>
            <button
              onClick={() => onCancelEditing()}
              className="flex items-center gap-1 px-3 py-1 bg-gray-600 text-white text-xs rounded-md hover:bg-gray-700 transition-colors"
            >
              <LuX className="w-3 h-3" />
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="mb-3">
          {item.description ? (
            <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded border">
              {item.description}
            </p>
          ) : (
            <p className="text-xs text-gray-400 italic">
              No description added. Click edit to add one.
            </p>
          )}
        </div>
      )}

      {/* Task Info */}
      <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
        <div className="flex items-center gap-1">
          <LuCalendar className="w-3 h-3" />
          <span>{moment(item.taskDueDate).format("MMM DD, YYYY")}</span>
        </div>
        <div className="flex items-center gap-1">
          <LuTarget className="w-3 h-3" />
          <span>{item.taskStatus}</span>
        </div>
      </div>

      {/* Domain Managers */}
      {item.domainManagers && item.domainManagers.length > 0 && (
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
          <LuUsers className="w-3 h-3 text-gray-400" />
          <div className="flex flex-wrap gap-1">
            {item.domainManagers.slice(0, 2).map((dm, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full"
              >
                {dm.name}
              </span>
            ))}
            {item.domainManagers.length > 2 && (
              <span className="text-xs text-gray-500">
                +{item.domainManagers.length - 2} more
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// Droppable Column Component
const DroppableColumn = ({ column, children, onDragOver, isDragOver }) => {
  const { setNodeRef } = useSortable({
    id: column.id,
    data: {
      type: 'column',
      column: column
    }
  });

  return (
    <div 
      ref={setNodeRef}
      className={`column-drop-zone ${column.bgColor} ${column.borderColor} border-2 rounded-lg p-3 transition-all duration-200 hover:shadow-md ${
        isDragOver ? 'drag-over' : ''
      }`}
      data-column-id={column.id}
      onDragOver={onDragOver}
    >
      {children}
    </div>
  );
};

const ChecklistItemManager = ({ checklistItems, onStatusUpdate, onDescriptionUpdate }) => {
  const [columns, setColumns] = useState({
    pending: {
      id: "pending",
      title: "Pending",
      color: "bg-blue-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      items: []
    },
    completed: {
      id: "completed",
      title: "Completed",
      color: "bg-green-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      items: []
    },
    rejected: {
      id: "rejected",
      title: "Rejected",
      color: "bg-red-500",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
      items: []
    }
  });

  const [editingItem, setEditingItem] = useState(null);
  const [descriptionText, setDescriptionText] = useState("");
  const [activeId, setActiveId] = useState(null);
  const [activeItem, setActiveItem] = useState(null);
  const [dragOverColumn, setDragOverColumn] = useState(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    if (checklistItems) {
      const newColumns = { ...columns };
      
      // Reset all columns
      Object.keys(newColumns).forEach(key => {
        newColumns[key].items = [];
      });

      // Distribute items to appropriate columns
      checklistItems.forEach(item => {
        if (item.completed) {
          newColumns.completed.items.push(item);
        } else if (item.rejected) {
          newColumns.rejected.items.push(item);
        } else {
          newColumns.pending.items.push(item);
        }
      });

      setColumns(newColumns);
    }
  }, [checklistItems]);

  const handleDragStart = (event) => {
    const { active } = event;
    setActiveId(active.id);
    
    const [taskId, checklistIndex] = active.id.split('-');
    const item = checklistItems.find(item => 
      item.taskId === taskId && item.checklistIndex === parseInt(checklistIndex)
    );
    setActiveItem(item);
  };

  const handleDragOver = (event) => {
    const { over } = event;
    if (over && ['pending', 'completed', 'rejected'].includes(over.id)) {
      setDragOverColumn(over.id);
    } else {
      setDragOverColumn(null);
    }
  };

  const handleDragEnd = async (event) => {
    const { active, over } = event;
    
    setActiveId(null);
    setActiveItem(null);
    setDragOverColumn(null);

    if (!active || !over) return;

    const activeId = active.id;
    const overId = over.id;

    if (activeId === overId) return;

    // Check if we're dropping on a column
    if (['pending', 'completed', 'rejected'].includes(overId)) {
      const [taskId, checklistIndex] = activeId.split('-');
      const parsedChecklistIndex = parseInt(checklistIndex);
      
      const sourceColumn = Object.keys(columns).find(key => 
        columns[key].items.some(item => 
          `${item.taskId}-${item.checklistIndex}` === activeId
        )
      );
      
      if (sourceColumn && sourceColumn !== overId) {
        // Moving between columns
        const sourceItems = [...columns[sourceColumn].items];
        const destItems = [...columns[overId].items];
        
        const movedItemIndex = sourceItems.findIndex(item => 
          `${item.taskId}-${item.checklistIndex}` === activeId
        );
        
        if (movedItemIndex !== -1) {
          const [movedItem] = sourceItems.splice(movedItemIndex, 1);
          
          // Update the item's status
          const updatedItem = {
            ...movedItem,
            completed: overId === 'completed',
            rejected: overId === 'rejected'
          };

          destItems.push(updatedItem);

          setColumns(prev => ({
            ...prev,
            [sourceColumn]: {
              ...prev[sourceColumn],
              items: sourceItems
            },
            [overId]: {
              ...prev[overId],
              items: destItems
            }
          }));

          // Call the status update function with the new status
          if (onStatusUpdate) {
            try {
              // Pass the new status (completed, rejected, or pending)
              const newStatus = overId === 'completed' ? 'completed' : overId === 'rejected' ? 'rejected' : 'pending';
              await onStatusUpdate(movedItem, newStatus);
              toast.success(`Task moved to ${columns[overId].title}`);
            } catch (error) {
              toast.error("Failed to update task status");
              // Revert the change on error
              setColumns(prev => ({
                ...prev,
                [sourceColumn]: {
                  ...prev[sourceColumn],
                  items: [...prev[sourceColumn].items, movedItem]
                },
                [overId]: {
                  ...prev[overId],
                  items: prev[overId].items.filter(item => 
                    `${item.taskId}-${item.checklistIndex}` !== activeId
                  )
                }
              }));
            }
          }
        }
      }
    } else {
      // Reordering within the same column
      const [taskId, checklistIndex] = activeId.split('-');
      const parsedChecklistIndex = parseInt(checklistIndex);
      
      const sourceColumn = Object.keys(columns).find(key => 
        columns[key].items.some(item => 
          `${item.taskId}-${item.checklistIndex}` === activeId
        )
      );
      
      if (sourceColumn) {
        const column = columns[sourceColumn];
        const oldIndex = column.items.findIndex(item => 
          `${item.taskId}-${item.checklistIndex}` === activeId
        );
        const newIndex = column.items.findIndex(item => 
          `${item.taskId}-${item.checklistIndex}` === overId
        );

        if (oldIndex !== newIndex && newIndex !== -1) {
          const newItems = arrayMove(column.items, oldIndex, newIndex);
          setColumns(prev => ({
            ...prev,
            [sourceColumn]: {
              ...prev[sourceColumn],
              items: newItems
            }
          }));
        }
      }
    }
  };

  const startEditing = (item) => {
    setEditingItem(item);
    setDescriptionText(item.description || "");
  };

  const saveDescription = async () => {
    if (!editingItem || !descriptionText.trim()) return;

    try {
      if (onDescriptionUpdate) {
        await onDescriptionUpdate(editingItem, descriptionText.trim());
        toast.success("Description updated successfully!");
      }
      setEditingItem(null);
      setDescriptionText("");
    } catch (error) {
      toast.error("Failed to update description");
    }
  };

  const cancelEditing = () => {
    setEditingItem(null);
    setDescriptionText("");
  };

  return (
    <div className="w-full">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
          <LuTarget className="w-6 h-6 text-blue-600" />
          Manage My Projects
        </h2>
        <p className="text-gray-600">
          Drag and drop your tasks between different status columns. Click the edit icon to add descriptions.
        </p>
        
        {/* Helpful Instructions */}
        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <svg className="w-5 h-5 text-blue-600 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">How it works:</p>
              <ul className="space-y-1 text-blue-700">
                <li>• <strong>Drag to "Completed"</strong> → Automatically marks item as done with timestamp</li>
                <li>• <strong>Drag to "Rejected"</strong> → Marks item as rejected (for review)</li>
                <li>• <strong>Drag to "Pending"</strong> → Moves item back to pending status</li>
                <li>• <strong>Click edit icon</strong> → Add descriptions and notes to your work</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {Object.values(columns).map((column) => (
            <div key={column.id} className="space-y-4">
              {/* Column Header */}
              <div className={`${column.bgColor} ${column.borderColor} border-2 rounded-lg p-4`}>
                <div className="flex items-center justify-between">
                  <h3 className={`${column.color} text-white px-3 py-1 rounded-full text-sm font-semibold`}>
                    {column.title}
                  </h3>
                  <span className="text-gray-600 font-medium">
                    {column.items.length}
                  </span>
                </div>
              </div>

              {/* Droppable Area */}
              <DroppableColumn 
                column={column} 
                isDragOver={dragOverColumn === column.id}
              >
                <SortableContext
                  items={column.items.map(item => `${item.taskId}-${item.checklistIndex}`)}
                  strategy={verticalListSortingStrategy}
                >
                  {column.items.map((item) => (
                    <SortableItem
                      key={`${item.taskId}-${item.checklistIndex}`}
                      item={item}
                      columnId={column.id}
                      onEdit={startEditing}
                      editingItem={editingItem}
                      descriptionText={descriptionText}
                      setDescriptionText={setDescriptionText}
                      onSaveDescription={saveDescription}
                      onCancelEditing={cancelEditing}
                    />
                  ))}
                </SortableContext>
                
                {/* Empty state for columns */}
                {column.items.length === 0 && (
                  <div className="flex items-center justify-center h-32 text-gray-400">
                    <div className="text-center">
                      <LuTarget className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No tasks</p>
                    </div>
                  </div>
                )}
              </DroppableColumn>
            </div>
          ))}
        </div>

        {/* Drag Overlay */}
        <DragOverlay
          dropAnimation={{
            sideEffects: defaultDropAnimationSideEffects({
              styles: {
                active: {
                  opacity: '0.8',
                  transform: 'scale(1.05)',
                },
              },
            }),
          }}
        >
          {activeId && activeItem ? (
            <div className="bg-white rounded-lg border border-gray-200 p-4 shadow-2xl opacity-90 transform rotate-2">
              <div className="flex items-center gap-2 mb-2">
                <LuTarget className="w-4 h-4 text-blue-600" />
                <h4 className="font-medium text-gray-900 text-sm">{activeItem.text}</h4>
              </div>
              <p className="text-xs text-gray-500">{activeItem.taskTitle}</p>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>

      {/* Instructions */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-blue-800 mb-2">How to use:</h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Drag tasks between columns to change their status</li>
          <li>• Click the edit icon to add or modify task descriptions</li>
          <li>• Tasks automatically update their status when moved</li>
          <li>• Use the priority badges to identify urgent tasks</li>
        </ul>
      </div>
    </div>
  );
};

export default ChecklistItemManager;