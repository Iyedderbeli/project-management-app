import React, { useContext, useState } from "react";
import toast from "react-hot-toast";
import { LuCheck, LuMessageSquare, LuSend, LuUsers, LuX } from "react-icons/lu";
import { UserContext } from "../../context/userContext";
import { API_PATHS } from "../../utils/apiPaths";
import axiosInstance from "../../utils/axiosInstance";
import AvatarGroup from "../AvatarGroup";
import SelectUsers from "../Inputs/SelectUsers";

const TaskReviewModal = ({ isOpen, onClose, task, onTaskUpdated, onAssignUsers }) => {
  const { user } = useContext(UserContext);
  const [loading, setLoading] = useState(false);
  const [rejectFeedback, setRejectFeedback] = useState("");
  const [rejectingItemIndex, setRejectingItemIndex] = useState(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [assigningToItem, setAssigningToItem] = useState(null);
  const [selectedItemUsers, setSelectedItemUsers] = useState([]);
  const [localTask, setLocalTask] = useState(task);
  const [assignedUsersDetails, setAssignedUsersDetails] = useState({});
  
  // Messaging state
  const [showMessaging, setShowMessaging] = useState(false);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [messagingLoading, setMessagingLoading] = useState(false);
  const [adminUser, setAdminUser] = useState(null);
  const [completingItemIndex, setCompletingItemIndex] = useState(null);
  const [completionDescription, setCompletionDescription] = useState("");
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [selectedItemForRating, setSelectedItemForRating] = useState(null);
  const [rating, setRating] = useState(0);
  const [ratingFeedback, setRatingFeedback] = useState("");
  
  // Task rating state
  const [showTaskRatingModal, setShowTaskRatingModal] = useState(false);
  const [showUserRatingModal, setShowUserRatingModal] = useState(false);
  const [taskQualityRating, setTaskQualityRating] = useState(0);
  const [taskTimeRating, setTaskTimeRating] = useState(0);
  const [taskReviewNotes, setTaskReviewNotes] = useState("");

  // Update local task when prop changes
  React.useEffect(() => {
    console.log("TaskReviewModal: task prop changed:", task);
    setLocalTask(task);
  }, [task]);

  // Function to refresh task data from server
  const refreshTaskData = async () => {
    try {
      console.log("Fetching fresh task data for ID:", localTask._id);
      const response = await axiosInstance.get(API_PATHS.TASKS.GET_TASK_BY_ID(localTask._id));
      if (response.data) {
        console.log("Received fresh task data:", response.data);
        setLocalTask(response.data);
      }
    } catch (error) {
      console.error("Error refreshing task data:", error);
    }
  };

  // Fetch user details for assigned users
  const fetchAssignedUsersDetails = async (userIds) => {
    if (!userIds || userIds.length === 0) return;
    
    try {
      const userDetails = {};
      for (const userId of userIds) {
        try {
          const response = await axiosInstance.get(API_PATHS.USERS.GET_USER_BY_ID(userId));
          userDetails[userId] = response.data;
        } catch (error) {
          console.error(`Error fetching user ${userId}:`, error);
        }
      }
      setAssignedUsersDetails(prev => ({ ...prev, ...userDetails }));
    } catch (error) {
      console.error("Error fetching assigned users details:", error);
    }
  };

  // Check if all checklist items are approved
  const allItemsApproved = localTask?.todoCheckList?.every(item => item.approved) || false;
  const hasUnapprovedItems = localTask?.todoCheckList?.some(item => !item.approved && !item.rejected) || false;

  const handleApproveItem = async (itemIndex) => {
    if (!localTask) return;
    
    setLoading(true);
    try {
      await axiosInstance.put(API_PATHS.TASKS.APPROVE_TODO_ITEM(localTask._id, itemIndex));
      
      // Update local state immediately
      const updatedTask = { ...localTask };
      updatedTask.todoCheckList[itemIndex] = {
        ...updatedTask.todoCheckList[itemIndex],
        approved: true,
        approvedBy: localTask._id, // You might want to get the actual user ID
        approvedAt: new Date()
      };
      setLocalTask(updatedTask);
      
      toast.success("Checklist item approved successfully");
    } catch (error) {
      console.error("Error approving item:", error);
      toast.error("Failed to approve item");
    } finally {
      setLoading(false);
    }
  };

  const handleAssignUsersToItem = (itemIndex) => {
    setAssigningToItem(itemIndex);
    setSelectedItemUsers([]);
    setShowAssignModal(true);
  };

  const handleAssignUsersSubmit = async () => {
    if (selectedItemUsers.length === 0) {
      toast.error("Please select at least one user to assign to this checklist item");
      return;
    }

    try {
      setLoading(true);
      // Assign users to the specific checklist item
      await axiosInstance.put(API_PATHS.TASKS.ASSIGN_USERS_TO_CHECKLIST_ITEM(localTask._id, assigningToItem), {
        assignedUsers: selectedItemUsers
      });
      
      // Update local state immediately
      const updatedTask = { ...localTask };
      updatedTask.todoCheckList[assigningToItem] = {
        ...updatedTask.todoCheckList[assigningToItem],
        assignedUsers: selectedItemUsers
      };
      setLocalTask(updatedTask);
      
      // Fetch user details for the newly assigned users
      await fetchAssignedUsersDetails(selectedItemUsers);
      
      toast.success("Users assigned to checklist item successfully");
      setShowAssignModal(false);
      setAssigningToItem(null);
      setSelectedItemUsers([]);
    } catch (error) {
      console.error("Error assigning users:", error);
      toast.error("Failed to assign users to checklist item");
    } finally {
      setLoading(false);
    }
  };

  const handleRejectItem = async (itemIndex) => {
    if (!localTask || !rejectFeedback.trim()) {
      toast.error("Please provide rejection feedback");
      return;
    }
    
    setLoading(true);
    try {
      await axiosInstance.put(API_PATHS.TASKS.REJECT_TODO_ITEM(localTask._id, itemIndex), {
        feedback: rejectFeedback.trim()
      });
      
      // Update local state immediately
      const updatedTask = { ...localTask };
      updatedTask.todoCheckList[itemIndex] = {
        ...updatedTask.todoCheckList[itemIndex],
        rejected: true,
        rejectionFeedback: rejectFeedback.trim(),
        rejectedBy: localTask._id, // You might want to get the actual user ID
        rejectedAt: new Date()
      };
      setLocalTask(updatedTask);
      
      toast.success("Checklist item rejected successfully");
      setRejectingItemIndex(null);
      setRejectFeedback("");
    } catch (error) {
      console.error("Error rejecting item:", error);
      toast.error("Failed to reject item");
    } finally {
      setLoading(false);
    }
  };



  const handleAssignUsersToTask = () => {
    onClose();
    if (onAssignUsers) {
      onAssignUsers(localTask);
    }
  };

  // Get assigned users avatars for a specific item
  const getAssignedUsersAvatars = (item) => {
    if (!item.assignedUsers || item.assignedUsers.length === 0) return [];
    
    return item.assignedUsers.map(userId => {
      const userDetails = assignedUsersDetails[userId];
      return userDetails?.profileImageUrl || '/default-avatar.png'; // Fallback to default avatar
    });
  };

  // Fetch user details when modal opens or task changes
  React.useEffect(() => {
    if (localTask?.todoCheckList) {
      const allAssignedUserIds = localTask.todoCheckList
        .filter(item => item.assignedUsers && item.assignedUsers.length > 0)
        .flatMap(item => item.assignedUsers);
      
      // Also include users who completed items
      const completedUserIds = localTask.todoCheckList
        .filter(item => item.completedBy)
        .map(item => item.completedBy);
      
      const allUserIds = [...new Set([...allAssignedUserIds, ...completedUserIds])];
      
      if (allUserIds.length > 0) {
        fetchAssignedUsersDetails(allUserIds);
      }
    }
  }, [localTask]);

  // Messaging functions
  const handleStartMessaging = async () => {
    if (!localTask?.createdBy) {
      toast.error("No admin found for this task");
      return;
    }

    setShowMessaging(true);
    setMessagingLoading(true);
    
    try {
      // Fetch admin user details
      const adminResponse = await axiosInstance.get(API_PATHS.USERS.GET_USER_BY_ID(localTask.createdBy));
      setAdminUser(adminResponse.data);
      
      // Fetch messages between current user and admin
      const messagesResponse = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATION(localTask.createdBy));
      if (messagesResponse.data && Array.isArray(messagesResponse.data)) {
        setMessages(messagesResponse.data);
      }
    } catch (error) {
      console.error("Error fetching messaging data:", error);
      toast.error("Failed to load messages");
    } finally {
      setMessagingLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !localTask?.createdBy) return;

    try {
      setMessagingLoading(true);
      
      const response = await axiosInstance.post(API_PATHS.MESSAGES.SEND_MESSAGE, {
        toUserId: localTask.createdBy,
        message: newMessage.trim(),
        taskId: localTask._id
      });

      if (response.data) {
        setMessages(prev => [...prev, response.data]);
        setNewMessage("");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    } finally {
      setMessagingLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleCompleteItem = async (itemIndex) => {
    if (!completionDescription.trim()) {
      toast.error("Please provide a description when completing the item");
      return;
    }

    try {
      setLoading(true);
      
      const response = await axiosInstance.put(
        API_PATHS.TASKS.COMPLETE_CHECKLIST_ITEM(localTask._id, itemIndex),
        {
          description: completionDescription.trim()
        }
      );

      if (response.data) {
        setLocalTask(response.data.task);
        setCompletingItemIndex(null);
        setCompletionDescription("");
        toast.success("Checklist item completed successfully!");
        if (onTaskUpdated) {
          onTaskUpdated();
        }
      }
    } catch (error) {
      console.error("Error completing checklist item:", error);
      toast.error(error.response?.data?.message || "Failed to complete checklist item");
    } finally {
      setLoading(false);
    }
  };

  const handleRateUser = (itemIndex) => {
    if (!localTask) return;
    
    const item = localTask.todoCheckList[itemIndex];
    if (!item.completed || !item.completedBy) {
      toast.error("Cannot rate an item that hasn't been completed by a user");
      return;
    }
    
    setSelectedItemForRating(itemIndex);
    setRating(0);
    setRatingFeedback("");
    setShowRatingModal(true);
  };

  const handleRatingSubmit = async () => {
    if (rating === 0) {
      toast.error("Please select a rating");
      return;
    }

    if (!ratingFeedback.trim()) {
      toast.error("Please provide feedback");
      return;
    }

    try {
      setLoading(true);
      const item = localTask.todoCheckList[selectedItemForRating];
      
      const response = await axiosInstance.put(
        API_PATHS.TASKS.RATE_USER_PERFORMANCE(localTask._id, selectedItemForRating),
        {
          userId: item.completedBy,
          rating: rating,
          feedback: ratingFeedback.trim()
        }
      );
      
      // Update local task state immediately with the response data
      if (response.data.task) {
        console.log("Updating local task with response:", response.data.task);
        setLocalTask(response.data.task);
      }
      
      toast.success("User performance rated successfully");
      setShowRatingModal(false);
      setSelectedItemForRating(null);
      setRating(0);
      setRatingFeedback("");
      
      // Refresh task data from server to ensure we have the latest data
      console.log("Refreshing task data from server...");
      await refreshTaskData();
      
      // Refresh assigned users details to show updated ratings
      if (localTask?.todoCheckList?.[selectedItemForRating]?.assignedUsers) {
        console.log("Refreshing assigned users details...");
        await fetchAssignedUsersDetails(localTask.todoCheckList[selectedItemForRating].assignedUsers);
      }
      
      // Refresh task data in parent component
      if (onTaskUpdated) {
        console.log("Calling onTaskUpdated callback...");
        onTaskUpdated();
      }
    } catch (error) {
      console.error("Error rating user performance:", error);
      toast.error(error.response?.data?.message || "Failed to rate user performance");
    } finally {
      setLoading(false);
    }
  };

  // Handle task rating submission
  const handleTaskRatingSubmit = async () => {
    if (taskQualityRating === 0 || taskTimeRating === 0) {
      toast.error("Please provide both quality and time ratings");
      return;
    }

    if (!taskReviewNotes.trim()) {
      toast.error("Please provide review notes");
      return;
    }

    try {
      setLoading(true);
      
      const response = await axiosInstance.put(
        API_PATHS.TASKS.RATE_TASK(localTask._id),
        {
          qualityRating: taskQualityRating,
          timeRating: taskTimeRating,
          reviewNotes: taskReviewNotes.trim()
        }
      );
      
      // Update local task state immediately with the response data
      if (response.data.task) {
        setLocalTask(response.data.task);
      }
      
      toast.success("Task rated successfully");
      setShowTaskRatingModal(false);
      setTaskQualityRating(0);
      setTaskTimeRating(0);
      setTaskReviewNotes("");
      
      // Refresh task data from server to ensure we have the latest data
      await refreshTaskData();
      
      // Refresh task data in parent component
      if (onTaskUpdated) {
        onTaskUpdated();
      }
    } catch (error) {
      console.error("Error rating task:", error);
      toast.error(error.response?.data?.message || "Failed to rate task");
    } finally {
      setLoading(false);
    }
  };

  // Debug: Log current localTask state
  console.log("TaskReviewModal render - localTask:", localTask);
  
  return (
    <>
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50"
           style={{ display: isOpen ? 'flex' : 'none' }}>
        <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-4xl max-h-[90vh] overflow-y-auto mx-4">
          <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
            <div className="flex items-center gap-3">
              <h3 className="text-xl font-semibold text-gray-900 lg:text-2xl">
                Task Review
              </h3>
              {/* Completion Status Badge */}
              {localTask?.status === "Completed" && (
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 border border-green-300 rounded-full">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs font-semibold text-green-800">Ready for Rating</span>
                </div>
              )}
            </div>
            <button onClick={onClose} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
            </button>
          </div>
          <div className="p-6 bg-white">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {localTask?.title}
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                {localTask?.description}
              </p>
              
              {/* Task Completion Status Banner - Show prominently when task is completed */}
              {localTask?.status === "Completed" && (
                <div className="mb-6 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <svg className="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-green-800 mb-1">🎉 Task Successfully Completed!</h3>
                      <p className="text-sm text-green-700">
                        All checklist items have been completed. As a Domain Manager, you can now evaluate the task quality and rate user performance.
                      </p>
                    </div>
                  </div>
                  
                  {/* Completion Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="text-center p-3 bg-white rounded-lg border border-green-200">
                      <div className="text-2xl font-bold text-green-600">
                        {localTask?.todoCheckList?.filter(item => item.completed).length || 0}
                      </div>
                      <div className="text-xs text-green-700">Items Completed</div>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg border border-green-200">
                      <div className="text-2xl font-bold text-blue-600">
                        {localTask?.todoCheckList?.filter(item => item.completed && item.completedBy).length || 0}
                      </div>
                      <div className="text-xs text-blue-700">Users to Rate</div>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg border border-green-200">
                      <div className="text-2xl font-bold text-purple-600">
                        {localTask?.todoCheckList?.filter(item => item.userRatings && item.userRatings.length > 0).length || 0}
                      </div>
                      <div className="text-xs text-purple-700">Already Rated</div>
                    </div>
                  </div>
                  
                  {/* Rating Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => setShowTaskRatingModal(true)}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span className="font-semibold">Rate Task Quality</span>
                    </button>
                    <button
                      onClick={() => setShowUserRatingModal(true)}
                      className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                      </svg>
                      <span className="font-semibold">Rate User Performance</span>
                    </button>
                  </div>
                  
                  {/* Quick Rating Info */}
                  <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                      <div className="text-xs text-blue-800">
                        <p className="font-medium mb-1">Rating Guidelines:</p>
                        <ul className="space-y-1 text-blue-700">
                          <li>• <strong>Task Quality:</strong> Evaluate overall task completion quality and standards</li>
                          <li>• <strong>User Performance:</strong> Rate individual users on their completed checklist items</li>
                          <li>• <strong>Feedback Required:</strong> Provide constructive feedback for improvement</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Checklist Items Review */}
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">
                  Review Checklist Items
                </h2>
                <p className="text-sm text-gray-600 mb-4">
                  Review and approve/reject individual checklist items for this task
                </p>
                <div className="space-y-3">
                  {localTask?.todoCheckList?.map((item, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border ${
                        item.approved
                          ? "bg-green-50 border-green-200"
                          : item.rejected
                          ? "bg-red-50 border-red-200"
                          : "bg-yellow-50 border-yellow-200"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {item.approved ? (
                            <LuCheck className="w-4 h-4 text-green-500" />
                          ) : item.rejected ? (
                            <LuX className="w-4 h-4 text-red-500" />
                          ) : (
                            <div className="w-4 h-4 border-2 border-yellow-400 rounded-full" />
                          )}
                          <span className={`text-sm font-medium ${
                            item.approved ? "text-green-800" :
                            item.rejected ? "text-red-800" :
                            "text-yellow-800"
                          }`}>
                            {item.text}
                          </span>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded ${
                          item.approved
                            ? "bg-green-100 text-green-800"
                            : item.rejected
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}>
                          {item.approved ? "Approved" : item.rejected ? "Rejected" : "Pending"}
                        </span>
                      </div>

                      {/* Show assigned users with avatars */}
                      {item.assignedUsers && item.assignedUsers.length > 0 && (
                        <div className="mb-3 p-3 bg-blue-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-blue-800">
                              Assigned Users ({item.assignedUsers.length})
                            </span>
                          </div>
                          <div className="flex items-center gap-3">
                            <AvatarGroup 
                              avatars={getAssignedUsersAvatars(item)} 
                              maxVisible={5}
                            />
                            <div className="flex flex-wrap gap-1">
                              {item.assignedUsers.map((userId, userIndex) => {
                                const userDetails = assignedUsersDetails[userId];
                                return (
                                  <span 
                                    key={userId}
                                    className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full"
                                  >
                                    {userDetails?.name || `User ${userIndex + 1}`}
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Show rejection feedback if item is rejected */}
                      {item.rejected && item.rejectionFeedback && (
                        <div className="mb-3 p-2 bg-red-100 rounded text-sm text-red-800">
                          <strong>Rejection Feedback:</strong> {item.rejectionFeedback}
                        </div>
                      )}

                      {/* Show completion information if item is completed */}
                      {item.completed && (
                        <div className="mb-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <LuCheck className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-semibold text-green-800">Completed</span>
                          </div>
                          {item.description && (
                            <div className="mb-2">
                              <span className="text-xs font-medium text-green-700">Description:</span>
                              <p className="text-sm text-green-800 mt-1">{item.description}</p>
                            </div>
                          )}
                          {item.completedBy && (
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-medium text-green-700">Completed by:</span>
                              <div className="flex items-center gap-2">
                                {/* User Avatar */}
                                <div className="w-6 h-6 rounded-full overflow-hidden bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center">
                                  {assignedUsersDetails[item.completedBy]?.profileImageUrl ? (
                                    <img
                                      src={assignedUsersDetails[item.completedBy].profileImageUrl}
                                      alt={assignedUsersDetails[item.completedBy]?.name || "User"}
                                      className="w-6 h-6 object-cover"
                                    />
                                  ) : (
                                    <span className="text-xs text-white font-semibold">
                                      {assignedUsersDetails[item.completedBy]?.name?.charAt(0)?.toUpperCase() || "U"}
                                    </span>
                                  )}
                                </div>
                                {/* User Name */}
                                <span className="text-sm text-green-800 font-medium">
                                  {assignedUsersDetails[item.completedBy]?.name || "Unknown User"}
                                </span>
                                {/* Completion Time */}
                                {item.completedAt && (
                                  <span className="text-xs text-green-600">
                                    on {new Date(item.completedAt).toLocaleDateString()} at {new Date(item.completedAt).toLocaleTimeString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                          
                          {/* Show rating under user name if domain manager has rated */}
                          {user?.role === "domain_manager" && item.completedBy && (() => {
                            const domainManagerRating = item.userRatings?.find(rating => rating.ratedBy === user._id);
                            const hasRated = domainManagerRating !== undefined;
                            
                            return hasRated ? (
                              <div className="mt-2 ml-9">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-medium text-purple-700">Rating:</span>
                                  <div className="flex items-center gap-1">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                      <svg
                                        key={star}
                                        className={`w-3 h-3 ${star <= domainManagerRating.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                      >
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                      </svg>
                                    ))}
                                    <span className="text-purple-700 font-medium text-xs">{domainManagerRating.rating}/5</span>
                                  </div>
                                </div>
                                {domainManagerRating.feedback && (
                                  <div className="mt-1 ml-9">
                                    <span className="text-xs text-purple-700 italic">
                                      "{domainManagerRating.feedback}"
                                    </span>
                                  </div>
                                )}
                              </div>
                            ) : null;
                          })()}
                          
                          {/* Enhanced Rating Section for Domain Managers */}
                          {user?.role === "domain_manager" && item.completedBy && (() => {
                            const domainManagerRating = item.userRatings?.find(rating => rating.ratedBy === user._id);
                            const hasRated = domainManagerRating !== undefined;
                            
                            return !hasRated ? (
                              <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center">
                                    <svg className="w-3 h-3 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                  </div>
                                  <span className="text-sm font-semibold text-purple-800">Rate User Performance</span>
                                </div>
                                <p className="text-xs text-purple-700 mb-3">
                                  This item was completed by <strong>{assignedUsersDetails[item.completedBy]?.name || "Unknown User"}</strong>. 
                                  Please rate their performance and provide feedback.
                                </p>
                                <button
                                  onClick={() => handleRateUser(index)}
                                  disabled={loading}
                                  className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg text-sm hover:bg-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                                >
                                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                  </svg>
                                  <span className="font-medium">Rate Performance</span>
                                </button>
                              </div>
                            ) : (
                              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                                    <svg className="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                  </div>
                                  <span className="text-sm font-semibold text-green-800">Performance Rated</span>
                                </div>
                                <div className="flex items-center gap-2 text-xs text-green-700">
                                  <span className="font-medium">Rating:</span>
                                  <div className="flex items-center gap-1">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                      <svg
                                        key={star}
                                        className={`w-3 h-3 ${star <= domainManagerRating.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                      >
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                      </svg>
                                    ))}
                                    <span className="font-semibold">{domainManagerRating.rating}/5</span>
                                  </div>
                                </div>
                                {domainManagerRating.feedback && (
                                  <div className="mt-2 text-xs text-green-700">
                                    <span className="font-medium">Feedback:</span>
                                    <p className="mt-1 italic">"{domainManagerRating.feedback}"</p>
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      )}

                      {/* Action buttons for pending items */}
                      {!item.approved && !item.rejected && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleApproveItem(index)}
                            disabled={loading}
                            className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-sm hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                          >
                            <LuCheck className="w-3 h-3" />
                            Approve
                          </button>
                          <button
                            onClick={() => setRejectingItemIndex(index)}
                            disabled={loading}
                            className="flex-1 bg-red-600 text-white py-2 px-3 rounded text-sm hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                          >
                            <LuX className="w-3 h-3" />
                            Reject
                          </button>
                        </div>
                      )}

                      {/* Completion functionality for approved items (for assigned users) */}
                      {item.approved && !item.completed && user?.role !== "domain_manager" && (
                        <div className="mt-3">
                          {completingItemIndex === index ? (
                            <div className="space-y-3">
                              <textarea
                                value={completionDescription}
                                onChange={(e) => setCompletionDescription(e.target.value)}
                                placeholder="Describe what you accomplished..."
                                className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows="3"
                              />
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleCompleteItem(index)}
                                  disabled={loading || !completionDescription.trim()}
                                  className="flex-1 bg-blue-600 text-white py-2 px-3 rounded text-sm hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                                >
                                  <LuCheck className="w-3 h-3" />
                                  Complete Item
                                </button>
                                <button
                                  onClick={() => {
                                    setCompletingItemIndex(null);
                                    setCompletionDescription("");
                                  }}
                                  disabled={loading}
                                  className="flex-1 bg-gray-500 text-white py-2 px-3 rounded text-sm hover:bg-gray-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              onClick={() => setCompletingItemIndex(index)}
                              className="w-full bg-blue-600 text-white py-2 px-3 rounded text-sm hover:bg-blue-700 transition-colors flex items-center justify-center gap-1"
                            >
                              <LuCheck className="w-3 h-3" />
                              Complete This Item
                            </button>
                          )}
                        </div>
                      )}



                      {/* Assign Users button for approved items (only if not completed) */}
                      {item.approved && !item.completed && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleAssignUsersToItem(index)}
                            disabled={loading}
                            className="flex-1 bg-blue-600 text-white py-2 px-3 rounded text-sm hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                          >
                            <LuUsers className="w-3 h-3" />
                            Assign Users
                          </button>
                        </div>
                      )}

                      {/* Rejection feedback input */}
                      {rejectingItemIndex === index && (
                        <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded">
                          <textarea
                            value={rejectFeedback}
                            onChange={(e) => setRejectFeedback(e.target.value)}
                            placeholder="Provide rejection feedback..."
                            className="w-full p-2 border border-red-300 rounded text-sm resize-none"
                            rows="3"
                          />
                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => handleRejectItem(index)}
                              disabled={loading || !rejectFeedback.trim()}
                              className="bg-red-600 text-white py-1 px-3 rounded text-sm hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              Submit Rejection
                            </button>
                            <button
                              onClick={() => {
                                setRejectingItemIndex(null);
                                setRejectFeedback("");
                              }}
                              className="bg-gray-500 text-white py-1 px-3 rounded text-sm hover:bg-gray-600 transition-colors"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                {/* Message Admin Button - Always visible for domain managers */}
                {user?.role === "domain_manager" && localTask?.createdBy && (
                  <div className="flex gap-3">
                    <button
                      onClick={handleStartMessaging}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <LuMessageSquare className="w-4 h-4" />
                      Message Admin
                    </button>
                  </div>
                )}
                
                {allItemsApproved && (
                  <div className="flex gap-3">

                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Messaging Interface Modal */}
      {showMessaging && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50">
          <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-2xl max-h-[80vh] overflow-y-auto mx-4">
            <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowMessaging(false)}
                  className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-all duration-200"
                >
                  <LuX className="w-5 h-5" />
                </button>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Message Admin
                  </h3>
                  <p className="text-sm text-gray-600">
                    {adminUser?.name || "Admin"} • {localTask?.title}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="p-6 bg-white">
              {messagingLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                </div>
              ) : (
                <>
                  {/* Messages */}
                  <div className="h-64 overflow-y-auto p-4 space-y-4 bg-gray-50 rounded-lg mb-4">
                    {messages.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <LuMessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                        <p className="text-sm">No messages yet</p>
                        <p className="text-xs mt-1">Start the conversation!</p>
                      </div>
                    ) : (
                      messages.map((message) => (
                        <div
                          key={message._id}
                          className={`flex ${message.fromUser._id === user._id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-sm ${
                              message.fromUser._id === user._id
                                ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white'
                                : 'bg-white text-gray-800 border border-gray-200'
                            }`}
                          >
                            <p className="text-sm leading-relaxed">{message.message}</p>
                            <p className={`text-xs mt-2 ${message.fromUser._id === user._id ? 'text-blue-100' : 'text-gray-500'}`}>
                              {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Message Input */}
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Type your message..."
                      className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-700 placeholder-gray-400"
                      disabled={messagingLoading}
                    />
                    <button
                      onClick={sendMessage}
                      disabled={!newMessage.trim() || messagingLoading}
                      className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl hover:from-blue-600 hover:to-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
                    >
                      <LuSend className="w-4 h-4" />
                      <span className="text-sm font-medium">Send</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Assign Users to Checklist Item Modal */}
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50"
           style={{ display: showAssignModal ? 'flex' : 'none' }}>
        <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-md max-h-[90vh] overflow-y-auto mx-4">
          <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
            <h3 className="text-xl font-semibold text-gray-900 lg:text-2xl">
              Assign Users to Checklist Item
            </h3>
            <button onClick={() => setShowAssignModal(false)} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
            </button>
          </div>
          <div className="p-6 bg-white">
            <div className="mb-4">
              <h4 className="font-medium text-gray-900 mb-2">
                {localTask?.todoCheckList?.[assigningToItem]?.text}
              </h4>
              <p className="text-sm text-gray-600">
                Select users to assign to this approved checklist item based on their skills.
              </p>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Assign Users to This Checklist Item</label>
              <SelectUsers
                selectedUsers={selectedItemUsers}
                setSelectedUsers={setSelectedItemUsers}
                showSkills={true}
                requiredSkills={localTask?.todoCheckList?.[assigningToItem]?.requiredSkills || []}
                taskId={localTask?._id}
                todoIndex={assigningToItem}
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleAssignUsersSubmit}
                disabled={loading || selectedItemUsers.length === 0}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <LuUsers className="w-4 h-4" />
                Assign Users
              </button>
              <button
                onClick={() => setShowAssignModal(false)}
                className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Rating Modal */}
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50"
           style={{ display: showRatingModal ? 'flex' : 'none' }}>
        <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-md max-h-[90vh] overflow-y-auto mx-4">
          <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
            <h3 className="text-xl font-semibold text-gray-900 lg:text-2xl">
              Rate User Performance
            </h3>
            <button onClick={() => setShowRatingModal(false)} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
            </button>
          </div>
          <div className="p-6 bg-white">
            <div className="mb-4">
              <h4 className="font-medium text-gray-900 mb-2">
                {localTask?.todoCheckList?.[selectedItemForRating]?.text}
              </h4>
              <p className="text-sm text-gray-600">
                Rate the performance of the user who completed this checklist item.
              </p>
            </div>
            
            {/* Rating Stars */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className={`text-2xl transition-colors ${
                      star <= rating
                        ? 'text-yellow-400'
                        : 'text-gray-300 hover:text-yellow-300'
                    }`}
                  >
                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {rating === 0 && "Click on a star to rate"}
                {rating === 1 && "Poor"}
                {rating === 2 && "Fair"}
                {rating === 3 && "Good"}
                {rating === 4 && "Very Good"}
                {rating === 5 && "Excellent"}
              </p>
            </div>
            
            {/* Feedback Textarea */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Feedback</label>
              <textarea
                value={ratingFeedback}
                onChange={(e) => setRatingFeedback(e.target.value)}
                placeholder="Provide detailed feedback about the user's performance..."
                className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                rows="4"
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleRatingSubmit}
                disabled={loading || rating === 0 || !ratingFeedback.trim()}
                className="flex-1 bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                Submit Rating
              </button>
              <button
                onClick={() => setShowRatingModal(false)}
                className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Task Rating Modal */}
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50"
           style={{ display: showTaskRatingModal ? 'flex' : 'none' }}>
        <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-md max-h-[90vh] overflow-y-auto mx-4">
          <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
            <h3 className="text-xl font-semibold text-gray-900 lg:text-2xl">
              Rate Task Quality
            </h3>
            <button onClick={() => setShowTaskRatingModal(false)} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
            </button>
          </div>
          <div className="p-6 bg-white">
            <div className="mb-4">
              <h4 className="font-medium text-gray-900 mb-2">
                {localTask?.title}
              </h4>
              <p className="text-sm text-gray-600">
                Rate the overall quality and time management of this completed task.
              </p>
            </div>
            
            {/* Quality Rating Stars */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Quality Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setTaskQualityRating(star)}
                    className={`text-2xl transition-colors ${
                      star <= taskQualityRating
                        ? 'text-yellow-400'
                        : 'text-gray-300 hover:text-yellow-300'
                    }`}
                  >
                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {taskQualityRating === 0 && "Click on a star to rate quality"}
                {taskQualityRating === 1 && "Poor Quality"}
                {taskQualityRating === 2 && "Fair Quality"}
                {taskQualityRating === 3 && "Good Quality"}
                {taskQualityRating === 4 && "Very Good Quality"}
                {taskQualityRating === 5 && "Excellent Quality"}
              </p>
            </div>

            {/* Time Rating Stars */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Time Management Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setTaskTimeRating(star)}
                    className={`text-2xl transition-colors ${
                      star <= taskTimeRating
                        ? 'text-yellow-400'
                        : 'text-gray-300 hover:text-yellow-300'
                    }`}
                  >
                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {taskTimeRating === 0 && "Click on a star to rate time management"}
                {taskTimeRating === 1 && "Poor Time Management"}
                {taskTimeRating === 2 && "Fair Time Management"}
                {taskTimeRating === 3 && "Good Time Management"}
                {taskTimeRating === 4 && "Very Good Time Management"}
                {taskTimeRating === 5 && "Excellent Time Management"}
              </p>
            </div>
            
            {/* Review Notes Textarea */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Review Notes</label>
              <textarea
                value={taskReviewNotes}
                onChange={(e) => setTaskReviewNotes(e.target.value)}
                placeholder="Provide detailed review notes about the task quality and time management..."
                className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                rows="4"
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleTaskRatingSubmit}
                disabled={loading || taskQualityRating === 0 || taskTimeRating === 0 || !taskReviewNotes.trim()}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                Submit Task Rating
              </button>
              <button
                onClick={() => setShowTaskRatingModal(false)}
                className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* User Rating Modal */}
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center z-50"
           style={{ display: showUserRatingModal ? 'flex' : 'none' }}>
        <div className="relative bg-white rounded-lg shadow-2xl border border-gray-200 w-full max-w-md max-h-[90vh] overflow-y-auto mx-4">
          <div className="flex justify-between items-start p-6 border-b border-gray-200 bg-white rounded-t-lg">
            <h3 className="text-xl font-semibold text-gray-900 lg:text-2xl">
              Rate User Performance
            </h3>
            <button onClick={() => setShowUserRatingModal(false)} className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
            </button>
          </div>
          <div className="p-6 bg-white">
            <div className="mb-4">
              <h4 className="font-medium text-gray-900 mb-2">
                {localTask?.title}
              </h4>
              <p className="text-sm text-gray-600">
                Select a completed checklist item to rate the user's performance.
              </p>
            </div>
            
            {/* List of completed items for rating */}
            <div className="mb-4 space-y-2">
              {localTask?.todoCheckList?.map((item, index) => (
                item.completed && item.completedBy ? (
                  <div key={index} className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">{item.text}</p>
                        <p className="text-sm text-gray-600">Completed by: {assignedUsersDetails[item.completedBy]?.name || 'Unknown User'}</p>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedItemForRating(index);
                          setRating(0);
                          setRatingFeedback("");
                          setShowUserRatingModal(false);
                          setShowRatingModal(true);
                        }}
                        className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors"
                      >
                        Rate
                      </button>
                    </div>
                  </div>
                ) : null
              ))}
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={() => setShowUserRatingModal(false)}
                className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TaskReviewModal; 