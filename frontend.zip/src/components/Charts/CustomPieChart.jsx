import React from 'react';
import {
    Cell,
    Legend,
    Pie,
    PieChart,
    ResponsiveContainer,
    Tooltip,
} from 'recharts';
import CustomLegend from './CustomLegend';
import CustomToolTip from './CustomToolTip';

const CustomPieChart = ({data,colors}) => {
  // Ensure data is an array and has content
  const chartData = Array.isArray(data) ? data : [];
  
  return (
    <ResponsiveContainer width="100%" height={325}>
      <PieChart>
        <Pie
          data={chartData}
          dataKey="count"
          nameKey="status"
          cx="50%"
          cy="50%"
          outerRadius={130}
          innerRadius={100}
          labelLine={false}
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
          ))}
        </Pie>
        <Tooltip content={<CustomToolTip />} />
        <Legend content={<CustomLegend />} iconType="circle" />
      </PieChart>
    </ResponsiveContainer>
  );
}

export default CustomPieChart