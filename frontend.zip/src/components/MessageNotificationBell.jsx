import React, { useContext, useEffect, useState } from 'react';
import { LuMessageSquare } from 'react-icons/lu';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/userContext';
import { API_PATHS } from '../utils/apiPaths';
import axiosInstance from '../utils/axiosInstance';

const MessageNotificationBell = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    fetchUnreadCount();
    // Poll for new messages every 10 seconds for better responsiveness
    const interval = setInterval(fetchUnreadCount, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchUnreadCount = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_UNREAD_COUNT);
      setUnreadCount(response.data.unreadCount);
    } catch (error) {
      console.error('Error fetching unread count:', error);
    }
  };

  const handleClick = () => {
    if (user?.role === "admin") {
      navigate("/admin/messages");
    } else if (user?.role === "domain_manager") {
      navigate("/domain-manager/messages");
    } else {
      navigate("/user/messages");
    }
  };

  return (
    <>
      <div className="relative">
        <div className="flex items-center gap-1">
          <button
            onClick={handleClick}
            className="relative p-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <LuMessageSquare className="w-6 h-6" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

        </div>
      </div>


    </>
  );
};

export default MessageNotificationBell; 