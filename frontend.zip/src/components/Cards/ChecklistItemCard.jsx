import moment from "moment";
import React from "react";
import { LuBell, LuCalendar, LuCheck, LuClock, LuTarget, LuUsers, LuX } from "react-icons/lu";

const ChecklistItemCard = ({ item, onComplete, onViewDetails, onProjectClick }) => {
  const getStatusIcon = () => {
    if (item.completed) {
      return <LuCheck className="w-5 h-5 text-green-600" />;
    } else if (item.rejected) {
      return <LuX className="w-5 h-5 text-red-600" />;
    } else if (item.isOverdue) {
      return <LuBell className="w-5 h-5 text-red-600" />;
    } else {
      return <LuClock className="w-5 h-5 text-blue-600" />;
    }
  };

  const getStatusColor = () => {
    if (item.completed) {
      return "bg-green-100 text-green-800 border-green-200";
    } else if (item.rejected) {
      return "bg-red-100 text-red-800 border-red-200";
    } else if (item.isOverdue) {
      return "bg-red-100 text-red-800 border-red-200";
    } else {
      return "bg-blue-100 text-blue-800 border-blue-200";
    }
  };

  const getPriorityColor = () => {
    switch (item.taskPriority) {
      case "High":
        return "bg-red-100 text-red-800 border-red-200";
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusText = () => {
    if (item.completed) {
      return "Completed";
    } else if (item.rejected) {
      return "Rejected";
    } else if (item.isOverdue) {
      return "Overdue";
    } else {
      return "Pending";
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {getStatusIcon()}
          <div>
            <h4 className="font-medium text-gray-900 text-sm">{item.text}</h4>
            {onProjectClick ? (
              <p 
                className="text-xs text-blue-600 hover:text-blue-800 cursor-pointer hover:underline transition-colors font-medium"
                onClick={onProjectClick}
                title="Click to manage all tasks for this project"
              >
                {item.taskTitle}
              </p>
            ) : (
              <p className="text-xs text-gray-500">{item.taskTitle}</p>
            )}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor()}`}>
            {getStatusText()}
          </span>
          <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full border ${getPriorityColor()}`}>
            {item.taskPriority}
          </span>
        </div>
      </div>

      {/* Description */}
      {item.description && (
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{item.description}</p>
      )}

      {/* Task Info */}
      <div className="grid grid-cols-2 gap-3 mb-3">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <LuCalendar className="w-4 h-4" />
          <span>Due: {moment(item.taskDueDate).format("MMM DD, YYYY")}</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <LuTarget className="w-4 h-4" />
          <span>Task: {item.taskStatus}</span>
        </div>
      </div>

      {/* Domain Managers */}
      {item.domainManagers && item.domainManagers.length > 0 && (
        <div className="flex items-center gap-2 mb-3">
          <LuUsers className="w-4 h-4 text-gray-400" />
          <div className="flex flex-wrap gap-1">
            {item.domainManagers.map((dm, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full"
              >
                {dm.name}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Rejection Feedback */}
      {item.rejected && item.rejectionFeedback && (
        <div className="mb-3 p-2 bg-red-50 border border-red-200 rounded-md">
          <p className="text-xs text-red-700 font-medium mb-1">Rejection Feedback:</p>
          <p className="text-xs text-red-600">{item.rejectionFeedback}</p>
        </div>
      )}

      {/* Completion Info */}
      {item.completed && item.completedAt && (
        <div className="mb-3 p-2 bg-green-50 border border-green-200 rounded-md">
          <p className="text-xs text-green-700 font-medium mb-1">Completed:</p>
          <p className="text-xs text-green-600">{moment(item.completedAt).format("MMM DD, YYYY HH:mm")}</p>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
        <button
          onClick={() => onViewDetails(item)}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium"
        >
          View Details
        </button>
        
        {!item.completed && !item.rejected && (
          <button
            onClick={() => onComplete(item)}
            className="px-3 py-1.5 bg-green-600 text-white text-xs rounded-md hover:bg-green-700 transition-colors"
          >
            Mark Complete
          </button>
        )}
      </div>
    </div>
  );
};

export default ChecklistItemCard;
