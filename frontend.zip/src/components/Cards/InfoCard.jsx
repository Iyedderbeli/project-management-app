const InfoCard = ({ icon, label, value, color }) => {
  return (
    <div className={`${color} rounded-lg p-4 text-white`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-white/80 mb-1">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
        {icon && (
          <div className="p-2 bg-white/20 rounded-lg">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};

export default InfoCard;
