import moment from "moment";
import React from "react";
import { LuMessageSquare, LuPaperclip, LuStar, LuUserCheck, LuUsers } from "react-icons/lu";
import AvatarGroup from "../AvatarGroup";

const TaskCard = ({
  title,
  description,
  priority,
  status,
  progress,
  createdAt,
  dueDate,
  assignedTo,
  attachmentCount,
  completedTodoCount,
  todoCheckList,
  onClick,
  showActions = false,
  userRole = null,
  onApproveTodo = null,
  onRateTask = null,
  onAssignUsers = null,
  onRejectTodo = null,
  onAssignDomainManagers = null,
  onStartConversation = null,
  task = null,
}) => {
  const getStatusTagColor = () => {
    switch (status) {
      case "In Progress":
        return "text-cyan-500 bg-cyan-50 border border-cyan-500/10";
      case "Completed":
        return "text-lime-500 bg-lime-50 border border-lime-500/20";
      case "Rejected":
        return "text-red-500 bg-red-50 border border-red-500/20";
      case "Ready for Assignment":
        return "text-gray-500 bg-gray-50 border border-gray-500/20";
      default:
        return "text-violet-500 bg-violet-50 border border-violet-500/10";
    }
  };

  const getPriorityTagColor = () => {
    switch (priority) {
      case "Low":
        return "text-emerald-500 bg-emerald-50 border border-emerald-500/10";
      case "Medium":
        return "text-amber-500 bg-amber-50 border border-amber-500/10";
      default:
        return "text-rose-500 bg-rose-50 border border-rose-500/10";
    }
    
  };

  return (
    <div
      className="bg-white rounded-xl py-4 shadow-md shadow-gray-100 border border-gray-200/50 cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-end gap-3 px-4">
        <div
          className={`text-[11px] font-medium ${getStatusTagColor()} px-4 py-0.5 rounded`}
        >
          {status}
        </div>
        <div
          className={`text-[11px] font-medium ${getPriorityTagColor()} px-4 py-0.5 rounded`}
        >
          {priority} Priority
        </div>
      </div>
      <div
        className={`px-4 border-l-[3px] ${
          status === "In Progress"
            ? "border-cyan-500"
            : status === "Completed"
            ? "border-indigo-500"
            : status === "Rejected"
            ? "border-red-500"
            : status === "Ready for Assignment"
            ? "border-gray-500"
            : "border-violet-500"
        }`}
      >
        <p className="text-sm font-medium text-gray-800 mt-4 line-clamp-2">
          {title}
        </p>
        <p className="text-xs text-gray-500 mt-1.5 line-clamp-2 leading-[18px]">
          {description}
        </p>
        <p className="text-[13px] text-gray-700/80 font-medium mt-2 mb-2 leading-[18px] ">
          Task Done:{" "}
          <span className="font-semibold text-gray-700">
            {completedTodoCount}/{todoCheckList.length || 0}
          </span>
        </p>
        
       
        {/* Progress Bar with Real-time Calculation */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
            <div className="flex items-center gap-1">
              <span className="font-medium">Progress</span>
              <div className="relative group">
                <svg className="w-3 h-3 text-gray-400 cursor-help" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 3 3 0 100-6zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                </svg>
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs text-white bg-gray-800 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                  Progress updates automatically when you complete checklist items
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-800"></div>
                </div>
              </div>
            </div>
            <span className={`font-semibold ${
              (completedTodoCount / (todoCheckList.length || 1)) * 100 === 100 
                ? 'text-green-600' 
                : (completedTodoCount / (todoCheckList.length || 1)) * 100 > 50 
                ? 'text-blue-600' 
                : 'text-orange-600'
            }`}>
              {Math.round((completedTodoCount / (todoCheckList.length || 1)) * 100)}%
            </span>
          </div>
          
          {/* Completion Status Badge */}
          {(completedTodoCount / (todoCheckList.length || 1)) * 100 === 100 && (
            <div className="mb-2 p-1 bg-green-50 border border-green-200 rounded-md">
              <div className="flex items-center gap-1 text-xs text-green-700">
                <svg className="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                <span className="font-medium">All tasks completed!</span>
              </div>
            </div>
          )}
          
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-2 rounded-full transition-all duration-700 ease-out ${
                (completedTodoCount / (todoCheckList.length || 1)) * 100 === 100 
                  ? 'bg-gradient-to-r from-green-500 to-green-600' 
                  : (completedTodoCount / (todoCheckList.length || 1)) * 100 > 50 
                  ? 'bg-gradient-to-r from-blue-500 to-blue-600' 
                  : 'bg-gradient-to-r from-orange-500 to-orange-600'
              }`}
              style={{ 
                width: `${(completedTodoCount / (todoCheckList.length || 1)) * 100}%` 
              }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>0%</span>
            <span>50%</span>
            <span>100%</span>
          </div>
        </div>
      </div>
      <div className="px-4">
        <div className="flex items-center justify-between my-1">
          <div>
            <label className="text-xs text-gray-500">Start Date</label>
            <p className="text-[13px] font-medium text-gray-900">
              {moment(createdAt).format("Do MMM YYYY")}
            </p>
          </div>

          <div>
            <label className="text-xs text-gray-500">Due Date</label>
            <p className="text-[13px] font-medium text-gray-900">
              {moment(dueDate).format("Do MMM YYYY")}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between mt-3">
          <AvatarGroup
            avatars={assignedTo.map((user) => user.profileImageUrl)}
          />

          <div className="flex items-center gap-2">
            {attachmentCount > 0 && (
              <div className="flex items-center gap-2 bg-blue-50 px-2.5 py-1.5 rounded-lg">
                <LuPaperclip className="text-primary" />{" "}
                <span className="text-xs text-gray-900">{attachmentCount}</span>
              </div>
            )}

            {/* Domain Manager Actions */}
            {showActions && userRole === "domain_manager" && (
              <div className="flex items-center gap-2">
                {/* Message Admin Button */}
                {task?.createdBy && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onStartConversation) onStartConversation(task.createdBy, task);
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded hover:bg-blue-200 transition-colors"
                  >
                    <LuMessageSquare className="w-3 h-3" />
                    Message Admin
                  </button>
                )}

                {/* Assign Users Button */}
                {status === "Ready for Assignment" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onAssignUsers) onAssignUsers();
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded hover:bg-blue-200 transition-colors"
                  >
                    <LuUsers className="w-3 h-3" />
                    Assign
                  </button>
                )}

                {/* Rate Task Button - Only show when task is completed */}
                {status === "Completed" && onRateTask && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onRateTask) onRateTask();
                    }}
                    className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded transition-colors ${
                      task?.qualityRating && task?.timeRating 
                        ? "bg-green-100 text-green-800 hover:bg-green-200" 
                        : "bg-orange-500 text-white hover:bg-orange-600 shadow-md"
                    }`}
                    title={task?.qualityRating && task?.timeRating ? "Task already rated" : "Rate this completed task"}
                  >
                    <LuStar className="w-4 h-4" />
                    {task?.qualityRating && task?.timeRating ? "Rated" : "Rate Task"}
                  </button>
                )}

                {/* Rate User Performance Button - Show for completed checklist items */}
                {status === "Completed" && todoCheckList && todoCheckList.some(item => item.completed && item.completedBy) && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      // This will open the TaskReviewModal where they can rate individual users
                      if (onClick) onClick();
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded hover:bg-yellow-200 transition-colors"
                    title="Rate user performance on completed items"
                  >
                    <LuUserCheck className="w-3 h-3" />
                    Rate Users
                  </button>
                )}

              </div>
            )}

            {/* Admin Actions */}
            {showActions && userRole === "admin" && (
              <div className="flex items-center gap-2">
                {/* Message Domain Manager Button */}
                {task?.assignedDomainManagers && task.assignedDomainManagers.length > 0 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onStartConversation) onStartConversation(task.assignedDomainManagers[0], task);
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded hover:bg-blue-200 transition-colors"
                  >
                    <LuMessageSquare className="w-3 h-3" />
                    Message DM
                  </button>
                )}

                {/* Assign Domain Managers Button */}
                {status === "Ready for Assignment" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onAssignDomainManagers) onAssignDomainManagers(task);
                    }}
                    className="flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded hover:bg-purple-200 transition-colors"
                  >
                    <LuUsers className="w-3 h-3" />
                    Assign DM
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
