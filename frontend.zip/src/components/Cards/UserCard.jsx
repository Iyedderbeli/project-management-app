import React from "react";
import { LuStar, LuAward, LuTarget } from "react-icons/lu";

const UserCard = ({ userInfo }) => {
  const getOverallRatingColor = (rating) => {
    if (rating >= 4.5) return "text-green-600 bg-green-50";
    if (rating >= 4.0) return "text-blue-600 bg-blue-50";
    if (rating >= 3.5) return "text-yellow-600 bg-yellow-50";
    if (rating >= 3.0) return "text-orange-600 bg-orange-50";
    return "text-red-600 bg-red-50";
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <LuStar key={i} className="w-3 h-3 fill-current text-yellow-400" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <LuStar key="half" className="w-3 h-3 fill-current text-yellow-400 opacity-50" />
      );
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <LuStar key={`empty-${i}`} className="w-3 h-3 text-gray-300" />
      );
    }

    return stars;
  };

  const getSkillLevel = (rating) => {
    if (rating >= 4.5) return "Expert";
    if (rating >= 4.0) return "Advanced";
    if (rating >= 3.5) return "Intermediate";
    if (rating >= 3.0) return "Beginner";
    return "Novice";
  };

  const getSkillColor = (rating) => {
    if (rating >= 4.5) return "text-green-600 bg-green-50";
    if (rating >= 4.0) return "text-blue-600 bg-blue-50";
    if (rating >= 3.5) return "text-yellow-600 bg-yellow-50";
    if (rating >= 3.0) return "text-orange-600 bg-orange-50";
    return "text-red-600 bg-red-50";
  };

  return (
    <div className="user-card p-4">
      {/* User Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <img
            src={userInfo?.profileImageUrl}
            alt="avatar"
            className="w-12 h-12 rounded-full border-2 border-white"
          />
          <div>
            <p className="text-sm font-medium text-gray-900">{userInfo?.name}</p>
            <p className="text-xs text-gray-500">{userInfo?.email}</p>
            <p className="text-xs text-gray-400 capitalize">{userInfo?.role}</p>
          </div>
        </div>
        
        {/* Overall Rating Badge */}
        {userInfo?.overallRating && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getOverallRatingColor(userInfo.overallRating)}`}>
            <LuAward className="w-3 h-3" />
            {userInfo.overallRating.toFixed(1)}
          </div>
        )}
      </div>

      {/* Skills Section */}
      {userInfo?.skills && userInfo.skills.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <LuTarget className="w-3 h-3 text-gray-500" />
            <span className="text-xs font-medium text-gray-700">Skills</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {userInfo.skills.slice(0, 3).map((skill, index) => (
              <div
                key={index}
                className={`px-2 py-1 rounded text-xs font-medium ${getSkillColor(skill.rating)}`}
              >
                {skill.name} ({skill.rating.toFixed(1)})
              </div>
            ))}
            {userInfo.skills.length > 3 && (
              <div className="px-2 py-1 rounded text-xs font-medium text-gray-600 bg-gray-100">
                +{userInfo.skills.length - 3} more
              </div>
            )}
          </div>
        </div>
      )}

      {/* Rating Stars */}
      {userInfo?.overallRating && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-medium text-gray-700">Overall Rating</span>
            <span className="text-xs text-gray-500">({userInfo.overallRating.toFixed(1)})</span>
          </div>
          <div className="flex items-center gap-1">
            {renderStars(userInfo.overallRating)}
          </div>
        </div>
      )}

      {/* Task Statistics */}
      <div className="flex items-end gap-2">
        <StatCard
          label="Pending"
          count={userInfo?.pendingTasks || 0}
          status="Pending"
        />
        <StatCard
          label="In Progress"
          count={userInfo?.inProgressTasks || 0}
          status="In Progress"
        />
        <StatCard
          label="Completed"
          count={userInfo?.completedTasks || 0}
          status="Completed"
        />
      </div>
    </div>
  );
};

export default UserCard;

const StatCard = ({ label, count, status }) => {
    const getStatusTagColor = () => {
      switch (status) {
        case "In Progress":
          return "text-cyan-500 bg-gray-50";
        case "Completed":
          return "text-indigo-500 bg-gray-50";
        default:
          return "text-violet-500 bg-gray-50";
        }
    };
    return (
      <div
        className={`flex-1 text-[10px] font-medium ${getStatusTagColor()} px-4 py-0.5 rounded`}
      >
        <span className="text-[12px] font-semibold">{count}</span> <br />{" "}
        <span className="whitespace-nowrap">{label}</span>
      </div>
    );
}
