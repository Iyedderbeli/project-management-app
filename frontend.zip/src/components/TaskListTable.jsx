import moment from 'moment';
import React from 'react';

const TaskListTable = ({ tableData, onTaskClick }) => {
    const getStatusBadgeColor = (status) => {
        switch (status) {
            case 'Pending':
                return "bg-purple-100 text-purple-500 border border-purple-200";
            case 'In Progress':
                return 'bg-cyan-100 text-cyan-500 border border-cyan-200';;
            case 'Completed':
                return 'bg-green-100 text-green-500 border border-green-200';

            default:
                return 'bg-gray-100 text-gray-500 border border-gray-200';
        }
    };

    const getPriorityBadgeColor = (priority) => {
        switch (priority) {
            case 'Low':
                return "bg-green-100 text-green-500 border border-green-200";
            case 'Medium':
                return 'bg-orange-100 text-orange-500 border border-orange-200';
            case 'High':
                return 'bg-red-100 text-red-500 border border-red-200';

            default:
                return 'bg-gray-100 text-gray-500 border border-gray-200';
        }
    };
  return (
      <div className='overflow-x-auto p-0 rounded-lg mt-3'>
          <table className='min-w-full'>
              <thead>
                  <tr className='text-left'>
                      <th className='font-medium text-[13px] text-gray-800 px-4 py-3'>Project Name</th>
                      <th className='font-medium text-[13px] text-gray-800 px-4 py-3'>Status</th>
                      <th className='font-medium text-[13px] text-gray-800 px-4 py-3'>Priority</th>
                      <th className='font-medium text-[13px] text-gray-800 px-4 py-3 hidden md:table-cell'>Created On</th>
                  </tr>
              </thead>
              <tbody>
                    {tableData.map((task, index) => (
                        <tr 
                            key={task._id} 
                            className={`border-t border-gray-200 ${onTaskClick ? 'cursor-pointer hover:bg-gray-50 transition-colors' : ''}`}
                            onClick={() => onTaskClick && onTaskClick(task)}
                        >
                            <td className=' my-3 mx-4 text-[13px] line-clamp-1 text-gray-700 overflow-hidden'>{task.title}</td>
                            <td className='px-4 py-4'>
                                <span className={`px-2 py-1 rounded inline-block text-xs ${getStatusBadgeColor(task.status)}`}>
                                    {task.status}
                                </span>
                            </td>
                            <td className='px-4 py-4'>
                                <span className={`px-2 py-1 rounded inline-block text-xs  ${getPriorityBadgeColor(task.priority)}`}>
                                    {task.priority}
                                </span>
                            </td>
                            <td className='text-[13px] text-nowrap hidden text-gray-700 px-4 py-4 md:table-cell'>{task.createdAt?moment(task.createdAt).format('DD MMM YYYY') :'N/A'}</td>
                        </tr>
                    ))}
              </tbody>
          </table>
    </div>
  )
}

export default TaskListTable