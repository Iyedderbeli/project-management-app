import moment from 'moment';
import React, { useContext, useEffect, useRef, useState } from 'react';
import toast from 'react-hot-toast';
import { LuMessageSquare, LuRefreshCw, LuSearch, LuSend, LuUsers, LuX } from 'react-icons/lu';
import { useLocation, useNavigate } from 'react-router-dom';
import { UserContext } from '../context/userContext';
import { API_PATHS } from '../utils/apiPaths';
import axiosInstance from '../utils/axiosInstance';

const MessagingSystem = () => {
  const { user } = useContext(UserContext);
  const location = useLocation();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const messagesEndRef = useRef(null);

  // Parse URL parameters for opening specific conversation
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const targetUserId = searchParams.get('userId');
    const taskId = searchParams.get('taskId');
    const notificationType = searchParams.get('type');
    
    if (targetUserId && conversations.length > 0) {
      const targetConversation = conversations.find(conv => conv.user._id === targetUserId);
      if (targetConversation) {
        setSelectedConversation(targetConversation);
        // Clear URL parameters after opening conversation
        navigate(location.pathname, { replace: true });
      }
    }
  }, [conversations, location.search, navigate]);

  useEffect(() => {
    if (user) {
      fetchConversations();
      fetchUnreadCount();
      
      // Gentle background refresh every 30 seconds
      const interval = setInterval(() => {
        fetchConversations();
        fetchUnreadCount();
      }, 30000);
      
      return () => clearInterval(interval);
    }
  }, [user]);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation.user._id);
      markMessagesAsRead(selectedConversation.user._id);
    }
  }, [selectedConversation]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchConversations = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATIONS);
      
      if (response.data && Array.isArray(response.data)) {
        setConversations(response.data);
      }
    } catch (error) {
      console.error('Error fetching conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (userId) => {
    try {
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_CONVERSATION(userId));
      if (response.data && Array.isArray(response.data)) {
        setMessages(response.data);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast.error('Failed to load messages');
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.MESSAGES.GET_UNREAD_COUNT);
      if (response.data && typeof response.data.unreadCount === 'number') {
        setUnreadCount(response.data.unreadCount);
      }
    } catch (error) {
      console.error('Error fetching unread count:', error);
    }
  };

  const markMessagesAsRead = async (userId) => {
    try {
      await axiosInstance.put(API_PATHS.MESSAGES.MARK_MESSAGES_READ(userId));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) {
      return;
    }

    // Prevent self-messaging
    if (selectedConversation.user._id === user._id) {
      toast.error("You cannot send messages to yourself");
      return;
    }

    // Universal messaging - All users can message each other
    // No role-based restrictions needed

    // Create optimistic message for immediate UI update
    const optimisticMessage = {
      _id: `temp_${Date.now()}`,
      message: newMessage.trim(),
      fromUser: {
        _id: user._id,
        name: user.name,
        role: user.role
      },
      toUser: {
        _id: selectedConversation.user._id,
        name: selectedConversation.user.name,
        role: selectedConversation.user.role
      },
      createdAt: new Date().toISOString(),
      isOptimistic: true
    };

    // Immediately add the message to UI
    setMessages(prev => [...prev, optimisticMessage]);
    setNewMessage('');

    try {
      const response = await axiosInstance.post(API_PATHS.MESSAGES.SEND_MESSAGE, {
        toUserId: selectedConversation.user._id,
        message: newMessage.trim()
      });

      if (response.data) {
        // Replace optimistic message with real message
        setMessages(prev => {
          const filtered = prev.filter(msg => msg._id !== optimisticMessage._id);
          return [...filtered, response.data];
        });
        
        // Update conversation list
        setConversations(prev => {
          return prev.map(conv => {
            if (conv.user._id === selectedConversation.user._id) {
              return {
                ...conv,
                lastMessage: response.data
              };
            }
            return conv;
          });
        });

        // Show success notification
        toast.success('Message sent successfully!');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
      
      // Remove optimistic message on error
      setMessages(prev => prev.filter(msg => msg._id !== optimisticMessage._id));
      setNewMessage(newMessage.trim()); // Restore the message
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getRoleBadge = (role) => {
    const roleColors = {
      admin: 'bg-red-100 text-red-800',
      domain_manager: 'bg-blue-100 text-blue-800',
      member: 'bg-green-100 text-green-800',
      user: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${roleColors[role] || roleColors.user}`}>
        {role.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  const searchUsers = async (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearchLoading(true);
      // Search for users by name or email containing the query
      const response = await axiosInstance.get(`${API_PATHS.USERS.SEARCH_USERS}?q=${encodeURIComponent(query.trim())}`);
      
      // Filter out the current user from search results
      const filteredResults = response.data?.filter(searchUser => searchUser._id !== user?._id) || [];
      setSearchResults(filteredResults);
      
      // Show feedback if no results found
      if (filteredResults.length === 0 && query.trim().length > 0) {
        console.log(`No users found for query: "${query}"`);
      }
    } catch (error) {
      console.error("Error searching users:", error);
      if (error.response?.status === 400) {
        toast.error("Please enter a valid search term");
      } else {
        toast.error("Failed to search users");
      }
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    // Clear previous timeout
    if (window.searchTimeout) {
      clearTimeout(window.searchTimeout);
    }
    
    if (query.trim()) {
      // Debounce search to avoid too many API calls
      window.searchTimeout = setTimeout(() => {
        searchUsers(query);
      }, 300);
    } else {
      setSearchResults([]);
    }
  };

  const startNewConversation = async (user) => {
    try {
      // Check if conversation already exists
      const existingConversation = conversations.find(conv => conv.user?._id === user._id || conv._id === user._id);
      
      if (existingConversation) {
        setSelectedConversation(existingConversation);
        // Fetch messages for this conversation
        await fetchMessages(existingConversation.user?._id || existingConversation._id);
        setSearchQuery("");
        setSearchResults([]);
        return;
      }

      // Create a new conversation object
      const newConversation = {
        _id: user._id,
        user: {
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          profileImageUrl: user.profileImageUrl
        },
        lastMessage: null,
        unreadCount: 0
      };

      setSelectedConversation(newConversation);
      setSearchQuery("");
      setSearchResults([]);
      
      // Refresh conversations list to include this new conversation
      await fetchConversations();
      
      toast.success(`Started conversation with ${user.name}`);
    } catch (error) {
      console.error("Error starting conversation:", error);
      toast.error("Failed to start conversation");
    }
  };

  const handleManualRefresh = async () => {
    try {
      await fetchConversations();
      await fetchUnreadCount();
      if (selectedConversation) {
        await fetchMessages(selectedConversation.user._id);
      }
    } catch (error) {
      console.error('Error during manual refresh:', error);
      toast.error('Failed to refresh messages');
    }
  };

  const filteredConversations = conversations.filter(conv => {
    // Filter by search term
    const matchesSearch = conv.user?.name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter out self-conversations
    if (conv.user._id === user._id) {
      return false;
    }
    
    // Universal messaging - Show all users regardless of role
    return matchesSearch;
  });

  return (
    <div className="flex h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Conversations Sidebar */}
      <div className="w-96 bg-white shadow-xl flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-white">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-800">Messages</h1>
            <button
              onClick={handleManualRefresh}
              className="p-2 text-gray-500 hover:text-blue-600 transition-colors bg-gray-100 rounded-lg hover:bg-blue-50"
              title="Check for new messages"
            >
              <LuRefreshCw className="w-5 h-5" />
            </button>
          </div>
          
          {/* Helpful tip */}
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>💡 Universal Messaging:</strong> Search for any user by name or email to start a conversation. 
              You can message admins, domain managers, or regular users.
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <LuSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search conversations or users..."
              value={searchQuery}
              onChange={handleSearchChange}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* User Search Results */}
          {searchResults.length > 0 && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200 max-h-48 overflow-y-auto">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Search Results</h4>
              <div className="space-y-2">
                {searchResults.map((searchUser) => (
                  <div
                    key={searchUser._id}
                    onClick={() => startNewConversation(searchUser)}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-white cursor-pointer transition-colors border border-transparent hover:border-blue-200"
                  >
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                      {searchUser.profileImageUrl ? (
                        <img
                          src={searchUser.profileImageUrl}
                          alt={searchUser.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <span>{searchUser.name?.charAt(0).toUpperCase()}</span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{searchUser.name}</p>
                      <p className="text-xs text-gray-500 truncate">{searchUser.email}</p>
                    </div>
                    {getRoleBadge(searchUser.role)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Loading indicator for search */}
          {searchLoading && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                Searching users...
              </div>
            </div>
          )}

          {/* Conversation Filter */}
          <div className="mt-3">
            <input
              type="text"
              placeholder="Filter conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {!user ? (
            <div className="p-6 text-center text-gray-500">
              <LuUsers className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="font-medium mb-2">Loading user...</p>
              <p className="text-sm text-gray-400">Please wait while we load your information</p>
            </div>
          ) : loading ? (
            <div className="p-6 text-center text-gray-500">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-2">Loading conversations...</p>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              <LuMessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="font-medium mb-2">No conversations yet</p>
              <p className="text-sm text-gray-400">
                Messages from all users will appear here
              </p>
              <p className="text-xs text-gray-400 mt-2">
                Tip: Use the search bar above to find and message any user
              </p>
              <p className="text-xs text-gray-400">
                You can message admins, domain managers, or regular users
              </p>
              <button
                onClick={handleManualRefresh}
                className="mt-4 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
              >
                Check for new messages
              </button>
            </div>
          ) : (
            filteredConversations.map((conversation) => (
              <div
                key={conversation.user._id}
                className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                  selectedConversation?.user._id === conversation.user._id ? 'bg-blue-50 border-blue-200' : ''
                }`}
                onClick={() => setSelectedConversation(conversation)}
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                    {conversation.user.profileImageUrl ? (
                      <img
                        src={conversation.user.profileImageUrl}
                        alt={conversation.user.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-lg">
                        {conversation.user.name?.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-semibold text-gray-800 truncate">
                        {conversation.user.name}
                      </p>
                      {getRoleBadge(conversation.user.role)}
                    </div>
                    <p className="text-xs text-gray-600 truncate mb-1">
                      {conversation.lastMessage?.message || 'No messages yet'}
                    </p>
                    <p className="text-xs text-gray-400">
                      {conversation.lastMessage?.createdAt ? moment(conversation.lastMessage.createdAt).fromNow() : ''}
                    </p>
                  </div>
                  {conversation.unreadCount > 0 && (
                    <span className="bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-semibold">
                      {conversation.unreadCount}
                    </span>
                  )}
                </div>
                                 </div>
                 ))
               )}
               <div ref={messagesEndRef} />
             </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 flex flex-col bg-white shadow-lg">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
                         <div className="p-6 border-b border-gray-200 bg-white">
               <div className="flex items-center justify-between">
                 <div className="flex items-center gap-4">
                   {/* Role indicator for domain managers */}
            
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                    {selectedConversation.user.profileImageUrl ? (
                      <img
                        src={selectedConversation.user.profileImageUrl}
                        alt={selectedConversation.user.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-lg">
                        {selectedConversation.user.name?.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-gray-800">
                      {selectedConversation.user.name}
                    </h2>
                    <div className="flex items-center gap-2">
                      {getRoleBadge(selectedConversation.user.role)}
                      <span className="text-sm text-gray-500">
                        {selectedConversation.user.email}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedConversation(null)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LuX className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50 min-h-0">
              {messages.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <LuMessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p className="font-medium mb-2">No messages yet</p>
                  <p className="text-sm">Start the conversation by sending a message</p>
                </div>
              ) : (
                                 messages.map((message) => (
                   <div
                     key={message._id}
                     className={`flex ${message.fromUser._id === selectedConversation.user._id ? 'justify-start' : 'justify-end'}`}
                   >
                     <div
                       className={`max-w-md px-4 py-3 rounded-2xl shadow-sm ${
                         message.fromUser._id === selectedConversation.user._id
                           ? 'bg-white text-gray-800 border border-gray-200'
                           : 'bg-blue-500 text-white'
                       } ${message.isOptimistic ? 'opacity-70' : ''}`}
                     >
                       <p className="text-sm leading-relaxed">{message.message}</p>
                       <div className={`text-xs mt-2 flex items-center gap-1 ${
                         message.fromUser._id === selectedConversation.user._id
                           ? 'text-gray-400'
                           : 'text-blue-100'
                       }`}>
                         <span>{moment(message.createdAt).format('HH:mm')}</span>
                         {message.isOptimistic && (
                           <span className="text-yellow-500">• Sending...</span>
                         )}
                       </div>
                     </div>
                   </div>
                 ))
              )}
            </div>

            {/* Message Input */}
            <div className="p-6 border-t border-gray-200 bg-white flex-shrink-0 z-10 relative">
              <div className="flex gap-3">
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder={`Type your message as ${user?.role === 'domain_manager' ? 'Domain Manager' : user?.role === 'admin' ? 'Admin' : 'User'}...`}
                  className="flex-1 p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows="2"
                />
                <button
                  onClick={sendMessage}
                  disabled={!newMessage.trim()}
                  className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors"
                >
                  <LuSend className="w-4 h-4" />
                  Send
                </button>

              </div>

            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center text-gray-500">
              <LuMessageSquare className="w-20 h-20 mx-auto mb-6 text-gray-300" />
              <h3 className="text-xl font-medium mb-2">Select a conversation</h3>
              <p className="text-sm">Choose a conversation from the sidebar to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MessagingSystem;